import { existsSync } from 'node:fs';
if (!existsSync(new URL('./dist/backend/server.js', import.meta.url))) await import('./scripts/build.mjs');
const { start } = await import('./dist/backend/server.js');
start();
