// Ported from chatbot.py. Standard-library operations use native JavaScript helpers.
import * as result_store from './result_store.ts';
import * as _u from './universe.ts';
import { today } from './tushare_client.ts';
import { pyAdd, pyAnd, pyAny, pyAt, pyBool, pyCompare, pyFormat, pyIn, pyInt, pyIsinstance, pyIter, pyLen, pyList, pyMethod, pyOr, pyRegex, pySlice, pyStr, pyType } from './runtime.ts';
export let FRESHNESS_MAX_AGE_HOURS = 24;
export let TEMPLATE_GREET = "Hi! I can help with company information and metrics stored in this dashboard. What would you like to check?";
export let TEMPLATE_THANKS = "You're welcome!";
export let TEMPLATE_BYE = "Goodbye! I answer only from records stored in this dashboard -- reload a company any time and ask away.";
export let TEMPLATE_JOKE = "What does a baby computer call his father? -Data!";
export let TEMPLATE_HELP = "Here is what I can actually do -- all answers come only from records this dashboard has stored locally on this machine (I have no internet access):\n• latest close and daily change, 52-week range, period high/low, max drawdown\n• six stored ratios: P/E (TTM), P/S (TTM), TTM cash dividend yield, revenue growth, ROE, interest coverage -- with the supplied-universe industry median when stored\n• industry matched-cohort revenue growth and aggregate annual revenue totals\n• brokerage rating distribution, most common brokerage rating, verified-horizon target midpoints (always attributed to the brokerages)\n• stored news items (I distinguish an empty feed from a failed query)\n• an overview of everything stored for one company\nI cannot browse, fetch live data, predict prices, or give personalised advice. If the records don't support a question, I'll say so.";
export let _GREET_ONLY = pyRegex.compile("^(?:hey|hi+|hello|hallo|yo|hiya|howdy|good\\s*(?:morning|afternoon|evening|day))[\\s!.,?]*$", 2);
export let _THANKS_ONLY = pyRegex.compile("^(?:thanks?|thank\\s+you|ty|thx|cheers)[\\s!.,?]*$", 2);
export let _BYE_ONLY = pyRegex.compile("^(?:bye(?:bye)?|goodbye|see\\s+(?:you|ya)|cya|later|that(?:'s| s)?\\s+all|done)[\\s!.,?]*$", 2);
export let _HELP = pyRegex.compile("what\\s+can\\s+you\\s+do|your\\s+(?:capabilit|function)|how\\s+do\\s+you\\s+work|^help\\??$|what\\s+are\\s+you\\s+able|^\\/?help\\b", 2);
export let _JOKE = pyRegex.compile("\\bjoke\\b|make\\s+me\\s+laugh|something\\s+funny", 2);
export let _LEAD_GREET = pyRegex.compile("^(?:hey|hi+|hello|hallo|yo|hiya|howdy|good\\s*(?:morning|afternoon|evening|day))[\\s,!.?]+", 2);
export let _UNSAFE = pyRegex.compile("(?:ignore|disregard|forget|override|bypass)\\s+(?:all\\s+|the\\s+|your\\s+)?(?:previous|prior|above|earlier|system|safety|allowed|authorized|rules?|polic(?:y|ies)|guardrails?|guidelines?|instructions?)|^(?:system|assistant|developer)\\s*:|you\\s+are\\s+now|new\\s+instructions?|pretend\\s+to\\s+be|role\\s*-?\\s*play|jailbreak|dan\\s+mode|https?://|<\\s*(?:script|html|iframe)|api[_\\s-]?key|password\\s*[:=]|token\\s*[:=]|secret\\s*[:=]", (2 | 8));
export let _PRON = pyRegex.compile("\\bits\\b|\\bthe\\s+company\\b|\\bthis\\s+company\\b|\\bthe\\s+stock\\b|\\bit\\b", 2);
export function _looks_like_injection(q: any): any {
    return pyBool(pyMethod(_UNSAFE, "search", q));
}
export function _convo(text: any): any {
    return { ["answer"]: text, ["answer_status"]: "conversational", ["note"]: "approved local template; no financial facts; no retrieval performed" };
}
export function _age_hours(iso: any): any { if (!iso)
    return null; const normalized = /(?:Z|[+-]\d{2}:?\d{2})$/.test(iso) ? iso : iso + '+08:00'; const ms = Date.parse(normalized); return Number.isFinite(ms) ? (Date.now() - ms) / 3600000 : null; }
export function _is_stale(record: any): any {
    let age: any;
    age = _age_hours(pyMethod(record, "get", "stored_at"));
    return (pyBool(((age === null))) ? true : ((pyCompare(age, FRESHNESS_MAX_AGE_HOURS) > 0)));
}
export function _tickers_in(q: any): any {
    return pyRegex.findall("\\b(\\d{6})\\b", q);
}
export function _match_company(q: any, records: any): any {
    let hits: any, low: any, name: any, rec: any, tk: any;
    [low, hits] = [pyMethod(q, "lower"), []];
    for ([tk, rec] of pyIter(pyMethod(records, "items"))) {
        name = pyOr(pyMethod(pyOr(pyMethod(rec, "get", "company"), () => { }), "get", "company_name"), () => "");
        if (pyBool(pyOr((pyIn(tk, low)), () => pyOr(pyAnd(name, () => (pyIn(pyMethod(name, "lower"), low))), () => pyAnd(((pyCompare(pyLen(name), 4) >= 0)), () => (pyIn(pySlice(name, null, 4), q))))))) {
            pyMethod(hits, "append", tk);
        }
    }
    return hits;
}
/** scope_tickers: authorized dashboard/watchlist tickers, enforced in code.
 *
 * context_ticker: the company currently selected in the dashboard UI. Used
 * ONLY to resolve references like "its"; never treated as factual evidence. */
export function answer(question: any, scope_tickers: any = null, context_ticker: any = null): any {
    let ack: any, age: any, allowed: any, explicit: any, in_scope: any, lead: any, name: any, names: any, out: any, q: any, rec: any, records: any, refused: any, rest: any, stored_hits: any, t0: any, tickers: any, tk: any, valid_unstored: any;
    q = pyMethod(pyOr(question, () => ""), "strip");
    if (pyBool(!pyBool(q))) {
        return { ["answer"]: "What would you like to check?", ["answer_status"]: "clarification_needed" };
    }
    if (pyBool(_looks_like_injection(q))) {
        return { ["answer"]: "That message looks like an attempt to change my rules or scope. Instructions in questions or stored records are inert data: I answer only from authorized dashboard records, with no network access.", ["answer_status"]: "unsupported_question", ["note"]: "possible prompt injection detected; refused, not obeyed" };
    }
    if (pyBool(pyMethod(_GREET_ONLY, "match", q))) {
        return _convo(TEMPLATE_GREET);
    }
    if (pyBool(pyMethod(_THANKS_ONLY, "match", q))) {
        return _convo(TEMPLATE_THANKS);
    }
    if (pyBool(pyMethod(_BYE_ONLY, "match", q))) {
        return _convo(TEMPLATE_BYE);
    }
    if (pyBool(pyMethod(_HELP, "match", q))) {
        return _convo(TEMPLATE_HELP);
    }
    if (pyBool(pyMethod(_JOKE, "search", q))) {
        return _convo(TEMPLATE_JOKE);
    }
    ack = "";
    lead = pyMethod(_LEAD_GREET, "match", q);
    if (pyBool(lead)) {
        rest = pyMethod(pySlice(q, pyMethod(lead, "end"), null), "strip");
        if (pyBool(!pyBool(rest))) {
            return _convo(TEMPLATE_GREET);
        }
        ack = "Hi! ";
        q = rest;
    }
    try {
        records = result_store.all_records();
    }
    catch (__error) {
        if (true) {
            const exc: any = __error;
            return { ["answer"]: "Retrieval from the local record store failed.", ["answer_status"]: "error", ["error"]: pyType(exc).name };
        }
        else {
            throw __error;
        }
    }
    allowed = (pyBool(((scope_tickers !== null))) ? scope_tickers : null);
    in_scope = (() => { const _comprehension1: any = {}; for (const [tk, r] of pyIter(pyMethod(records, "items"))) {
        if (!pyBool(pyOr(((allowed === null)), () => (pyIn(tk, allowed)))))
            continue;
        _comprehension1[tk] = r;
    } return _comprehension1; })();
    explicit = pyOr(_tickers_in(q), () => _match_company(q, records));
    stored_hits = (() => { const _comprehension2: any = []; for (const t of pyIter(explicit)) {
        if (!pyBool((pyIn(t, in_scope))))
            continue;
        _comprehension2.push(t);
    } return _comprehension2; })();
    refused = (pyBool(((allowed !== null))) ? (() => { const _comprehension3: any = []; for (const t of pyIter(explicit)) {
        if (!pyBool(pyAnd(((allowed !== null)), () => (!pyIn(t, allowed)))))
            continue;
        _comprehension3.push(t);
    } return _comprehension3; })() : []);
    valid_unstored = (() => { const _comprehension4: any = []; for (const t of pyIter(explicit)) {
        if (!pyBool(pyAnd((!pyIn(t, in_scope)), () => !pyBool(pyAnd(((allowed !== null)), () => (!pyIn(t, allowed)))))))
            continue;
        _comprehension4.push(t);
    } return _comprehension4; })();
    if (pyBool(pyAnd(refused, () => !pyBool(stored_hits)))) {
        return { ["answer"]: pyAdd(ack, "That company is not part of your authorized dashboard records, so I will not retrieve or discuss it."), ["answer_status"]: "unsupported_question", ["note"]: "out-of-scope request refused without exposing unauthorized records" };
    }
    if (pyBool(pyAnd(!pyBool(stored_hits), () => valid_unstored))) {
        t0 = pyAt(valid_unstored, 0);
        if (pyBool(((_u.get_company(t0) === null)))) {
            return { ["answer"]: pyAdd(ack, (pyStr(t0) + " is not part of the supplied SSE A-share universe, so there is no authorized record to retrieve.")), ["answer_status"]: "unsupported_question" };
        }
        return { ["answer"]: pyAdd(ack, ("The app does not know based on the data available in this dashboard: no results have been stored yet for " + pyStr(t0) + ". Open that company in the dashboard first (real data needs a configured Tushare token).")), ["answer_status"]: "insufficient_data" };
    }
    tickers = stored_hits;
    if (pyBool(!pyBool(tickers))) {
        if (pyBool(!pyBool(in_scope))) {
            return { ["answer"]: pyAdd(ack, "The app does not know based on the data available in this dashboard: no company results have been stored yet. Open a company in the dashboard first (real data needs a configured Tushare token)."), ["answer_status"]: "insufficient_data" };
        }
        names = pyMethod(", ", "join", (() => { const _comprehension5: any = []; for (const [tk, r] of pyIter(pySlice(pyList(pyMethod(in_scope, "items")), null, 6))) {
            _comprehension5.push((pyStr(pyMethod(pyOr(pyMethod(r, "get", "company"), () => { }), "get", "company_name")) + " (" + pyStr(tk) + ")"));
        } return _comprehension5; })());
        if (pyBool(pyAnd(context_ticker, () => (pyIn(context_ticker, in_scope))))) {
            tickers = [context_ticker];
        }
        else {
            if (pyBool(context_ticker)) {
                return { ["answer"]: pyAdd(ack, ("The company currently selected (" + pyStr(context_ticker) + ") is not among your stored authorized records, so I cannot answer for it. Your stored dashboard covers: " + pyStr(names) + ".")), ["answer_status"]: "unsupported_question", ["note"]: "context reference did not resolve to an authorized stored record" };
            }
            else {
                if (pyBool(((pyLen(in_scope) === 1)))) {
                    tickers = pyList(pyMethod(in_scope, "keys"));
                }
                else {
                    return { ["answer"]: pyAdd(pyAdd(pyAdd(ack, "Which company do you mean? Your stored dashboard covers: "), names), "."), ["answer_status"]: "clarification_needed" };
                }
            }
        }
    }
    tk = pyAt(tickers, 0);
    rec = pyAt(records, tk);
    name = pyOr(pyMethod(pyOr(pyMethod(rec, "get", "company"), () => { }), "get", "company_name"), () => tk);
    if (pyBool(_is_stale(rec))) {
        age = _age_hours(pyMethod(rec, "get", "stored_at"));
        return { ["answer"]: pyAdd(pyAdd(pyAdd(ack, ("Dashboard records for " + pyStr(name) + " are stale")), (pyBool(((age !== null))) ? (" (stored " + pyStr(pyInt(age)) + " hours ago)") : " (no valid stored date)")), ". Refresh the dashboard before asking about current values."), ["answer_status"]: "stale_data", ["stored_at"]: pyMethod(rec, "get", "stored_at") };
    }
    out = _dispatch(pyMethod(q, "lower"), rec, name);
    if (pyBool(pyAnd(ack, () => pyIsinstance(pyMethod(out, "get", "answer"), String)))) {
        out["answer"] = pyAdd(ack, pyAt(out, "answer"));
    }
    return out;
}
export function _fmt(v: any, suffix: any = ""): any {
    return (pyBool(((v === null))) ? "N/A" : (pyStr(v) + pyStr(suffix)));
}
export function _dispatch(q: any, rec: any, name: any): any {
    let bm: any, caps: any, cite: any, cm: any, comp: any, cov: any, dist: any, feed: any, g: any, groups: any, growth: any, hist: any, ind: any, ir: any, label: any, last: any, lbl: any, lines: any, m: any, md: any, metric_patterns: any, mid: any, mm: any, nw: any, parts: any, pat: any, proven: any, pt: any, qw: any, suffix: any, summ: any, text: any, totals: any, w: any;
    caps = pyMethod(rec, "get", "capabilities", {});
    proven = pyMethod(rec, "get", "provenance", {});
    cite = { ["source"]: pyMethod(proven, "get", "provider", "Tushare via backend (stored dashboard record)"), ["as_of"]: pyMethod(proven, "get", "as_of"), ["stored_at"]: pyMethod(rec, "get", "stored_at") };
    function answered(text: any, defs: any = null): any {
        let out: any;
        out = { ["answer"]: text, ["answer_status"]: "answered", ["citations"]: cite };
        if (pyBool(defs)) {
            out["definitions"] = defs;
        }
        return out;
    }
    function not_know(section: any, label: any, status: any, reason: any = null): any {
        return { ["answer"]: pyAdd(pyAdd(("The app does not know based on the data available in this dashboard: stored " + pyStr(label) + " for " + pyStr(name) + " is not usable (section: " + pyStr(section) + ", status: " + pyStr(pyOr(status, () => "missing"))), (pyBool(reason) ? (", reason: " + pyStr(reason)) : "")), ")."), ["answer_status"]: "insufficient_data", ...cite };
    }
    if (pyBool(pyAnd(pyRegex.search("\\b(price|close|trading at|how much)\\b", q), () => !pyBool(pyRegex.search("target|rating|broker|analyst|recommend", q))))) {
        hist = pyOr(pyMethod(caps, "get", "historical-analysis"), () => pyOr(pyMethod(caps, "get", "historical_analysis"), () => { }));
        if (pyBool(((pyMethod(hist, "get", "status") !== "available")))) {
            return not_know("historical-analysis", "price analysis", pyMethod(hist, "get", "status"), pyMethod(hist, "get", "reason"));
        }
        m = pyMethod(hist, "get", "metrics", {});
        cov = pyMethod(hist, "get", "actual_coverage_period", {});
        return answered((pyStr(name) + "'s latest stored close was CNY " + pyStr(_fmt(pyMethod(m, "get", "current_price"))) + " (quote date " + pyStr(pyMethod(cov, "get", "end", "unknown")) + "). Daily change: " + pyStr(_fmt(pyMethod(m, "get", "daily_change_percentage"))) + "% vs previous session close. 52-week range " + pyStr(_fmt(pyMethod(m, "get", "52_week_low"))) + " – " + pyStr(_fmt(pyMethod(m, "get", "52_week_high"))) + ". " + pyStr(pyMethod(hist, "get", "coverage_note", ""))), pyMethod(hist, "get", "calculation_definitions"));
    }
    if (pyBool((pyIn("drawdown", q)))) {
        hist = pyOr(pyMethod(caps, "get", "historical-analysis"), () => pyOr(pyMethod(caps, "get", "historical_analysis"), () => { }));
        md = pyOr(pyMethod(pyOr(pyMethod(hist, "get", "metrics"), () => { }), "get", "max_drawdown"), () => { });
        if (pyBool(((pyMethod(md, "get", "percentage") === null)))) {
            return not_know("historical-analysis", "adjusted drawdown", pyMethod(hist, "get", "status"), pyMethod(md, "get", "reason"));
        }
        return answered(("Maximum drawdown for " + pyStr(name) + " was " + pyStr(pyAt(md, "percentage")) + "% on an adjusted-close basis (reference date " + pyStr(pyMethod(md, "get", "reference_date")) + ", " + pyStr(pyMethod(md, "get", "period", "stored period")) + "). Formula: " + pyStr(pyMethod(md, "get", "formula")) + ". A historical peak-to-trough description, not a prediction."), { ["adjusted close"]: "prices normalised for splits/bonus issues to the reference date" });
    }
    if (pyBool(pyAnd(pyOr((pyIn("industry", q)), () => pyOr((pyIn("sector", q)), () => (pyIn("peer", q)))), () => pyAny((() => { const _comprehension6: any = []; for (const k of pyIter(["growth", "revenue", "median", "cohort", "compare", "peers"])) {
        _comprehension6.push((pyIn(k, q)));
    } return _comprehension6; })())))) {
        ir = pyOr(pyMethod(caps, "get", "industry-research"), () => pyOr(pyMethod(caps, "get", "industry_research"), () => { }));
        growth = (() => { const _comprehension7: any = []; for (const g of pyIter(pyOr(pyMethod(ir, "get", "matched_cohort_growth"), () => []))) {
            if (!pyBool(((pyMethod(g, "get", "status") === "available"))))
                continue;
            _comprehension7.push(g);
        } return _comprehension7; })();
        totals = (() => { const _comprehension8: any = []; for (const t of pyIter(pyOr(pyMethod(ir, "get", "annual_revenue_totals"), () => []))) {
            if (!pyBool(((pyMethod(t, "get", "aggregate_revenue_cny") !== null))))
                continue;
            _comprehension8.push(t);
        } return _comprehension8; })();
        if (pyBool(pyAnd(!pyBool(growth), () => !pyBool(totals)))) {
            return not_know("industry-research", "industry revenue records", pyMethod(ir, "get", "status"), pyMethod(ir, "get", "reason"));
        }
        label = pyMethod(pyOr(pyMethod(rec, "get", "company"), () => { }), "get", "industry_label", "?");
        parts = [];
        if (pyBool(totals)) {
            last = pyAt(totals, (-1));
            pyMethod(parts, "append", ("Supplied SSE universe labelled “" + pyStr(label) + "”: latest stored aggregate annual revenue (FY" + pyStr(pyAt(last, "financial_year")) + ") CNY " + pyFormat(pyAt(last, "aggregate_revenue_cny"), (",.0f")) + " across " + pyStr(pyAt(last, "included_company_count")) + "/" + pyStr(pyAt(last, "total_universe_count")) + " companies (coverage " + pyStr(pyMethod(last, "get", "coverage_percentage")) + "%)."));
        }
        if (pyBool(growth)) {
            g = pyAt(growth, (-1));
            pyMethod(parts, "append", ("Matched-cohort growth " + pyStr(pyAt(g, "years")) + ": " + pyStr(pyAt(g, "yoy_growth_percentage_points")) + "% (n=" + pyStr(pyAt(g, "matched_company_count")) + ")."));
        }
        pyMethod(parts, "append", "Listed-company statistics for the supplied SSE universe — not mainland-China market size or demand/supply evidence; cohort membership can differ between year pairs.");
        return answered(pyMethod(" ", "join", parts));
    }
    metric_patterns = [["\\bp/?e\\b|earnings multiple|price.to.earnings", "pe", "P/E (TTM)", ""], ["\\bp/?s\\b|price.to.sales", "ps", "P/S (TTM)", ""], ["dividend", "dividend_yield", "TTM cash dividend yield", "%"], ["revenue growth|sales growth|\\brevenue\\b|\\bgrowth\\b", "revenue_growth", "revenue growth", "%"], ["\\broe\\b|return on equity", "roe", "ROE", "%"], ["interest coverage|coverage ratio|\\bcoverage\\b", "interest_coverage", "interest coverage", "x"]];
    for ([pat, mid, label, suffix] of pyIter(metric_patterns)) {
        if (pyBool(pyRegex.search(pat, q))) {
            cm = pyOr(pyMethod(caps, "get", "company-card-metrics"), () => pyOr(pyMethod(caps, "get", "card_metrics"), () => { }));
            m = pyMethod(pyOr(pyMethod(cm, "get", "metrics"), () => { }), "get", mid);
            if (pyBool(!pyBool(m))) {
                return not_know("company-card-metrics", label, null);
            }
            if (pyBool(pyOr(((pyMethod(m, "get", "status") !== "available")), () => ((pyMethod(m, "get", "value") === null))))) {
                return not_know("company-card-metrics", label, pyMethod(m, "get", "status"), pyMethod(m, "get", "reason"));
            }
            text = pyAdd(pyAdd(pyAdd((pyStr(name) + "'s stored " + pyStr(label) + ": " + pyStr(_fmt(pyAt(m, "value"), suffix)) + " [basis: " + pyStr(pyMethod(m, "get", "calculation_basis"))), (pyBool(pyMethod(m, "get", "reporting_period")) ? ("; period: " + pyStr(pyMethod(m, "get", "reporting_period"))) : "")), (pyBool(pyMethod(m, "get", "source_publication_date")) ? ("; published: " + pyStr(pyMethod(m, "get", "source_publication_date"))) : "")), ("; provenance: " + pyStr(pyMethod(m, "get", "provenance", "retrieved")) + "]."));
            bm = pyOr(pyMethod(m, "get", "benchmark"), () => { });
            if (pyBool(pyAnd(((pyMethod(bm, "get", "status") === "available")), () => ((pyMethod(bm, "get", "industry_median") !== null))))) {
                text += (" Supplied-universe SSE industry median for " + pyStr(pyMethod(bm, "get", "benchmark_period")) + ": " + pyStr(_fmt(pyAt(bm, "industry_median"), suffix)) + " over " + pyStr(pyMethod(bm, "get", "peer_count")) + " comparable companies (" + pyStr(pyMethod(bm, "get", "industry_universe_count")) + " in universe, " + pyStr(pyMethod(bm, "get", "excluded_count")) + " excluded). A supplied-universe statistic, not a whole-China benchmark.");
            }
            else {
                if (pyBool(bm)) {
                    text += (" Industry median unavailable (" + pyStr(pyMethod(bm, "get", "reason", "not retrieved")) + ").");
                }
            }
            return answered(text);
        }
    }
    if (pyBool(pyAny((() => { const _comprehension9: any = []; for (const k of pyIter(["rating", "analyst", "broker", "target", "recommend"])) {
        _comprehension9.push((pyIn(k, q)));
    } return _comprehension9; })()))) {
        pt = pyOr(pyMethod(caps, "get", "price-target"), () => pyOr(pyMethod(caps, "get", "price_target"), () => { }));
        if (pyBool((!pyIn(pyMethod(pt, "get", "status"), ["available", "partial", "no_results"])))) {
            return not_know("price-target", "broker research", pyMethod(pt, "get", "status"), pyMethod(pt, "get", "reason"));
        }
        dist = pyOr(pyMethod(pt, "get", "rating_distribution"), () => { });
        parts = [];
        if (pyBool(pyAny(pyMethod(dist, "values")))) {
            summ = pyOr(pyMethod(pt, "get", "rating_summary"), () => { });
            qw = pyOr(pyMethod(pt, "get", "query_window"), () => { });
            pyMethod(parts, "append", pyAdd(pyAdd(("Among " + pyStr(pyMethod(pt, "get", "eligible_brokerages_for_ratings", 0)) + " eligible brokerages (" + pyStr(pyMethod(qw, "get", "start_date")) + " → " + pyStr(pyMethod(qw, "get", "end_date")) + "): "), pyMethod(", ", "join", (() => { const _comprehension10: any = []; for (const [cat, n] of pyIter(pyMethod(dist, "items"))) {
                _comprehension10.push((pyStr(cat) + " " + pyStr(n)));
            } return _comprehension10; })())), "."));
            if (pyBool(pyMethod(summ, "get", "value"))) {
                pyMethod(parts, "append", ("Most common brokerage rating: " + pyStr(pyAt(summ, "value")) + " (" + pyStr(pyMethod(summ, "get", "category_count")) + "/" + pyStr(pyMethod(summ, "get", "total_mapped_brokerages")) + ")."));
            }
        }
        groups = (() => { const _comprehension11: any = []; for (const g of pyIter(pyOr(pyMethod(pt, "get", "target_groups"), () => []))) {
            if (!pyBool(((pyMethod(g, "get", "status") === "available"))))
                continue;
            _comprehension11.push(g);
        } return _comprehension11; })();
        if (pyBool(groups)) {
            g = pyAt(groups, 0);
            pyMethod(parts, "append", ("Average brokerage target midpoint (" + pyStr(pyAt(g, "horizon")) + "): CNY " + pyStr(pyAt(g, "average_target_midpoint")) + " across " + pyStr(pyAt(g, "eligible_brokerage_count")) + " brokerages; implied difference vs stored close: " + pyStr(pyAt(g, "implied_percentage_difference")) + "%. A calculated summary of sourced opinions — not an official consensus, not a guaranteed price."));
        }
        else {
            ind = pyOr(pyMethod(pt, "get", "individual_source_targets"), () => []);
            if (pyBool(ind)) {
                pyMethod(parts, "append", ("No verified-horizon average available; " + pyStr(pyLen(ind)) + " individual source targets are stored with dates and bounds."));
            }
            else {
                if (pyBool(((pyMethod(pt, "get", "status") === "no_results")))) {
                    pyMethod(parts, "append", "A successful stored query found no broker reports in the window.");
                }
            }
        }
        if (pyBool(!pyBool(parts))) {
            return not_know("price-target", "supported rating/target records", pyMethod(pt, "get", "status"));
        }
        pyMethod(parts, "append", "Buy/Sell labels belong to the named brokerages; nothing here is personalised advice or this app's own opinion.");
        return answered(pyMethod(" ", "join", parts));
    }
    if (pyBool(pyAny((() => { const _comprehension12: any = []; for (const k of pyIter(["news", "story", "stories", "headline", "happened"])) {
        _comprehension12.push((pyIn(k, q)));
    } return _comprehension12; })()))) {
        nw = pyOr(pyMethod(caps, "get", "company-industry-news"), () => pyOr(pyMethod(caps, "get", "company_industry_news"), () => { }));
        feed = pyOr(pyMethod(nw, "get", "feed"), () => []);
        if (pyBool((pyIn(pyMethod(nw, "get", "status"), [null, "provider_not_configured", "permission_denied", "error"])))) {
            return { ["answer"]: ("The app does not know based on the data available in this dashboard: stored news retrieval for " + pyStr(name) + " did not complete (status: " + pyStr(pyMethod(nw, "get", "status", "missing")) + " — a failed query, not an empty feed)."), ["answer_status"]: "insufficient_data", ...cite };
        }
        if (pyBool(!pyBool(feed))) {
            w = pyOr(pyMethod(nw, "get", "query_window"), () => { });
            return { ["answer"]: ("A successful stored query for " + pyStr(name) + " found no matching stories in " + pyStr(pyMethod(w, "get", "start_date")) + " → " + pyStr(pyMethod(w, "get", "end_date")) + "."), ["answer_status"]: "answered", ...cite, ["note"]: "empty result from a successful query, distinct from failure" };
        }
        lines = pyMethod("; ", "join", (() => { const _comprehension13: any = []; for (const it of pyIter(pySlice(feed, null, 5))) {
            _comprehension13.push(("“" + pyStr(pyAt(it, "title")) + "” (" + pyStr(pyOr(pyMethod(it, "get", "publisher"), () => "publisher not supplied")) + ", " + pyStr(pyOr(pyMethod(it, "get", "published_at"), () => "time not supplied")) + ", " + pyStr(pyAt(it, "match_type")) + ")"));
        } return _comprehension13; })());
        return answered(("Stored news items for " + pyStr(name) + ": " + pyStr(lines) + ". Timing of a story is not evidence that it moved the price; inclusion does not verify every claim."));
    }
    if (pyBool(pyAny((() => { const _comprehension14: any = []; for (const k of pyIter(["what do you know", "tell me about", "overview", "who is", "summary"])) {
        _comprehension14.push((pyIn(k, q)));
    } return _comprehension14; })()))) {
        cm = pyOr(pyMethod(pyOr(pyMethod(caps, "get", "company-card-metrics"), () => pyOr(pyMethod(caps, "get", "card_metrics"), () => { })), "get", "metrics"), () => { });
        hist = pyOr(pyMethod(pyOr(pyMethod(caps, "get", "historical-analysis"), () => pyOr(pyMethod(caps, "get", "historical_analysis"), () => { })), "get", "metrics"), () => { });
        comp = pyOr(pyMethod(rec, "get", "company"), () => { });
        lines = [(pyStr(pyMethod(comp, "get", "company_name")) + " (" + pyStr(pyMethod(comp, "get", "exchange")) + "-" + pyStr(pyMethod(comp, "get", "company_id")) + "), industry label “" + pyStr(pyMethod(comp, "get", "industry_label")) + "”.")];
        if (pyBool(((pyMethod(hist, "get", "current_price") !== null)))) {
            pyMethod(lines, "append", ("Latest stored close CNY " + pyStr(pyAt(hist, "current_price")) + "."));
        }
        for ([mid, lbl] of pyIter([["pe", "P/E TTM"], ["roe", "ROE"], ["revenue_growth", "revenue growth"]])) {
            mm = pyOr(pyMethod(cm, "get", mid), () => { });
            if (pyBool(((pyMethod(mm, "get", "status") === "available")))) {
                pyMethod(lines, "append", (pyStr(lbl) + ": " + pyStr(pyAt(mm, "value")) + "."));
            }
        }
        pyMethod(lines, "append", ("Stored section statuses: " + pyStr(pyMethod(rec, "get", "feature_status")) + "."));
        return answered(pyMethod(" ", "join", lines));
    }
    return { ["answer"]: "The app does not know based on the data available in this dashboard: this question needs an unsupported handler or data outside the stored records. Try asking about the stored price, a specific ratio (P/E, P/S, dividend yield, revenue growth, ROE, interest coverage), industry cohort growth, broker ratings/targets, or news. Ask “what can you do?” for my full list.", ["answer_status"]: "unsupported_question", ...cite };
}
