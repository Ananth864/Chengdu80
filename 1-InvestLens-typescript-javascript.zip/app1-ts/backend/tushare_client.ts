/** Sole external provider. Tokens are never returned or included in stored results. */
import { existsSync, readFileSync, mkdirSync, writeFileSync, chmodSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { ROOT } from './paths.ts';
export const API_URL = 'https://api.tushare.pro';
export const CACHE_TTL_SECONDS = 900;
export const TIMEZONE = 'Asia/Shanghai';
export const MAX_RETRIES = 3;
export const TIMEOUT_SECONDS = 20;
export const TOKEN_FILE = join(ROOT, 'config/tushare_token.txt');
export class ProviderError extends Error {
    kind: string;
    code: string | null;
    constructor(kind: string, message: string, code: string | null = null) {
        super(message);
        this.name = 'ProviderError';
        this.kind = kind;
        this.code = code;
    }
}
let memoryToken: string | null = null, generation = 0;
const cache = new Map<string, {
    timestamp: number;
    rows: any[];
}>();
export function set_memory_token(value: string | null): void { memoryToken = (value || '').trim() || null; generation++; cache.clear(); }
export const clear_memory_token = (): void => set_memory_token(null);
export function persist_token_file(value: string): void {
    mkdirSync(dirname(TOKEN_FILE), { recursive: true });
    writeFileSync(TOKEN_FILE, value.trim(), { mode: 0o600 });
    chmodSync(TOKEN_FILE, 0o600);
}
const envToken = (): string | null => (process.env.TUSHARE_TOKEN || '').trim() || null;
const fileToken = (): string | null => existsSync(TOKEN_FILE) ? readFileSync(TOKEN_FILE, 'utf8').trim() || null : null;
export const token = (): string | null => memoryToken || envToken() || fileToken();
export function token_source(): string | null {
    return memoryToken ? 'memory (entered in the app this session)' : envToken() ? 'environment variable TUSHARE_TOKEN' : fileToken() ? 'config/tushare_token.txt' : null;
}
export const is_configured = (): boolean => token() !== null;
export const retrieved_at = (): string => new Date(Date.now() + 8 * 3600000).toISOString().slice(0, 19) + '+08:00';
export const today = (): string => retrieved_at().slice(0, 10);
export function d(value: any): string | null {
    if (!value)
        return null;
    const s = String(value).trim();
    return /^\d{8}$/.test(s) ? `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}` : s.slice(0, 10) || null;
}
export async function query(api_name: string, params: Record<string, any> | null = null, fields = ''): Promise<any[]> {
    const credential = token();
    if (!credential)
        throw new ProviderError('provider_not_configured', 'No Tushare token configured for the backend.');
    params ||= {};
    // Include the current credential in the cache namespace, so environment/file changes cannot reuse another account's data.
    const key = JSON.stringify([credential, api_name, fields, Object.entries(params).sort(([a], [b]) => a.localeCompare(b))]);
    const hit = cache.get(key);
    if (hit && Date.now() - hit.timestamp < CACHE_TTL_SECONDS * 1000)
        return structuredClone(hit.rows);
    const currentGeneration = generation;
    let body: any;
    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
        try {
            const response = await fetch(API_URL, { method: 'POST',
                headers: { 'Content-Type': 'application/json', 'User-Agent': 'sse-dashboard-demo/1.1' },
                body: JSON.stringify({ api_name, token: credential, params, fields }),
                signal: AbortSignal.timeout(TIMEOUT_SECONDS * 1000) });
            if (!response.ok)
                throw new Error('Provider HTTP failure');
            body = await response.json();
            break;
        }
        catch {
            if (attempt === MAX_RETRIES - 1)
                throw new ProviderError('error', 'Tushare request failed after retries.');
            await new Promise(resolve => setTimeout(resolve, Math.min(2 ** attempt, 4) * 1000));
        }
    }
    const code = body?.code, message = String(body?.msg || '').trim();
    if (code !== 0) {
        if (['权限', '积分', 'token', '没有', '不允许'].some(s => message.includes(s)) || /permission|token/i.test(message))
            throw new ProviderError('permission_denied', 'Tushare rejected this endpoint for the configured account.', String(code));
        // Do not repeat provider text: it can contain credential material.
        throw new ProviderError('error', 'Tushare endpoint error.', String(code));
    }
    const names = body.data?.fields || [], items = body.data?.items || [];
    const rows = items.map((item: any[]) => Object.fromEntries(names.slice(0, item.length).map((name: string, i: number) => [name, item[i]])));
    if (currentGeneration === generation && credential === token())
        cache.set(key, { timestamp: Date.now(), rows: structuredClone(rows) });
    return rows;
}
