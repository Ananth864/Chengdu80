/** Node HTTP adapter. The same API paths and static frontend are retained. */
import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { readFileSync, statSync } from 'node:fs';
import { resolve, extname, sep } from 'node:path';
import { pathToFileURL } from 'node:url';
import { ROOT } from './paths.ts';
import * as capabilities from './capabilities.ts';
import * as chatbot from './chatbot.ts';
import * as fixtures from './fixtures.ts';
import * as metric_guide from './metric_guide.ts';
import * as result_store from './result_store.ts';
import * as universe from './universe.ts';
import { ProviderError, clear_memory_token, is_configured, persist_token_file, query, set_memory_token, token_source, today } from './tushare_client.ts';
const WEB = resolve(ROOT, 'web');
const MIME: Record<string, string> = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml' };
function send(response: ServerResponse, code: number, body: Buffer | string, contentType: string): void {
    const data = typeof body === 'string' ? Buffer.from(body) : body;
    response.writeHead(code, { 'Content-Type': contentType, 'Content-Length': data.length, 'Cache-Control': 'no-store' });
    response.end(data);
}
function json(response: ServerResponse, obj: any, code = 200): void { send(response, code, JSON.stringify(obj), 'application/json; charset=utf-8'); }
function range(days: number): [
    string,
    string
] {
    const end = today(), start = new Date(end + 'T00:00:00Z');
    start.setUTCDate(start.getUTCDate() - days);
    return [start.toISOString().slice(0, 10).replaceAll('-', ''), end.replaceAll('-', '')];
}
export async function verify_endpoints(): Promise<any> {
    if (!is_configured())
        return { status: 'provider_not_configured', note: 'no token in the backend; nothing was sent anywhere.', endpoints: [] };
    const [s, e] = range(10), [rs, re] = range(30), [ns, ne] = range(3);
    const probes: [
        string,
        string,
        () => Promise<any[]>
    ][] = [
        ['daily', 'daily prices (historical-analysis)', () => query('daily', { ts_code: '600000.SH', start_date: s, end_date: e }, 'ts_code,trade_date,close')],
        ['adj_factor', 'adjustment factors (max drawdown)', () => query('adj_factor', { ts_code: '600000.SH', start_date: s, end_date: e }, 'ts_code,trade_date,adj_factor')],
        ['daily_basic', 'valuation & dividend ratios (card metrics)', () => query('daily_basic', { ts_code: '600000.SH', start_date: s, end_date: e }, 'ts_code,trade_date,pe_ttm,ps_ttm,dv_ratio')],
        ...(['income', 'balancesheet', 'fina_indicator'].map((api, i): [
            string,
            string,
            () => Promise<any[]>
        ] => [api,
            ['income statements (revenue, growth, coverage)', 'balance sheet (equity for ROE fallback)', 'financial indicators (ROE)'][i],
            () => query(api, { ts_code: '600000.SH', period: `${Number(today().slice(0, 4)) - 1}1231` }, ['ts_code,end_date,total_revenue', 'ts_code,end_date,total_hldr_eqy_exc_min_int', 'ts_code,end_date,roe'][i])])),
        ['report_rc', 'broker research (ratings & targets)', () => query('report_rc', { ts_code: '600000.SH', start_date: rs, end_date: re }, 'ts_code,report_date,org_name,rating')],
        ['news', 'news feed (company-industry-news)', () => query('news', { ts_code: '600000.SH', start_date: ns, end_date: ne })],
    ];
    const results: any[] = [];
    for (const [endpoint, description, probe] of probes) {
        try {
            const rows = await probe();
            results.push(rows.length ? { endpoint, description, status: 'available', rows_returned: rows.length }
                : { endpoint, description, status: 'empty_success', note: 'endpoint readable; probe returned no rows' });
        }
        catch (exc) {
            results.push({ endpoint, description, status: exc instanceof ProviderError ? exc.kind : 'error', reason: exc instanceof ProviderError ? exc.message : (exc as Error).name });
        }
    }
    return { status: 'done', token_source: token_source(), endpoints_ok: results.filter(r => ['available', 'empty_success'].includes(r.status)).length,
        endpoints_total: results.length, note: 'Per-endpoint authenticated evidence. A token alone does not guarantee every permission.', endpoints: results };
}
async function readBody(request: IncomingMessage): Promise<any> {
    const chunks = [];
    let size = 0;
    for await (const chunk of request) {
        size += chunk.length;
        if (size > 1024 * 1024)
            throw new Error('body_too_large');
        chunks.push(chunk);
    }
    const data = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
    if (!data || typeof data !== 'object' || Array.isArray(data))
        throw new SyntaxError('Body must be an object');
    return data;
}
export async function handler(request: IncomingMessage, response: ServerResponse): Promise<void> {
    try {
        const url = new URL(request.url || '/', 'http://localhost'), path = url.pathname;
        const q = Object.fromEntries(url.searchParams), method = request.method;
        if (method === 'POST') {
            let body: any;
            try {
                body = await readBody(request);
            }
            catch (error) {
                return json(response, { status: 'invalid_input', error_code: (error as Error).message === 'body_too_large' ? 'body_too_large' : 'malformed_json' }, (error as Error).message === 'body_too_large' ? 413 : 400);
            }
            if (path === '/api/token') {
                if (body.token != null && typeof body.token !== 'string')
                    return json(response, { status: 'invalid_input', error_code: 'invalid_token' }, 400);
                const tok = (body.token || '').trim();
                if (!tok) {
                    clear_memory_token();
                    return json(response, { status: 'cleared', note: 'session token removed from backend memory; environment/config token still applies if set' });
                }
                set_memory_token(tok);
                let saved = false;
                if (body.persist) {
                    try {
                        persist_token_file(tok);
                        saved = true;
                    }
                    catch { }
                }
                return json(response, { status: 'saved', in_backend_memory: true, written_to_config_file: saved,
                    note: 'The token is not returned to the browser or saved in browser storage. Permissions are unknown until verified.' });
            }
            if (path === '/api/verify')
                return json(response, await verify_endpoints());
            return json(response, { status: 'error', error_code: 'unknown_endpoint' }, 404);
        }
        if (method !== 'GET')
            return json(response, { status: 'invalid_input', error_code: 'method_not_allowed' }, 405);
        if (path.startsWith('/api/')) {
            if (path === '/api/config')
                return json(response, { provider: 'Tushare', configured: is_configured(), token_source: token_source(),
                    universe_size: Object.keys(universe.load_universe()).length,
                    note: 'Token is held in the backend process only. Without a token data capabilities return provider_not_configured.' });
            if (path === '/api/companies') {
                const limit = Number(q.limit || 30);
                if (!Number.isInteger(limit))
                    return json(response, { status: 'invalid_input', error_code: 'invalid_limit' }, 400);
                return json(response, { query: q.q || '', results: universe.search(q.q || '', Math.max(1, Math.min(1000, limit))) });
            }
            if (path === '/api/metric-guide')
                return json(response, { capability_id: 'metric-education', guide: metric_guide.GUIDE,
                    note: 'Curated explanations. No universal good/bad threshold is asserted for any metric.' });
            if (path === '/api/chat')
                return json(response, chatbot.answer(q.q || '', (q.scope || '').split(',').map(s => s.trim()).filter(Boolean).length
                    ? q.scope.split(',').map(s => s.trim()).filter(Boolean) : null, q.ctx?.trim() || null));
            if (path === '/api/store')
                return json(response, { capability_id: 'result-store', schema_version: result_store.SCHEMA_VERSION, stored_companies: result_store.summary() });
            if (['/api/company', '/api/bundle', '/api/refresh'].includes(path)) {
                const company = universe.get_company(q.ticker || '');
                if (!company)
                    return json(response, { status: 'invalid_input', error_code: 'ticker_not_in_supplied_universe', exchange: 'SSE' }, 404);
                if (path === '/api/company')
                    return json(response, { status: 'available', ...company.to_dict(), industry_peer_count: universe.industry_members(company.industry).length });
                if (path === '/api/bundle') {
                    if (q.mode === 'fixture')
                        return json(response, fixtures.bundle(company, q.period || '1y'));
                    const bundle = await capabilities.bundle_for(company, q.period || '1y');
                    bundle.store_result = result_store.save(bundle);
                    return json(response, bundle);
                }
                const runners: Record<string, () => Promise<any>> = {
                    historical_analysis: () => capabilities.historical_analysis(company, q.period || '1y'), card_metrics: () => capabilities.card_metrics(company),
                    industry_research: () => capabilities.industry_research(company), company_industry_news: () => capabilities.company_industry_news(company),
                    price_target: () => capabilities.price_target(company),
                };
                const fn = runners[q.capability];
                if (!fn)
                    return json(response, { status: 'invalid_input', error_code: 'unknown_capability' }, 400);
                return json(response, await fn());
            }
            return json(response, { status: 'error', error_code: 'unknown_endpoint' }, 404);
        }
        const rel = path === '/' ? 'index.html' : decodeURIComponent(path).replace(/^\/+/, '');
        const full = resolve(WEB, rel);
        if (!full.startsWith(WEB + sep))
            return send(response, 404, 'not found', 'text/plain; charset=utf-8');
        try {
            if (!statSync(full).isFile())
                throw new Error('not a file');
            send(response, 200, readFileSync(full), MIME[extname(full)] || 'application/octet-stream');
        }
        catch {
            send(response, 404, 'not found', 'text/plain; charset=utf-8');
        }
    }
    catch (exc) {
        json(response, { status: 'error', reason: (exc as Error).name || 'Error' }, 500);
    }
}
export function resolve_port(argv: string[], envValue?: string): number {
    let raw = envValue || '8765';
    const index = argv.indexOf('--port');
    if (index >= 0) {
        if (!argv[index + 1])
            throw new Error('--port needs a number');
        raw = argv[index + 1];
    }
    if (!/^\d+$/.test(raw.trim()) || Number(raw) < 1 || Number(raw) > 65535)
        throw new Error('Port must be an integer from 1 to 65535');
    return Number(raw);
}
export function start(): void {
    try {
        const port = resolve_port(process.argv.slice(2), process.env.PORT), host = process.env.HOST || '127.0.0.1';
        const server = createServer((req, res) => { void handler(req, res); });
        server.on('error', (error: Error) => { console.error(`Cannot listen on ${host}:${port}: ${error.message}`); process.exitCode = 1; });
        server.listen(port, host, () => { console.log(`InvestLens -> http://${host}:${port}`); console.log(`Tushare token configured: ${is_configured()}`); });
    }
    catch (error) {
        console.error((error as Error).message);
        process.exitCode = 1;
    }
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href)
    start();
