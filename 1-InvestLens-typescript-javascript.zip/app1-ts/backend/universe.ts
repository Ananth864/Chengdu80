/** CSV remains the source of truth; tickers retain leading zeroes. */
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { ROOT } from './paths.ts';
export const EXCHANGE = 'SSE';
export class Company {
    ticker: string;
    name: string;
    industry: string;
    market_cap_rmb_csv: number | null;
    size_category: string;
    constructor(ticker: string, name: string, industry: string, market_cap_rmb_csv: number | null, size_category: string) {
        Object.assign(this, { ticker, name, industry, market_cap_rmb_csv, size_category });
    }
    to_dict(): Record<string, any> {
        return { exchange: EXCHANGE, company_id: this.ticker, company_name: this.name,
            industry_label: this.industry, size_category: this.size_category,
            csv_market_cap_snapshot_undated: this.market_cap_rmb_csv };
    }
}
/** Handles quoted fields, escaped quotes, BOMs, CRLF, and embedded newlines. */
export function parseCSV(text: string): string[][] {
    const rows: string[][] = [];
    let row: string[] = [], field = '', quoted = false;
    for (let i = 0; i < text.length; i++) {
        const ch = text[i];
        if (ch === '"') {
            if (quoted && text[i + 1] === '"') {
                field += '"';
                i++;
            }
            else
                quoted = !quoted;
        }
        else if (ch === ',' && !quoted) {
            row.push(field);
            field = '';
        }
        else if ((ch === '\n' || ch === '\r') && !quoted) {
            if (ch === '\r' && text[i + 1] === '\n')
                i++;
            row.push(field);
            if (row.some(v => v !== ''))
                rows.push(row);
            row = [];
            field = '';
        }
        else
            field += ch;
    }
    if (quoted)
        throw new Error('Unclosed quoted CSV field');
    if (field || row.length) {
        row.push(field);
        rows.push(row);
    }
    return rows;
}
let cached: Record<string, Company> | undefined;
export function load_universe(): Record<string, Company> {
    if (cached)
        return cached;
    const [header, ...rows] = parseCSV(readFileSync(join(ROOT, 'data/companies.csv'), 'utf8'));
    const columns = header.map(v => v.replace(/^\uFEFF/, '').trim());
    const result: Record<string, Company> = {};
    for (const values of rows) {
        const row = Object.fromEntries(columns.map((key, i) => [key, (values[i] || '').trim()]));
        const ticker = row['Ticker Symbol'];
        if (!/^\d{6}$/.test(ticker) || Object.hasOwn(result, ticker))
            continue;
        const raw = row['A-share Market Capitalisation (RMB)'];
        const cap = raw ? Number(raw.replaceAll(',', '')) : NaN;
        result[ticker] = new Company(ticker, row['Company Name'], row.Industry, Number.isFinite(cap) ? cap : null, row['Size Category']);
    }
    cached = result;
    return result;
}
export const get_company = (ticker: string): Company | null => load_universe()[(ticker || '').trim()] || null;
export const industry_members = (label: string): Company[] => Object.values(load_universe()).filter(c => c.industry === label);
export function search(query: string, limit = 25): Record<string, any>[] {
    const q = (query || '').trim().toLowerCase();
    const out = [];
    for (const c of Object.values(load_universe())) {
        if (!q || c.ticker.includes(q) || c.name.toLowerCase().includes(q) || c.industry.toLowerCase().includes(q)) {
            out.push(c.to_dict());
            if (out.length >= limit)
                break;
        }
    }
    return out;
}
