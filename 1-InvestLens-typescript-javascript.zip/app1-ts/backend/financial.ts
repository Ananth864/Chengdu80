// Ported from financial.py. Standard-library operations use native JavaScript helpers.
import { ProviderError, d, query } from './tushare_client.ts';
import { pyAdd, pyAnd, pyAt, pyBool, pyCompare, pyDict, pyFloat, pyIn, pyInt, pyIter, pyMax, pyMethod, pyOr, pySlice, pySorted, pyStr } from './runtime.ts';
export let CURRENCY = "CNY";
export function _num(v: any): any {
    let f: any;
    if (pyBool(pyOr(((v === null)), () => ((v === ""))))) {
        return null;
    }
    try {
        f = pyFloat(v);
    }
    catch (__error) {
        if (true) {
            return null;
        }
        else {
            throw __error;
        }
    }
    return f;
}
export async function _rows(api: any, ts_code: any, start: any, end: any, fields: any): Promise<any> {
    return await query(api, { ["ts_code"]: ts_code, ["start_date"]: start, ["end_date"]: end }, fields);
}
/** Return annual observations plus the statement rows needed for TTM. */
export async function fetch_company_financials(ts_code: any, as_of: any): Promise<any> {
    let balance: any, end: any, income: any, ratios: any, start: any;
    end = pyMethod(as_of, "replace", "-", "");
    start = (pyStr((pyInt(pySlice(as_of, null, 4)) - 6)) + "0101");
    income = await _rows("income", ts_code, start, end, "ts_code,end_date,ann_date,f_ann_date,report_type,comp_type,total_revenue,revenue,n_income_attr_p,ebit,total_profit,fin_exp,interest_expense,general_excpt");
    balance = await _rows("balancesheet", ts_code, start, end, "ts_code,end_date,ann_date,f_ann_date,report_type,total_hldr_eqy_exc_min_int,total_hldr_eqy_inc_min_int");
    ratios = await _rows("fina_indicator", ts_code, start, end, "ts_code,end_date,ann_date,roe,roe_waa,roe_dt,tr_yoy,netprofit_yoy");
    /** Latest-published-first map keyed by period end date, consolidated only. */
    function index(rows: any): any {
        let cur: any, out: any, period: any, pub: any, r: any;
        out = {};
        for (r of pyIter(rows)) {
            period = d(pyMethod(r, "get", "end_date"));
            if (pyBool(!pyBool(period))) {
                continue;
            }
            if (pyBool((!pyIn(pyStr(pyOr(pyMethod(r, "get", "report_type"), () => "1")), ["1", "4"])))) {
                continue;
            }
            pub = d(pyOr(pyMethod(r, "get", "ann_date"), () => pyMethod(r, "get", "f_ann_date")));
            if (pyBool(pyAnd(pub, () => ((pyCompare(pub, as_of) > 0))))) {
                continue;
            }
            cur = pyMethod(out, "get", period);
            if (pyBool(pyOr(((cur === null)), () => ((pyCompare(pyOr(pub, () => ""), pyOr(pyMethod(cur, "get", "_published"), () => "")) > 0))))) {
                r = pyDict(r);
                r["_published"] = pub;
                out[period] = r;
            }
        }
        return out;
    }
    return { ["income"]: index(income), ["balance"]: index(balance), ["ratios"]: index(ratios), ["as_of"]: as_of, ["currency"]: CURRENCY };
}
export function annual_years(fin: any): any {
    return pySorted([(() => { const _comprehension1: any = []; for (const p of pyIter(pyAt(fin, "income"))) {
            if (!pyBool(pyMethod(p, "endswith", "-12-31")))
                continue;
            _comprehension1.push(pySlice(p, null, 4));
        } return _comprehension1; })()], null, false);
}
export function annual(fin: any, year: any): any {
    let bal: any, rat: any, row: any;
    row = pyMethod(pyAt(fin, "income"), "get", (pyStr(year) + "-12-31"));
    if (pyBool(!pyBool(row))) {
        return null;
    }
    bal = pyMethod(pyAt(fin, "balance"), "get", (pyStr(year) + "-12-31"), {});
    rat = pyMethod(pyAt(fin, "ratios"), "get", (pyStr(year) + "-12-31"), {});
    return { ["year"]: year, ["revenue"]: (pyBool(((pyMethod(row, "get", "total_revenue") !== null))) ? _num(pyMethod(row, "get", "total_revenue")) : _num(pyMethod(row, "get", "revenue"))), ["parent_profit"]: _num(pyMethod(row, "get", "n_income_attr_p")), ["ebit"]: _num(pyMethod(row, "get", "ebit")), ["pre_tax"]: _num(pyMethod(row, "get", "total_profit")), ["interest_expense"]: (pyBool(((_num(pyMethod(row, "get", "fin_exp")) !== null))) ? _num(pyMethod(row, "get", "fin_exp")) : _num(pyMethod(row, "get", "interest_expense"))), ["general_admin"]: _num(pyMethod(row, "get", "general_excpt")), ["equity"]: _num(pyMethod(bal, "get", "total_hldr_eqy_exc_min_int")), ["published"]: pyMethod(row, "get", "_published"), ["roe_provider"]: (pyBool(((_num(pyMethod(rat, "get", "roe_waa")) !== null))) ? _num(pyMethod(rat, "get", "roe_waa")) : _num(pyMethod(rat, "get", "roe"))) };
}
export function _latest_period_before(fin: any, source: any, as_of: any): any {
    let cand: any;
    cand = (() => { const _comprehension2: any = []; for (const [p, r] of pyIter(pyMethod(pyAt(fin, source), "items"))) {
        if (!pyBool(pyAnd(((pyCompare(p, as_of) <= 0)), () => ((pyCompare(pyOr(pyMethod(r, "get", "_published"), () => "9999"), as_of) <= 0)))))
            continue;
        _comprehension2.push(p);
    } return _comprehension2; })();
    return (pyBool(cand) ? pyMax([cand], null, false) : null);
}
/** Trailing-twelve-month total for an income field. */
export function ttm(fin: any, field: any, as_of: any): any {
    let fy: any, latest: any, period_end: any, prior_full: any, prior_year: any, prior_ytd: any, prior_ytd_period: any, prior_ytd_val: any, row: any, value: any;
    latest = _latest_period_before(fin, "income", as_of);
    if (pyBool(!pyBool(latest))) {
        return { ["value"]: null, ["status"]: "unavailable", ["reason"]: "no_published_statements" };
    }
    row = pyAt(pyAt(fin, "income"), latest);
    period_end = latest;
    value = _num(pyMethod(row, "get", field));
    if (pyBool(pyMethod(period_end, "endswith", "-12-31"))) {
        return { ["value"]: value, ["status"]: (pyBool(((value !== null))) ? "available" : "unavailable"), ["coverage_end"]: period_end, ["published"]: pyMethod(row, "get", "_published"), ["method"]: "annual_statement", ["reason"]: (pyBool(((value !== null))) ? null : "missing_field") };
    }
    prior_year = pyStr((pyInt(pySlice(period_end, null, 4)) - 1));
    fy = annual(fin, prior_year);
    prior_ytd_period = (pyStr(prior_year) + pyStr(pySlice(period_end, 4, null)));
    prior_ytd = pyMethod(pyAt(fin, "income"), "get", prior_ytd_period);
    if (pyBool(pyOr(((value === null)), () => pyOr(((fy === null)), () => pyOr(((pyMethod(fy, "get", "revenue") === null)), () => ((prior_ytd === null))))))) {
        return { ["value"]: null, ["status"]: "unavailable", ["coverage_end"]: period_end, ["published"]: pyMethod(row, "get", "_published"), ["method"]: "ytd_plus_prior_year", ["reason"]: "insufficient_comparable_statements" };
    }
    if (pyBool(((field === "total_revenue")))) {
        prior_full = pyAt(fy, "revenue");
    }
    else {
        prior_full = pyAt(fy, "parent_profit");
    }
    prior_ytd_val = (pyBool(((_num(pyMethod(prior_ytd, "get", field)) !== null))) ? _num(pyMethod(prior_ytd, "get", field)) : (pyBool(((field === "total_revenue"))) ? _num(pyMethod(prior_ytd, "get", "revenue")) : null));
    if (pyBool(pyOr(((prior_full === null)), () => ((prior_ytd_val === null))))) {
        return { ["value"]: null, ["status"]: "unavailable", ["coverage_end"]: period_end, ["published"]: pyMethod(row, "get", "_published"), ["method"]: "ytd_plus_prior_year", ["reason"]: "insufficient_comparable_statements" };
    }
    return { ["value"]: (pyAdd(value, prior_full) - prior_ytd_val), ["status"]: "available", ["coverage_end"]: period_end, ["published"]: pyMethod(row, "get", "_published"), ["method"]: "latest_ytd_plus_prior_full_year_minus_prior_ytd", ["reason"]: null };
}
