// Ported from fixtures.py. Standard-library operations use native JavaScript helpers.
import { retrieved_at, today } from './tushare_client.ts';
import { PyDate, PyDelta, pyAdd, pyAt, pyBool, pyDateSubtract, pyFormat, pyHash, pyIn, pyInt, pyIter, pyLen, pyMax, pyMethod, pyMin, pyRange, pyRound, pySlice, pyStr, pySum, pyZip } from './runtime.ts';
export function _seed(text: any): any {
    let h: any;
    h = pyMethod(pyHash(pyMethod(text, "encode", "utf-8")), "hexdigest");
    return (parseInt(pySlice(h, null, 8), 16) / 4294967295);
}
export function _walk(ts_code: any, n: any, base: any): any {
    let d0: any, drift: any, i: any, out: any, r: any, v: any;
    r = _seed(ts_code);
    [out, v] = [[], base];
    for (i of pyIter(pyRange(n))) {
        drift = pyAdd((Math.sin((pyAdd(i, (r * 40)) / 11.0)) * 0.011), (Math.sin((pyAdd(i, (r * 7)) / 3.0)) * 0.004));
        v = pyMax([0.5, (v * pyAdd(1, drift))], null, false);
        d0 = pyDateSubtract(new PyDate(today()), new PyDelta(((n - 1) - i), 0)).isoformat();
        pyMethod(out, "append", { ["date"]: d0, ["close"]: pyRound(v, 2), ["high"]: pyRound((v * 1.012), 2), ["low"]: pyRound((v * 0.988), 2), ["open"]: pyRound((v * 0.997), 2), ["volume"]: pyInt(pyAdd(100000.0, (r * 500000.0))) });
    }
    return out;
}
export let _FIX = { ["status"]: "fixture", ["fixture_warning"]: "SYNTHETIC DEMO DATA — not a real observation. Cannot support any investment judgement." };
export function historical(company: any, period: any = "1y"): any {
    let days: any, hi: any, last: any, lo: any, mdd: any, peak: any, prev: any, s: any, series: any, span: any;
    days = pyMethod({ ["1m"]: 28, ["6m"]: 182, ["1y"]: 365, ["5y"]: 1825 }, "get", period, 365);
    span = pyMin([days, 1500], null, false);
    series = _walk((pyStr(company.ticker) + ".SH"), pyMax([2, Math.floor(span / 2)], null, false), pyAdd(20, (_seed(company.ticker) * 180)));
    [last, prev] = [pyAt(series, (-1)), pyAt(series, (-2))];
    hi = pyMax([(() => { const _comprehension1: any = []; for (const s of pyIter(series)) {
            _comprehension1.push(pyAt(s, "high"));
        } return _comprehension1; })()], null, false);
    lo = pyMin([(() => { const _comprehension2: any = []; for (const s of pyIter(series)) {
            _comprehension2.push(pyAt(s, "low"));
        } return _comprehension2; })()], null, false);
    [peak, mdd] = [pyAt(pyAt(series, 0), "close"), 0.0];
    for (s of pyIter(series)) {
        peak = pyMax([peak, pyAt(s, "close")], null, false);
        mdd = pyMin([mdd, ((pyAt(s, "close") / peak) - 1)], null, false);
    }
    return { ..._FIX, ["capability_id"]: "historical-analysis", ["contract_version"]: "1.1.0", ["exchange"]: "SSE", ["company_id"]: company.ticker, ["company_name"]: company.name, ["industry_label"]: company.industry, ["provider"]: "FIXTURE (no provider called)", ["as_of"]: today(), ["retrieved_at"]: retrieved_at(), ["currency"]: "CNY", ["requested_period"]: period, ["actual_coverage_period"]: { ["start"]: pyAt(pyAt(series, 0), "date"), ["end"]: pyAt(last, "date"), ["trading_days"]: pyLen(series) }, ["price_basis"]: "fixture raw prices", ["adjustment_basis"]: "fixture adjusted closes", ["coverage_note"]: "52-week window fully covered by fixture history.", ["metrics"]: { ["current_price"]: pyAt(last, "close"), ["52_week_high"]: hi, ["52_week_low"]: lo, ["available_period_high"]: hi, ["available_period_low"]: lo, ["daily_change_amount"]: pyRound((pyAt(last, "close") - pyAt(prev, "close")), 2), ["daily_change_percentage"]: pyRound((((pyAt(last, "close") / pyAt(prev, "close")) - 1) * 100), 2), ["distance_from_52_week_high"]: { ["amount"]: pyRound((pyAt(last, "close") - hi), 2), ["percentage"]: pyRound((((pyAt(last, "close") / hi) - 1) * 100), 2) }, ["distance_from_52_week_low"]: { ["amount"]: pyRound((pyAt(last, "close") - lo), 2), ["percentage"]: pyRound((((pyAt(last, "close") / lo) - 1) * 100), 2) }, ["max_drawdown"]: { ["percentage"]: pyRound((mdd * 100), 2), ["basis"]: "fixture adjusted close", ["reference_date"]: pyAt(last, "date"), ["period"]: "selected period", ["formula"]: "min(P_t / running_peak_t - 1)" }, ["_52w_coverage_status"]: "complete" }, ["series"]: series, ["calculation_definitions"]: { ["note"]: "definitions shown for layout only" }, ["data_limitations"]: [pyAt(_FIX, "fixture_warning")] };
}
export function card_metrics(company: any): any {
    let basis: any, metrics: any, mid: any, px: any, r: any, unit: any, v: any, vals: any;
    r = _seed(company.ticker);
    px = pyAdd(20, (r * 180));
    vals = { ["pe"]: [pyRound(pyAdd(6, (r * 22)), 2), "ratio", "TTM: market cap / TTM parent profit"], ["ps"]: [pyRound(pyAdd(1, (r * 6)), 2), "ratio", "TTM: market cap / TTM consolidated revenue"], ["dividend_yield"]: [pyRound(pyAdd(0.4, (r * 5)), 2), "percentage_points", "TTM cash dividends per share / raw close"], ["revenue_growth"]: [pyRound(pyAdd((-4), (r * 26)), 2), "percentage_points", "latest FY vs preceding FY consolidated revenue"], ["roe"]: [pyRound(pyAdd(4, (r * 16)), 2), "percentage_points", "fixture annual ROE"], ["interest_coverage"]: [pyRound(pyAdd(1.5, (r * 8)), 2), "multiple_x", "fixture EBIT / interest expense"] };
    metrics = {};
    for ([mid, [v, unit, basis]] of pyIter(pyMethod(vals, "items"))) {
        metrics[mid] = { ["value"]: v, ["unit"]: unit, ["status"]: "fixture", ["reason"]: "synthetic", ["reporting_period"]: (pyBool((pyIn(mid, ["revenue_growth", "roe", "interest_coverage"]))) ? "FY2024" : null), ["as_of"]: today(), ["source"]: null, ["calculation_basis"]: basis, ["benchmark"]: { ["industry_median"]: pyRound((v * pyAdd(0.8, (r * 0.5))), 2), ["peer_count"]: 42, ["status"]: "fixture", ["industry_universe_count"]: 85, ["excluded_count"]: 43, ["benchmark_period"]: today(), ["note"]: "fixture median -- not a supplied-universe SSE statistic." } };
    }
    return { ..._FIX, ["capability_id"]: "company-card-metrics", ["contract_version"]: "1.1.0", ["exchange"]: "SSE", ["company_id"]: company.ticker, ["company_name"]: company.name, ["industry_label"]: company.industry, ["provider"]: "FIXTURE", ["as_of"]: today(), ["retrieved_at"]: retrieved_at(), ["currency"]: "CNY", ["quote_as_of"]: today(), ["current_price"]: pyRound(px, 2), ["latest_completed_financial_year"]: "2024", ["metrics"]: metrics, ["statuses"]: (() => { const _comprehension3: any = {}; for (const k of pyIter(metrics)) {
            _comprehension3[k] = "fixture";
        } return _comprehension3; })(), ["universe_scope"]: { ["industry_label"]: company.industry, ["total_universe_count"]: 85, ["definition"]: "fixture universe" }, ["data_limitations"]: [pyAt(_FIX, "fixture_warning")] };
}
export function industry_research(company: any): any {
    let growth: any, i: any, r: any, totals: any, y: any, yrs: any;
    r = _seed(company.industry);
    [yrs, totals, growth] = [[], [], []];
    for (y of pyIter(pyRange(2020, 2025))) {
        pyMethod(yrs, "append", pyStr(y));
        pyMethod(totals, "append", pyRound(((800000000000.0 * pyAdd(1, r)) * pyAdd(pyAdd(1, (0.06 * (y - 2020))), (0.03 * Math.sin(pyAdd(y, (r * 9)))))), 2));
    }
    for (i of pyIter(pyRange((pyLen(totals) - 1)))) {
        pyMethod(growth, "append", { ["years"]: (pyStr(pyAt(yrs, i)) + "->" + pyStr(pyAt(yrs, pyAdd(i, 1)))), ["status"]: "fixture", ["yoy_growth_percentage_points"]: pyRound((((pyAt(totals, pyAdd(i, 1)) / pyAt(totals, i)) - 1) * 100), 2), ["matched_company_count"]: pyAdd(60, pyInt((r * 20))), ["matched_cohort_coverage_percentage"]: 74.0, ["calculation"]: "fixture matched-cohort formula" });
    }
    return { ..._FIX, ["capability_id"]: "industry-research", ["contract_version"]: "1.1.0", ["exchange"]: "SSE", ["company_id"]: company.ticker, ["company_name"]: company.name, ["industry_label"]: company.industry, ["provider"]: "FIXTURE", ["as_of"]: today(), ["retrieved_at"]: retrieved_at(), ["currency"]: "CNY", ["universe_scope"]: { ["industry_label"]: company.industry, ["total_universe_count"]: 85, ["selection"]: "fixture" }, ["status_note"]: "FIXTURE values. Even when populated these are not market size or demand evidence.", ["annual_revenue_totals"]: (() => { const _comprehension4: any = []; for (const [y, t] of pyIter(pyZip(yrs, totals))) {
            _comprehension4.push({ ["financial_year"]: y, ["aggregate_revenue_cny"]: t, ["included_company_count"]: 70, ["total_universe_count"]: 85, ["excluded_count"]: 15, ["coverage_percentage"]: 82.4, ["status"]: "fixture", ["source"]: "FIXTURE income" });
        } return _comprehension4; })(), ["matched_cohort_growth"]: growth, ["statuses"]: { ["annual_revenue"]: "fixture", ["growth"]: "fixture" }, ["excluded_scope"]: ["five-year outlook", "industry forecast", "whole-China market size", "demand/supply narrative", "material events"], ["data_limitations"]: [pyAt(_FIX, "fixture_warning")] };
}
export function news(company: any): any {
    let i: any, items: any;
    items = [];
    for (i of pyIter(pyRange(4))) {
        pyMethod(items, "append", { ["match_type"]: "company", ["title"]: ("[FIXTURE] " + pyStr(company.name) + " demo headline " + pyStr(pyAdd(i, 1))), ["publisher"]: "fixture-publisher", ["published_at"]: (pyStr(today()) + "T09:" + pyFormat(pyAdd(10, i), ("02d")) + ":00"), ["source_reference"]: { ["url"]: null }, ["provider_id"]: "FIXTURE", ["language"]: "zh", ["summary"]: "Synthetic headline for layout testing only." });
    }
    for (i of pyIter(pyRange(3))) {
        pyMethod(items, "append", { ["match_type"]: "industry", ["title"]: ("[FIXTURE] " + pyStr(company.industry) + " demo story " + pyStr(pyAdd(i, 1))), ["publisher"]: "fixture-publisher", ["published_at"]: (pyStr(today()) + "T08:" + pyFormat(pyAdd(20, i), ("02d")) + ":00"), ["source_reference"]: { ["url"]: null }, ["provider_id"]: "FIXTURE", ["language"]: "zh" });
    }
    return { ..._FIX, ["capability_id"]: "company-industry-news", ["contract_version"]: "1.1.0", ["exchange"]: "SSE", ["company_id"]: company.ticker, ["company_name"]: company.name, ["industry_label"]: company.industry, ["provider"]: "FIXTURE", ["as_of"]: today(), ["retrieved_at"]: retrieved_at(), ["currency"]: "CNY", ["query_window"]: { ["lookback_days"]: 7, ["start_date"]: today(), ["end_date"]: today() }, ["feed"]: items, ["coverage_note"]: "Fixture feed. No story is evidence of any price movement.", ["data_limitations"]: [pyAt(_FIX, "fixture_warning")] };
}
export function price_target(company: any): any {
    let avg: any, dist: any, px: any, r: any, targets: any;
    r = _seed(company.ticker);
    px = pyRound(pyAdd(20, (r * 180)), 2);
    dist = { ["Strong Sell"]: 0, ["Sell"]: 1, ["Hold"]: 2, ["Buy"]: 6, ["Strong Buy"]: 4 };
    targets = (() => { const _comprehension5: any = []; for (const i of pyIter(pyRange(5))) {
        _comprehension5.push({ ["brokerage"]: ("Fixture Securities " + pyStr(pyAdd(i, 1))), ["report_date"]: today(), ["min_price"]: pyRound((px * 1.02), 2), ["max_price"]: pyRound((px * 1.24), 2), ["midpoint"]: pyRound((px * 1.13), 2), ["currency"]: "CNY", ["verified_horizon"]: "12 months (fixture)" });
    } return _comprehension5; })();
    avg = pyRound((pySum((() => { const _comprehension6: any = []; for (const t of pyIter(targets)) {
        _comprehension6.push(pyAt(t, "midpoint"));
    } return _comprehension6; })()) / pyLen(targets)), 2);
    return { ..._FIX, ["capability_id"]: "price-target", ["contract_version"]: "1.1.0", ["exchange"]: "SSE", ["company_id"]: company.ticker, ["company_name"]: company.name, ["industry_label"]: company.industry, ["provider"]: "FIXTURE", ["as_of"]: today(), ["retrieved_at"]: retrieved_at(), ["currency"]: "CNY", ["demo_configuration"]: { ["report_lookback_calendar_days"]: 90, ["contribution_unit"]: "brokerage", ["rating_categories"]: ["Strong Sell", "Sell", "Hold", "Buy", "Strong Buy"], ["minimum_brokerages_per_target_group"]: 3 }, ["query_window"]: { ["start_date"]: today(), ["end_date"]: today(), ["note"]: "fixture window; not a target horizon" }, ["rating_distribution"]: dist, ["rating_summary"]: { ["status"]: "fixture", ["label"]: "Most common brokerage rating", ["value"]: "Buy", ["category_count"]: 6, ["total_mapped_brokerages"]: 13, ["majority"]: true }, ["latest_close"]: { ["price"]: px, ["date"]: today(), ["basis"]: "fixture raw close" }, ["eligible_brokerages_for_ratings"]: 13, ["eligible_brokerages_for_targets"]: 5, ["total_distinct_brokerages_in_window"]: 13, ["individual_source_targets"]: targets, ["target_groups"]: [{ ["horizon"]: "12 months (fixture)", ["eligible_brokerage_count"]: 5, ["average_target_midpoint"]: avg, ["implied_percentage_difference"]: pyRound((((avg / px) - 1) * 100), 2), ["quote_date"]: today(), ["source_dates"]: [today()], ["calculation"]: "fixture equal-weight mean of midpoints", ["status"]: "fixture", ["contributions"]: (() => { const _comprehension7: any = []; for (const t of pyIter(targets)) {
                    _comprehension7.push((() => { const _comprehension8: any = {}; for (const k of pyIter(["brokerage", "report_date", "min_price", "max_price", "midpoint"])) {
                        _comprehension8[k] = pyAt(t, k);
                    } return _comprehension8; })());
                } return _comprehension7; })() }], ["excluded_target_records"]: [], ["unmapped_ratings"]: [], ["count_unit"]: "brokerages (fixture)", ["horizon_policy_note"]: "fixture horizon is invented for layout only.", ["data_limitations"]: [pyAt(_FIX, "fixture_warning")] };
}
export function bundle(company: any, period: any = "1y"): any {
    let out: any;
    out = { ["company"]: company.to_dict(), ["capabilities"]: { ["historical_analysis"]: historical(company, period), ["card_metrics"]: card_metrics(company), ["industry_research"]: industry_research(company), ["company_industry_news"]: news(company), ["price_target"]: price_target(company) }, ["generated_at"]: retrieved_at(), ["timezone"]: "Asia/Shanghai", ["fixture_mode"]: true, ["fixture_warning"]: pyAt(_FIX, "fixture_warning"), ["feature_status"]: (() => { const _comprehension9: any = {}; for (const k of pyIter(["historical_analysis", "card_metrics", "industry_research", "company_industry_news", "price_target"])) {
            _comprehension9[k] = "fixture";
        } return _comprehension9; })() };
    return out;
}
