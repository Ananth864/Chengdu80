// Ported from capabilities.py. Standard-library operations use native JavaScript helpers.
import * as financial from './financial.ts';
import * as universe from './universe.ts';
import { ProviderError, d, is_configured, query, retrieved_at, today } from './tushare_client.ts';
import { PyDate, PyDelta, pyAbs, pyAdd, pyAnd, pyAny, pyAt, pyBool, pyCompare, pyDateFormat, pyDateSubtract, pyDict, pyFloat, pyIn, pyInt, pyIsinstance, pyIter, pyLen, pyList, pyMax, pyMethod, pyMin, pyMod, pyOr, pyRange, pyRound, pySet, pySlice, pySorted, pyStr, pySum, pyType, pyZip } from './runtime.ts';
export let PROVIDER = "Tushare";
export let PERIODS = { ["1m"]: 28, ["6m"]: 182, ["1y"]: 365, ["5y"]: 1825 };
export function _err(exc: any): any {
    if (pyBool(pyIsinstance(exc, ProviderError))) {
        return { ["status"]: exc.kind, ["reason"]: exc.message, ["error_code"]: exc.code };
    }
    return { ["status"]: "error", ["reason"]: "Unexpected retrieval failure.", ["error_code"]: pyType(exc).name };
}
export function _base(capability: any, company: any): any {
    return { ["capability_id"]: capability, ["contract_version"]: "1.1.0", ["exchange"]: "SSE", ["company_id"]: company.ticker, ["company_name"]: company.name, ["industry_label"]: company.industry, ["provider"]: PROVIDER, ["as_of"]: today(), ["retrieved_at"]: retrieved_at(), ["currency"]: "CNY", ["data_limitations"]: [] };
}
export async function _daily(ts_code: any, start: any, end: any): Promise<any> {
    return await query("daily", { ["ts_code"]: ts_code, ["start_date"]: start, ["end_date"]: end }, "ts_code,trade_date,open,high,low,close,pre_close,pct_chg,vol,amount");
}
/** Adjusted close series normalised to the latest trading date as reference. */
export async function _adj_closes(ts_code: any, rows: any): Promise<any> {
    let f: any, factor_rows: any, factors: any, last_compact: any, out: any, r: any, ref: any, ref_date: any;
    try {
        last_compact = pyAt(pyAt(rows, (-1)), "trade_date");
        factor_rows = await query("adj_factor", { ["ts_code"]: ts_code, ["start_date"]: pyAt(pyAt(rows, 0), "trade_date"), ["end_date"]: last_compact }, "ts_code,trade_date,adj_factor");
        factors = (() => { const _comprehension1: any = {}; for (const r of pyIter(factor_rows)) {
            _comprehension1[d(pyAt(r, "trade_date"))] = pyMethod(r, "get", "adj_factor");
        } return _comprehension1; })();
        ref_date = d(last_compact);
        ref = pyMethod(factors, "get", ref_date);
        if (pyBool(pyOr(!pyBool(ref), () => ((pyCompare(pyFloat(ref), 0) <= 0))))) {
            return { ["available"]: false, ["reason"]: "adjustment_factor_missing_for_latest_date" };
        }
        out = [];
        for (r of pyIter(rows)) {
            f = pyMethod(factors, "get", d(pyAt(r, "trade_date")));
            if (pyBool(!pyBool(f))) {
                return { ["available"]: false, ["reason"]: "adjustment_factors_incomplete_for_period" };
            }
            pyMethod(out, "append", ((pyFloat(pyAt(r, "close")) * pyFloat(f)) / pyFloat(ref)));
        }
        return { ["available"]: true, ["values"]: out, ["reference_date"]: ref_date, ["formula"]: "close * adj_factor / adj_factor(reference_date)" };
    }
    catch (__error) {
        if (__error instanceof ProviderError) {
            const exc: any = __error;
            return { ["available"]: false, ["reason"]: ("adjustment_data_unavailable (" + pyStr(exc.kind) + ")") };
        }
        else {
            throw __error;
        }
    }
}
export async function historical_analysis(company: any, period: any = "1y"): Promise<any> {
    let adj: any, as_of: any, current: any, days: any, first: any, hi52: any, latest: any, lo52: any, mdd: any, metrics: any, partial_52w: any, peak: any, prev_close: any, res: any, rows: any, series: any, start: any, ts_code: any, v: any, win: any, window_end: any, window_start: any;
    res = _base("historical-analysis", company);
    days = pyMethod(PERIODS, "get", period, pyAt(PERIODS, "1y"));
    res["requested_period"] = period;
    ts_code = (pyStr(company.ticker) + ".SH");
    as_of = today();
    start = pyDateFormat(pyDateSubtract(new PyDate(as_of), new PyDelta(days, 0)), "%Y%m%d");
    try {
        rows = await _daily(ts_code, start, pyMethod(as_of, "replace", "-", ""));
    }
    catch (__error) {
        if (true) {
            const exc: any = __error;
            pyMethod(res, "update", _err(exc));
            return res;
        }
        else {
            throw __error;
        }
    }
    if (pyBool(!pyBool(rows))) {
        res["status"] = "no_results";
        res["reason"] = "successful query returned no trading records for this period";
        return res;
    }
    rows = pySorted([rows], (r: any) => (pyAt(r, "trade_date")), false);
    series = (() => { const _comprehension2: any = []; for (const r of pyIter(rows)) {
        _comprehension2.push({ ["date"]: d(pyAt(r, "trade_date")), ["close"]: pyAt(r, "close"), ["high"]: pyAt(r, "high"), ["low"]: pyAt(r, "low"), ["open"]: pyAt(r, "open"), ["volume"]: pyAt(r, "vol") });
    } return _comprehension2; })();
    [latest, first] = [pyAt(rows, (-1)), pyAt(rows, 0)];
    res["actual_coverage_period"] = { ["start"]: d(pyAt(first, "trade_date")), ["end"]: d(pyAt(latest, "trade_date")), ["trading_days"]: pyLen(rows) };
    res["adjustment_basis"] = "metrics and chart use raw daily quotes; max drawdown uses adjusted closes";
    res["status"] = "available";
    current = pyFloat(pyAt(latest, "close"));
    prev_close = (pyBool((!pyIn(pyMethod(latest, "get", "pre_close"), [null, ""]))) ? pyFloat(pyAt(latest, "pre_close")) : null);
    window_end = d(pyAt(latest, "trade_date"));
    window_start = pyDateFormat(pyDateSubtract(new PyDate(window_end), new PyDelta(363, 0)), "%Y-%m-%d");
    win = pyOr((() => { const _comprehension3: any = []; for (const s of pyIter(series)) {
        if (!pyBool(((pyCompare(pyAt(s, "date"), window_start) >= 0))))
            continue;
        _comprehension3.push(s);
    } return _comprehension3; })(), () => series);
    partial_52w = ((pyCompare(pyAt(pyAt(win, 0), "date"), window_start) > 0));
    hi52 = pyMax([(() => { const _comprehension4: any = []; for (const s of pyIter(win)) {
            _comprehension4.push(pyAt(s, "high"));
        } return _comprehension4; })()], null, false);
    lo52 = pyMin([(() => { const _comprehension5: any = []; for (const s of pyIter(win)) {
            _comprehension5.push(pyAt(s, "low"));
        } return _comprehension5; })()], null, false);
    metrics = { ["current_price"]: current, ["52_week_high"]: hi52, ["52_week_low"]: lo52, ["available_period_high"]: pyMax([(() => { const _comprehension6: any = []; for (const s of pyIter(series)) {
                _comprehension6.push(pyAt(s, "high"));
            } return _comprehension6; })()], null, false), ["available_period_low"]: pyMin([(() => { const _comprehension7: any = []; for (const s of pyIter(series)) {
                _comprehension7.push(pyAt(s, "low"));
            } return _comprehension7; })()], null, false), ["daily_change_amount"]: (pyBool(prev_close) ? pyRound((current - prev_close), 4) : null), ["daily_change_percentage"]: (pyBool(prev_close) ? pyRound((((current - prev_close) / prev_close) * 100), 4) : null), ["distance_from_52_week_high"]: { ["amount"]: pyRound((current - hi52), 4), ["percentage"]: (pyBool(hi52) ? pyRound((((current / hi52) - 1) * 100), 4) : null) }, ["distance_from_52_week_low"]: { ["amount"]: pyRound((current - lo52), 4), ["percentage"]: (pyBool(lo52) ? pyRound((((current / lo52) - 1) * 100), 4) : null) } };
    adj = await _adj_closes(ts_code, rows);
    if (pyBool(pyAnd(pyMethod(adj, "get", "available"), () => ((pyCompare(pyLen(rows), 2) >= 0))))) {
        [peak, mdd] = [pyAt(pyAt(adj, "values"), 0), 0.0];
        for (v of pyIter(pyAt(adj, "values"))) {
            peak = pyMax([peak, v], null, false);
            if (pyBool(((pyCompare(peak, 0) > 0)))) {
                mdd = pyMin([mdd, ((v / peak) - 1)], null, false);
            }
        }
        metrics["max_drawdown"] = { ["percentage"]: pyRound((mdd * 100), 4), ["basis"]: "adjusted close", ["reference_date"]: pyAt(adj, "reference_date"), ["formula"]: pyAt(adj, "formula"), ["period"]: (pyStr(window_start) + " to " + pyStr(window_end) + " (selected period)") };
    }
    else {
        metrics["max_drawdown"] = { ["percentage"]: null, ["status"]: "unavailable", ["reason"]: pyMethod(adj, "get", "reason", "insufficient_valid_observations") };
    }
    res["metrics"] = metrics;
    res["series"] = series;
    res["calculation_definitions"] = { ["52_week_window"]: "364 calendar days ending on the latest quote date (inclusive)", ["daily_change"]: "latest close vs previous trading session close", ["max_drawdown"]: "min(P_t / running_peak_t - 1) on adjusted closes" };
    if (pyBool(partial_52w)) {
        res["coverage_note"] = ("52-week metrics are partial: retrieved history starts at " + pyStr(pyAt(pyAt(win, 0), "date")) + ", after the window opening.");
        pyMethod(pyAt(res, "data_limitations"), "append", pyAt(res, "coverage_note"));
        metrics["_52w_coverage_status"] = "partial";
    }
    else {
        res["coverage_note"] = "52-week window fully covered by retrieved history.";
        metrics["_52w_coverage_status"] = "complete";
    }
    return res;
}
export async function _daily_basic_on(trade_date: any): Promise<any> {
    let rows: any;
    rows = await query("daily_basic", { ["trade_date"]: pyMethod(trade_date, "replace", "-", "") }, "ts_code,trade_date,close,pe_ttm,ps_ttm,dv_ratio,total_mv");
    return (() => { const _comprehension8: any = {}; for (const r of pyIter(rows)) {
        if (!pyBool(pyMethod(r, "get", "trade_date")))
            continue;
        _comprehension8[pyAt(r, "ts_code")] = r;
    } return _comprehension8; })();
}
export async function _annual_batch(period_compact: any): Promise<any> {
    let out: any, r: any, rows: any, val: any;
    rows = await query("income", { ["period"]: period_compact }, "ts_code,end_date,ann_date,report_type,total_revenue,revenue");
    out = {};
    for (r of pyIter(rows)) {
        if (pyBool((!pyIn(pyStr(pyOr(pyMethod(r, "get", "report_type"), () => "1")), ["1", "4"])))) {
            continue;
        }
        val = pyMethod(r, "get", "total_revenue");
        if (pyBool((pyIn(val, [null, ""])))) {
            val = pyMethod(r, "get", "revenue");
        }
        if (pyBool((pyIn(val, [null, ""])))) {
            continue;
        }
        pyMethod(out, "setdefault", pyAt(r, "ts_code"), pyFloat(val));
    }
    return out;
}
export function _median(values: any): any {
    let n: any, s: any;
    if (pyBool(!pyBool(values))) {
        return null;
    }
    s = pySorted([values], null, false);
    n = pyLen(s);
    return (pyBool(pyMod(n, 2)) ? pyAt(s, Math.floor(n / 2)) : (pyAdd(pyAt(s, (Math.floor(n / 2) - 1)), pyAt(s, Math.floor(n / 2))) / 2));
}
export function _benchmark(peers: any, universe_count: any, excluded: any, basis: any, minimum: any = 5): any {
    let eligible: any, note: any;
    eligible = (() => { const _comprehension9: any = []; for (const v of pyIter(peers)) {
        if (!pyBool(pyAnd(pyIsinstance(v, [Number, Number]), () => pyAnd(((v === v)), () => ((pyAbs(v) !== pyFloat("inf")))))))
            continue;
        _comprehension9.push(pyFloat(v));
    } return _comprehension9; })();
    note = "Supplied-universe SSE industry median -- NOT a whole-China industry benchmark. Universe = all validated SSE A-share companies in the supplied CSV sharing the exact industry label; the selected company is included when eligible.";
    if (pyBool(((pyCompare(pyLen(eligible), minimum) < 0)))) {
        return { ["industry_median"]: null, ["peer_count"]: pyLen(eligible), ["status"]: "insufficient_data", ["reason"]: "insufficient_comparable_peers", ["industry_universe_count"]: universe_count, ["excluded_count"]: excluded, ["note"]: note, ...basis };
    }
    return { ["industry_median"]: pyRound(_median(eligible), 4), ["peer_count"]: pyLen(eligible), ["status"]: "available", ["industry_universe_count"]: universe_count, ["excluded_count"]: excluded, ["note"]: note, ["calculation"]: "median of eligible sorted values", ...basis };
}
/** Six company-card metrics: documented Tushare ratios first, defined fallbacks. */
export async function card_metrics(company: any, quote_date: any = null): Promise<any> {
    let a: any, ann_missing: any, annual_vals: any, as_of: any, b: any, basic_rows: any, basis_txt: any, cur_b: any, field: any, field_map: any, fin: any, fn: any, fy: any, hist: any, me: any, metrics: any, mid: any, miss: any, peers_ts: any, prev_b: any, quote_basis: any, r: any, res: any, row: any, skeleton: any, ts: any, ts_code: any, unit: any, v: any, val: any, vals: any, why: any, years: any;
    res = _base("company-card-metrics", company);
    ts_code = (pyStr(company.ticker) + ".SH");
    as_of = today();
    metrics = {};
    if (pyBool(!pyBool(is_configured()))) {
        skeleton = { ["pe"]: ["ratio", "TTM: total company equity market cap / TTM net profit attributable to parent"], ["ps"]: ["ratio", "TTM: total company equity market cap / TTM consolidated revenue"], ["dividend_yield"]: ["percentage_points", "TTM gross cash dividends per share actually paid / latest raw close"], ["revenue_growth"]: ["percentage_points", "latest published completed FY vs preceding FY, consolidated total revenue"], ["roe"]: ["percentage_points", "provider annual ROE where available, else simple-average fallback"], ["interest_coverage"]: ["multiple_x", "annual EBIT / annual interest expense"] };
        res["metrics"] = (() => { const _comprehension10: any = {}; for (const [mid, [unit, basis]] of pyIter(pyMethod(skeleton, "items"))) {
            _comprehension10[mid] = { ["value"]: null, ["unit"]: unit, ["status"]: "unavailable", ["reason"]: "provider_not_configured", ["reporting_period"]: null, ["as_of"]: null, ["source"]: null, ["calculation_basis"]: basis, ["benchmark"]: { ["industry_median"]: null, ["peer_count"]: 0, ["status"]: "unavailable", ["reason"]: "provider_not_configured", ["industry_universe_count"]: pyLen(universe.industry_members(company.industry)) } };
        } return _comprehension10; })();
        res["status"] = "provider_not_configured";
        res["reason"] = "No Tushare token configured for the backend. Metric values require authenticated retrieval and are never estimated.";
        res["statuses"] = (() => { const _comprehension11: any = {}; for (const k of pyIter(skeleton)) {
            _comprehension11[k] = "unavailable";
        } return _comprehension11; })();
        res["universe_scope"] = { ["industry_label"]: company.industry, ["total_universe_count"]: pyLen(universe.industry_members(company.industry)), ["definition"]: "exact CSV industry label match, no market-cap size filter" };
        return res;
    }
    peers_ts = (() => { const _comprehension12: any = []; for (const c of pyIter(universe.industry_members(company.industry))) {
        _comprehension12.push((pyStr(c.ticker) + ".SH"));
    } return _comprehension12; })();
    basic_rows = {};
    try {
        if (pyBool(!pyBool(quote_date))) {
            hist = await _daily(ts_code, pyDateFormat(pyDateSubtract(new PyDate(as_of), new PyDelta(12, 0)), "%Y%m%d"), pyMethod(as_of, "replace", "-", ""));
            quote_date = (pyBool(hist) ? d(pyMax([(() => { const _comprehension13: any = []; for (const r of pyIter(hist)) {
                    _comprehension13.push(pyAt(r, "trade_date"));
                } return _comprehension13; })()], null, false)) : null);
        }
        if (pyBool(quote_date)) {
            basic_rows = await _daily_basic_on(quote_date);
        }
    }
    catch (__error) {
        if (true) {
            const exc: any = __error;
            pyMethod(pyAt(res, "data_limitations"), "append", ("daily_basic: " + pyStr(pyAt(_err(exc), "status")) + " - " + pyStr(pyAt(_err(exc), "reason"))));
        }
        else {
            throw __error;
        }
    }
    me = pyMethod(basic_rows, "get", ts_code, {});
    res["quote_as_of"] = quote_date;
    res["current_price"] = pyMethod(me, "get", "close");
    for ([mid, field, unit, basis_txt] of pyIter([["pe", "pe_ttm", "ratio", "TTM: total company equity market cap / TTM net profit attributable to parent"], ["ps", "ps_ttm", "ratio", "TTM: total company equity market cap / TTM consolidated revenue"], ["dividend_yield", "dv_ratio", "percentage_points", "TTM gross cash dividends per share actually paid / latest raw close"]])) {
        val = pyMethod(me, "get", field);
        if (pyBool((pyIn(val, [null, ""])))) {
            metrics[mid] = { ["value"]: null, ["unit"]: unit, ["status"]: "unavailable", ["reason"]: "ratio_field_not_returned_by_source", ["reporting_period"]: null, ["as_of"]: quote_date, ["source"]: null, ["calculation_basis"]: basis_txt };
        }
        else {
            metrics[mid] = { ["value"]: pyRound(pyFloat(val), 4), ["unit"]: unit, ["status"]: "available", ["source"]: ("Tushare daily_basic." + pyStr(field)), ["as_of"]: quote_date, ["provenance"]: "retrieved", ["calculation_basis"]: basis_txt };
        }
    }
    if (pyBool(((pyAt(pyAt(metrics, "dividend_yield"), "status") === "available")))) {
        pyAt(metrics, "dividend_yield")["label"] = "TTM cash dividend yield";
    }
    fin = { ["income"]: {}, ["balance"]: {}, ["ratios"]: {}, ["as_of"]: as_of, ["currency"]: "CNY" };
    try {
        fin = await financial.fetch_company_financials(ts_code, as_of);
    }
    catch (__error) {
        if (true) {
            const exc: any = __error;
            pyMethod(pyAt(res, "data_limitations"), "append", ("statements: " + pyStr(pyAt(_err(exc), "status")) + " - " + pyStr(pyAt(_err(exc), "reason"))));
        }
        else {
            throw __error;
        }
    }
    years = financial.annual_years(fin);
    fy = (pyBool(years) ? pyAt(years, (-1)) : null);
    res["latest_completed_financial_year"] = fy;
    function _growth(row: any): any {
        let cur_v: any, prev: any, prior_v: any;
        if (pyBool(!pyBool(row))) {
            return [null, "no_published_annual_statement"];
        }
        prev = financial.annual(fin, pyStr((pyInt(pyAt(row, "year")) - 1)));
        if (pyBool(!pyBool(prev))) {
            return [null, "no_consecutive_comparable_years"];
        }
        [cur_v, prior_v] = [pyMethod(row, "get", "revenue"), pyMethod(prev, "get", "revenue")];
        if (pyBool(pyOr(((cur_v === null)), () => pyOr(((prior_v === null)), () => ((pyCompare(prior_v, 0) <= 0)))))) {
            return [null, "missing_or_nonpositive_prior_year_revenue"];
        }
        return [pyRound((((cur_v / prior_v) - 1) * 100), 4), null];
    }
    function _roe(row: any): any {
        let avg_eq: any, prior: any;
        if (pyBool(!pyBool(row))) {
            return [null, "no_published_annual_statement"];
        }
        if (pyBool(((pyMethod(row, "get", "roe_provider") !== null)))) {
            return [pyRound(pyAt(row, "roe_provider"), 4), null];
        }
        prior = financial.annual(fin, pyStr((pyInt(pyAt(row, "year")) - 1)));
        if (pyBool(pyOr(((pyMethod(row, "get", "parent_profit") === null)), () => !pyBool(prior)))) {
            return [null, "insufficient_inputs"];
        }
        if (pyBool(pyOr(!pyBool(pyMethod(row, "get", "equity")), () => !pyBool(pyMethod(prior, "get", "equity"))))) {
            return [null, "missing_comparable_equity"];
        }
        avg_eq = (pyAdd(pyAt(row, "equity"), pyAt(prior, "equity")) / 2);
        if (pyBool(((pyCompare(avg_eq, 0) <= 0)))) {
            return [null, "nonpositive_average_equity"];
        }
        return [pyRound(((pyAt(row, "parent_profit") / avg_eq) * 100), 4), "simple_average_roe_fallback"];
    }
    function _coverage(row: any): any {
        let ebit: any, ebit_field: any, ie: any, pre: any;
        if (pyBool(!pyBool(row))) {
            return [null, "no_published_annual_statement"];
        }
        ie = pyMethod(row, "get", "interest_expense");
        if (pyBool(pyOr(((ie === null)), () => ((pyCompare(ie, 0) <= 0))))) {
            return [null, "interest_expense_unavailable_or_nonpositive"];
        }
        [pre, ebit_field] = [pyMethod(row, "get", "pre_tax"), pyMethod(row, "get", "ebit")];
        ebit = (pyBool(((pre !== null))) ? pyAdd(pre, ie) : ebit_field);
        if (pyBool(((ebit === null)))) {
            return [null, "ebit_inputs_unavailable"];
        }
        return [pyRound((ebit / ie), 4), null];
    }
    for ([mid, fn, unit, basis_txt] of pyIter([["revenue_growth", _growth, "percentage_points", "latest published completed FY vs preceding FY, consolidated total revenue"], ["roe", _roe, "percentage_points", "provider annual ROE where available, else simple-average of opening/closing parent equity"], ["interest_coverage", _coverage, "multiple_x", "annual EBIT / annual interest expense; EBIT = profit before tax + interest expense"]])) {
        row = (pyBool(fy) ? financial.annual(fin, fy) : null);
        [val, why] = fn(row);
        metrics[mid] = { ["value"]: val, ["unit"]: unit, ["status"]: (pyBool(((val !== null))) ? "available" : "unavailable"), ["reason"]: why, ["reporting_period"]: fy, ["source"]: (pyBool(pyAnd(((mid === "roe")), () => pyAnd(((why === null)), () => pyAnd(row, () => ((pyMethod(row, "get", "roe_provider") !== null)))))) ? "Tushare fina_indicator" : "Tushare income/balancesheet"), ["as_of"]: (pyBool(row) ? pyMethod(row, "get", "published") : null), ["source_publication_date"]: (pyBool(row) ? pyMethod(row, "get", "published") : null), ["provenance"]: (pyBool(pyAnd(((mid === "roe")), () => pyAnd(((why === null)), () => pyAnd(row, () => ((pyMethod(row, "get", "roe_provider") !== null)))))) ? "retrieved" : "calculated"), ["calculation_basis"]: basis_txt };
    }
    quote_basis = { ["benchmark_period"]: quote_date, ["benchmark_calculation_basis"]: "identical provider ratio and one common quote date" };
    field_map = { ["pe"]: "pe_ttm", ["ps"]: "ps_ttm", ["dividend_yield"]: "dv_ratio" };
    for (mid of pyIter(["pe", "ps", "dividend_yield"])) {
        pyAt(metrics, mid)["_peer_vals"] = [];
        pyAt(metrics, mid)["_peer_missing"] = 0;
    }
    for (ts of pyIter(peers_ts)) {
        r = pyMethod(basic_rows, "get", ts);
        if (pyBool(!pyBool(r))) {
            for (mid of pyIter(["pe", "ps", "dividend_yield"])) {
                pyAt(metrics, mid)["_peer_missing"] += 1;
            }
            continue;
        }
        for (mid of pyIter(["pe", "ps", "dividend_yield"])) {
            v = pyMethod(r, "get", pyAt(field_map, mid));
            if (pyBool((pyIn(v, [null, ""])))) {
                pyMethod(pyAt(metrics, mid), "setdefault", "_peer_missing", 0);
                pyAt(metrics, mid)["_peer_missing"] += 1;
            }
            else {
                pyMethod(pyMethod(pyAt(metrics, mid), "setdefault", "_peer_vals", []), "append", pyFloat(v));
            }
        }
    }
    for (mid of pyIter(["pe", "ps", "dividend_yield"])) {
        vals = pyMethod(pyAt(metrics, mid), "pop", "_peer_vals", []);
        miss = pyMethod(pyAt(metrics, mid), "pop", "_peer_missing", 0);
        pyAt(metrics, mid)["benchmark"] = _benchmark(vals, pyLen(peers_ts), miss, quote_basis);
    }
    annual_vals = [];
    ann_missing = 0;
    if (pyBool(fy)) {
        try {
            cur_b = await _annual_batch((pyStr(fy) + "1231"));
            prev_b = await _annual_batch((pyStr((pyInt(fy) - 1)) + "1231"));
            for (ts of pyIter(peers_ts)) {
                [a, b] = [pyMethod(cur_b, "get", ts), pyMethod(prev_b, "get", ts)];
                if (pyBool(pyAnd(((a !== null)), () => pyAnd(((b !== null)), () => ((pyCompare(b, 0) > 0)))))) {
                    pyMethod(annual_vals, "append", (((a / b) - 1) * 100));
                }
                else {
                    ann_missing += 1;
                }
            }
        }
        catch (__error) {
            if (true) {
                const exc: any = __error;
                pyMethod(pyAt(res, "data_limitations"), "append", ("peer annual: " + pyStr(pyAt(_err(exc), "status"))));
            }
            else {
                throw __error;
            }
        }
    }
    pyAt(metrics, "revenue_growth")["benchmark"] = _benchmark(annual_vals, pyLen(peers_ts), ann_missing, { ["benchmark_period"]: (pyBool(fy) ? ("FY " + pyStr(fy)) : null), ["benchmark_calculation_basis"]: "same financial year, consecutive-year consolidated revenue growth" });
    for ([mid, why] of pyIter([["roe", "peer_annual_roe_batch_not_retrieved_in_demo"], ["interest_coverage", "peer_interest_coverage_requires_comparable_expense_fields"]])) {
        pyAt(metrics, mid)["benchmark"] = { ["industry_median"]: null, ["peer_count"]: 0, ["status"]: "unavailable", ["reason"]: why, ["industry_universe_count"]: pyLen(peers_ts), ["note"]: "Company value is still shown when supported; no benchmark marker is drawn for it." };
    }
    res["metrics"] = metrics;
    res["universe_scope"] = { ["industry_label"]: company.industry, ["total_universe_count"]: pyLen(peers_ts), ["definition"]: "exact CSV industry label match, no market-cap size filter" };
    res["statuses"] = (() => { const _comprehension14: any = {}; for (const [k, v] of pyIter(pyMethod(metrics, "items"))) {
        _comprehension14[k] = pyAt(v, "status");
    } return _comprehension14; })();
    if (pyBool(!pyBool(basic_rows))) {
        pyMethod(pyAt(res, "data_limitations"), "append", "No daily_basic snapshot for the quote date: valuation and dividend benchmarks unavailable.");
    }
    res["status"] = (pyBool(pyAny((() => { const _comprehension15: any = []; for (const m of pyIter(pyMethod(metrics, "values"))) {
        _comprehension15.push(((pyAt(m, "status") === "available")));
    } return _comprehension15; })())) ? "available" : "unavailable");
    return res;
}
/** Listed-company industry statistics for the supplied SSE universe.
 *
 * Historical annual revenue only: no market size, no demand/supply narrative,
 * no forecast or five-year outlook (demo scope). */
export async function industry_research(company: any): Promise<any> {
    let as_of: any, batch: any, cohort: any, count: any, cur_batch: any, cur_sum: any, cur_y: any, e: any, end_compact: any, growth: any, pairs: any, peers: any, period: any, prev_batch: any, prev_sum: any, prev_y: any, pub_ok: any, res: any, retrieval_errors: any, start_year: any, total: any, v: any, vals: any, year: any, year_totals: any, years_sorted: any;
    res = _base("industry-research", company);
    res["asset_scope"] = "Listed-company industry statistics for the supplied SSE A-share universe only";
    peers = universe.industry_members(company.industry);
    res["universe_scope"] = { ["industry_label"]: company.industry, ["total_universe_count"]: pyLen(peers), ["selection"]: "exact CSV industry label, no market-cap size filter" };
    res["status_note"] = "These are reported revenue totals of listed companies in the supplied SSE universe. They are not mainland-China market size, not total industry revenue, and not demand or supply evidence.";
    if (pyBool(!pyBool(is_configured()))) {
        res["status"] = "provider_not_configured";
        res["reason"] = "No Tushare token configured: annual consolidated statements cannot be retrieved, so no aggregate or growth value exists to display.";
        res["annual_revenue_totals"] = [];
        res["matched_cohort_growth"] = [];
        res["statuses"] = { ["annual_revenue"]: "unavailable", ["growth"]: "unavailable" };
        res["excluded_scope"] = ["five-year outlook", "industry forecast", "whole-China market size", "demand/supply narrative", "material events"];
        return res;
    }
    as_of = today();
    end_compact = pyMethod(as_of, "replace", "-", "");
    start_year = (pyInt(pySlice(as_of, null, 4)) - 6);
    year_totals = {};
    retrieval_errors = [];
    for (year of pyIter(pyRange(pyAdd(start_year, 1), pyInt(pySlice(as_of, null, 4))))) {
        period = (pyStr(year) + "1231");
        if (pyBool(((pyCompare(period, end_compact) > 0)))) {
            continue;
        }
        try {
            batch = await _annual_batch(period);
        }
        catch (__error) {
            if (true) {
                const exc: any = __error;
                e = _err(exc);
                pyMethod(retrieval_errors, "append", ("FY" + pyStr(year) + ": " + pyStr(pyAt(e, "status"))));
                year_totals[pyStr(year)] = { ["status"]: pyAt(e, "status"), ["reason"]: pyAt(e, "reason"), ["aggregate_revenue"]: null, ["included_company_count"]: 0 };
                continue;
            }
            else {
                throw __error;
            }
        }
        vals = (() => { const _comprehension16: any = []; for (const [ts, v] of pyIter(pyMethod(batch, "items"))) {
            if (!pyBool((pyIn(ts, (() => { const _comprehension17: any = []; for (const c of pyIter(peers)) {
                _comprehension17.push((pyStr(c.ticker) + ".SH"));
            } return new Set(_comprehension17); })()))))
                continue;
            _comprehension16.push(v);
        } return _comprehension16; })();
        pub_ok = 0;
        total = 0.0;
        for (v of pyIter(vals)) {
            total += v;
            pub_ok += 1;
        }
        count = pyLen(peers);
        year_totals[pyStr(year)] = { ["financial_year"]: pyStr(year), ["aggregate_revenue_cny"]: (pyBool(pub_ok) ? pyRound(total, 2) : null), ["included_company_count"]: pub_ok, ["total_universe_count"]: count, ["excluded_count"]: (count - pub_ok), ["coverage_percentage"]: (pyBool(count) ? pyRound(((pub_ok / count) * 100), 2) : null), ["status"]: (pyBool(((pub_ok === count))) ? "available" : (pyBool(pub_ok) ? "partial" : "no_results")), ["partial_coverage_note"]: (pyBool(((pub_ok === count))) ? null : "Partial coverage: companies without a published consolidated annual total_revenue statement are excluded, never replaced with zero."), ["source"]: ("Tushare income (consolidated, report_type 1/4), periods published by " + pyStr(as_of)) };
    }
    years_sorted = pySorted([(() => { const _comprehension18: any = []; for (const y of pyIter(year_totals)) {
            if (!pyBool(pyMethod(pyAt(year_totals, y), "get", "aggregate_revenue_cny")))
                continue;
            _comprehension18.push(y);
        } return _comprehension18; })()], null, false);
    growth = [];
    pairs = pyList(pyZip(years_sorted, pySlice(years_sorted, 1, null)));
    for ([prev_y, cur_y] of pyIter(pairs)) {
        try {
            prev_batch = await _annual_batch((pyStr(prev_y) + "1231"));
            cur_batch = await _annual_batch((pyStr(cur_y) + "1231"));
        }
        catch (__error) {
            if (true) {
                const exc: any = __error;
                pyMethod(growth, "append", { ["years"]: (pyStr(prev_y) + "->" + pyStr(cur_y)), ["status"]: pyAt(_err(exc), "status"), ["yoy_growth_percentage_points"]: null });
                continue;
            }
            else {
                throw __error;
            }
        }
        cohort = (() => { const _comprehension19: any = []; for (const ts of pyIter(prev_batch)) {
            if (!pyBool(pyAnd((pyIn(ts, cur_batch)), () => pyAnd(((pyCompare(pyAt(prev_batch, ts), 0) > 0)), () => ((pyAt(cur_batch, ts) !== null))))))
                continue;
            _comprehension19.push(ts);
        } return _comprehension19; })();
        if (pyBool(!pyBool(cohort))) {
            pyMethod(growth, "append", { ["years"]: (pyStr(prev_y) + "->" + pyStr(cur_y)), ["status"]: "insufficient_data", ["yoy_growth_percentage_points"]: null, ["reason"]: "no_matched_comparable_observations" });
            continue;
        }
        prev_sum = pySum((() => { const _comprehension20: any = []; for (const ts of pyIter(cohort)) {
            _comprehension20.push(pyAt(prev_batch, ts));
        } return _comprehension20; })());
        cur_sum = pySum((() => { const _comprehension21: any = []; for (const ts of pyIter(cohort)) {
            _comprehension21.push(pyAt(cur_batch, ts));
        } return _comprehension21; })());
        pyMethod(growth, "append", { ["years"]: (pyStr(prev_y) + "->" + pyStr(cur_y)), ["yoy_growth_percentage_points"]: pyRound((((cur_sum / prev_sum) - 1) * 100), 4), ["matched_company_count"]: pyLen(cohort), ["matched_cohort_coverage_percentage"]: (pyBool(peers) ? pyRound(((pyLen(cohort) / pyLen(peers)) * 100), 2) : null), ["status"]: "available", ["calculation"]: pyMod("(sum matched-cohort FY%s revenue / sum matched-cohort FY%s revenue - 1) * 100", [cur_y, prev_y]), ["cohort_note"]: "Matched cohort only: companies reporting comparable consolidated revenue in both years. Cohort membership can differ between year pairs; this is not calculated from yearly totals whose membership differs." });
    }
    res["annual_revenue_totals"] = (() => { const _comprehension22: any = []; for (const year_values of pyIter((() => { const _comprehension23: any = []; for (const y of pyIter(pySorted([year_totals], null, false))) {
        _comprehension23.push(pyAt(year_totals, y));
    } return _comprehension23; })())) {
        _comprehension22.push(year_values);
    } return _comprehension22; })();
    res["matched_cohort_growth"] = growth;
    res["retrieval_errors"] = retrieval_errors;
    res["statuses"] = { ["annual_revenue"]: (pyBool(years_sorted) ? "available" : (pyBool(retrieval_errors) ? "error" : "unavailable")), ["growth"]: (pyBool(pyAny((() => { const _comprehension24: any = []; for (const g of pyIter(growth)) {
            _comprehension24.push(((pyAt(g, "status") === "available")));
        } return _comprehension24; })())) ? "available" : "insufficient_data") };
    if (pyBool(!pyBool(years_sorted))) {
        res["status"] = "unavailable";
        res["reason"] = (pyBool(retrieval_errors) ? pyAt(retrieval_errors, 0) : "no comparable annual consolidated revenue statements retrieved");
    }
    else {
        res["status"] = "available";
    }
    res["excluded_scope"] = ["five-year outlook", "industry forecast", "whole-China market size", "demand/supply narrative", "material events"];
    return res;
}
export async function company_industry_news(company: any, lookback_days: any = 7, max_company_items: any = 5, max_industry_items: any = 5): Promise<any> {
    let company_items: any, end: any, errors: any, first: any, industry_items: any, it: any, items: any, res: any, seen: any, start: any;
    res = _base("company-industry-news", company);
    res["query_window"] = { ["lookback_days"]: lookback_days };
    if (pyBool(((pyCompare(lookback_days, 180) > 0)))) {
        res["status"] = "unsupported_data";
        res["reason"] = "demo news window is capped at 180 days";
        return res;
    }
    start = pyDateFormat(pyDateSubtract(new PyDate(today()), new PyDelta(lookback_days, 0)), "%Y%m%d");
    end = pyMethod(today(), "replace", "-", "");
    pyAt(res, "query_window")["start_date"] = d(start);
    pyAt(res, "query_window")["end_date"] = d(end);
    items = [];
    errors = [];
    async function pull(api: any, params: any, label: any, limit: any, title_key: any, url_key: any, time_key: any, src_key: any): Promise<any> {
        let e: any, out: any, pub: any, r: any, rows: any, title: any, url: any;
        try {
            rows = await query(api, params);
        }
        catch (__error) {
            if (true) {
                const exc: any = __error;
                e = _err(exc);
                pyMethod(errors, "append", (pyStr(api) + ": " + pyStr(pyAt(e, "status")) + " - " + pyStr(pyAt(e, "reason"))));
                return [];
            }
            else {
                throw __error;
            }
        }
        out = [];
        for (r of pyIter(rows)) {
            title = pyMethod(pyOr(pyMethod(r, "get", title_key), () => ""), "strip");
            url = pyMethod(pyOr(pyMethod(r, "get", url_key), () => ""), "strip");
            pub = pyMethod(r, "get", time_key);
            if (pyBool(!pyBool(title))) {
                continue;
            }
            pyMethod(out, "append", { ["match_type"]: label, ["title"]: title, ["publisher"]: pyOr(pyMethod(pyOr(pyMethod(r, "get", src_key), () => ""), "strip"), () => null), ["published_at"]: (pyBool(pub) ? pySlice(pyStr(pub), null, 19) : null), ["source_reference"]: { ["url"]: pyOr(url, () => null) }, ["provider_id"]: PROVIDER, ["language"]: "zh", ["summary"]: null });
            if (pyBool(((pyCompare(pyLen(out), limit) >= 0)))) {
                break;
            }
        }
        return out;
    }
    seen = pySet();
    function dedup(lst: any): any {
        let it: any, k: any, keep: any;
        keep = [];
        for (it of pyIter(lst)) {
            k = pyOr(pyAt(pyAt(it, "source_reference"), "url"), () => [pyAt(it, "title"), pyAt(it, "published_at")]);
            if (pyBool((pyIn(k, seen)))) {
                continue;
            }
            seen.add(k);
            pyMethod(keep, "append", it);
        }
        return keep;
    }
    company_items = dedup(await pull("news", { ["ts_code"]: (pyStr(company.ticker) + ".SH"), ["start_date"]: start, ["end_date"]: end, ["src"]: "" }, "company", max_company_items, "title", "url", "time", "src"));
    industry_items = dedup(await pull("news", { ["ts_code"]: "", ["start_date"]: start, ["end_date"]: end, ["src"]: "" }, "industry", max_industry_items, "title", "url", "time", "src"));
    for (it of pyIter(industry_items)) {
        if (pyBool(pyAnd(pySlice(company.name, null, 4), () => (pyIn(pySlice(company.name, null, 4), pyAt(it, "title")))))) {
            it["match_type"] = "company";
            it["also_matches_industry"] = true;
        }
    }
    items = pySorted([pyAdd(company_items, industry_items)], (i: any) => (pyOr(pyAt(i, "published_at"), () => "")), true);
    res["feed"] = items;
    res["errors"] = errors;
    res["coverage_note"] = "Company matching uses the validated ticker; industry matching uses the exact CSV label. No causal link between any story and price movement is implied.";
    if (pyBool(pyAnd(errors, () => !pyBool(items)))) {
        first = pyAt(errors, 0);
        res["status"] = (pyBool((pyIn("permission_denied", first))) ? "permission_denied" : (pyBool((pyIn("provider_not_configured", first))) ? "provider_not_configured" : "error"));
        res["reason"] = "news retrieval failed; this is not an empty feed";
    }
    else {
        if (pyBool(!pyBool(items))) {
            res["status"] = "no_results";
            res["reason"] = "successful query returned no matching items in the window";
        }
        else {
            res["status"] = (pyBool(((pyCompare(pyLen(items), 2) >= 0))) ? "available" : "partial");
        }
    }
    return res;
}
export let RATING_MAP = { ["买入"]: "Buy", ["推荐"]: "Strong Buy", ["强推"]: "Strong Buy", ["增持"]: "Buy", ["中性"]: "Hold", ["持有"]: "Hold", ["减持"]: "Sell", ["卖出"]: "Sell", ["回避"]: "Sell" };
export let RATING_ORDER = ["Strong Sell", "Sell", "Hold", "Buy", "Strong Buy"];
export let REPORT_WINDOW_DAYS = 90;
export let MIN_BROKERAGES_PER_TARGET_GROUP = 3;
export async function price_target(company: any): Promise<any> {
    let ambiguous_orgs: any, as_of: any, avg: any, best: any, by_org: any, cat: any, cur: any, dist: any, entry: any, excluded_targets: any, g: any, groups: any, hi: any, hi_f: any, hist: any, horizon: any, individual: any, key: any, lo: any, lo_f: any, mapped: any, members: any, org: any, out: any, quote: any, r: any, raw: any, rd: any, res: any, rows: any, start: any, summary: any, target_groups: any, tied: any, top: any, unmapped: any;
    res = _base("price-target", company);
    res["demo_configuration"] = { ["report_lookback_calendar_days"]: REPORT_WINDOW_DAYS, ["contribution_unit"]: "brokerage", ["rating_summary_method"]: "mode; ties = Mixed; zero mapped opinions = unavailable", ["target_summary_method"]: "arithmetic mean of each eligible brokerage target-range midpoint", ["minimum_brokerages_per_target_group"]: MIN_BROKERAGES_PER_TARGET_GROUP };
    as_of = today();
    start = pyDateFormat(pyDateSubtract(new PyDate(as_of), new PyDelta((REPORT_WINDOW_DAYS - 1), 0)), "%Y-%m-%d");
    res["query_window"] = { ["start_date"]: start, ["end_date"]: as_of, ["note"]: "Report freshness window; NOT a target-price horizon." };
    try {
        rows = await query("report_rc", { ["ts_code"]: (pyStr(company.ticker) + ".SH"), ["start_date"]: pyMethod(start, "replace", "-", ""), ["end_date"]: pyMethod(as_of, "replace", "-", "") }, "ts_code,report_date,report_title,org_name,author_name,quarter,rating,max_price,min_price");
    }
    catch (__error) {
        if (true) {
            const exc: any = __error;
            pyMethod(res, "update", _err(exc));
            return res;
        }
        else {
            throw __error;
        }
    }
    if (pyBool(!pyBool(rows))) {
        res["status"] = "no_results";
        res["reason"] = "no broker research reports dated inside the 90-day window";
        res["rating_distribution"] = (() => { const _comprehension25: any = {}; for (const k of pyIter(RATING_ORDER)) {
            _comprehension25[k] = 0;
        } return _comprehension25; })();
        res["target_groups"] = [];
        return res;
    }
    by_org = {};
    ambiguous_orgs = [];
    for (r of pyIter(rows)) {
        rd = d(pyMethod(r, "get", "report_date"));
        if (pyBool(pyOr(!pyBool(rd), () => pyOr(((pyCompare(rd, start) < 0)), () => ((pyCompare(rd, as_of) > 0)))))) {
            continue;
        }
        org = pyMethod(pyOr(pyMethod(r, "get", "org_name"), () => ""), "strip");
        if (pyBool(!pyBool(org))) {
            pyMethod(ambiguous_orgs, "append", "missing_institution");
            continue;
        }
        cur = pyMethod(by_org, "get", org);
        key = [rd, pyOr(pyMethod(r, "get", "report_title"), () => "")];
        if (pyBool(pyOr(((cur === null)), () => ((pyCompare(key, pyAt(cur, "_key")) > 0))))) {
            r = pyDict(r);
            r["_key"] = key;
            by_org[org] = r;
        }
    }
    dist = (() => { const _comprehension26: any = {}; for (const k of pyIter(RATING_ORDER)) {
        _comprehension26[k] = 0;
    } return _comprehension26; })();
    [mapped, unmapped] = [0, []];
    for ([org, r] of pyIter(pyMethod(by_org, "items"))) {
        raw = pyMethod(pyOr(pyMethod(r, "get", "rating"), () => ""), "strip");
        cat = pyMethod(RATING_MAP, "get", raw);
        if (pyBool(((cat === null)))) {
            pyMethod(unmapped, "append", { ["brokerage"]: org, ["original_rating"]: pyOr(raw, () => null), ["reason"]: "unmappable_or_missing_rating" });
            continue;
        }
        dist[cat] += 1;
        mapped += 1;
    }
    summary = { ["status"]: "unavailable", ["reason"]: "no_mapped_opinions" };
    if (pyBool(mapped)) {
        best = pyMax([pyMethod(dist, "values")], null, false);
        tied = (() => { const _comprehension27: any = []; for (const c of pyIter(RATING_ORDER)) {
            if (!pyBool(((pyAt(dist, c) === best))))
                continue;
            _comprehension27.push(c);
        } return _comprehension27; })();
        if (pyBool(((pyCompare(pyLen(tied), 1) > 0)))) {
            summary = { ["status"]: "available", ["label"]: "Most common brokerage rating", ["value"]: "Mixed", ["tied_categories"]: tied, ["category_count"]: best, ["total_mapped_brokerages"]: mapped, ["note"]: "Tie between categories; no majority claimed." };
        }
        else {
            summary = { ["status"]: "available", ["label"]: "Most common brokerage rating", ["value"]: pyAt(tied, 0), ["category_count"]: best, ["total_mapped_brokerages"]: mapped, ["majority"]: ((pyCompare((best * 2), mapped) > 0)), ["note"]: "Modal category among eligible brokerages; not an average and not this app's opinion." };
        }
    }
    quote = null;
    try {
        hist = await _daily((pyStr(company.ticker) + ".SH"), pyDateFormat(pyDateSubtract(new PyDate(as_of), new PyDelta(12, 0)), "%Y%m%d"), pyMethod(as_of, "replace", "-", ""));
        if (pyBool(hist)) {
            top = pyMax([hist], (x: any) => (pyAt(x, "trade_date")), false);
            quote = { ["price"]: pyFloat(pyAt(top, "close")), ["date"]: d(pyAt(top, "trade_date")), ["basis"]: "raw close" };
        }
    }
    catch (__error) {
        if (true) {
            const exc: any = __error;
            pyMethod(pyAt(res, "data_limitations"), "append", ("quote for upside: " + pyStr(pyAt(_err(exc), "status"))));
        }
        else {
            throw __error;
        }
    }
    res["latest_close"] = quote;
    groups = {};
    individual = [];
    excluded_targets = [];
    for ([org, r] of pyIter(pyMethod(by_org, "items"))) {
        [lo, hi] = [pyMethod(r, "get", "min_price"), pyMethod(r, "get", "max_price")];
        rd = d(pyMethod(r, "get", "report_date"));
        try {
            [lo_f, hi_f] = [pyFloat(lo), pyFloat(hi)];
        }
        catch (__error) {
            if (true) {
                pyMethod(excluded_targets, "append", { ["brokerage"]: org, ["report_date"]: rd, ["reason"]: "missing_or_invalid_target_bounds" });
                continue;
            }
            else {
                throw __error;
            }
        }
        if (pyBool(!pyBool(pyAnd(((pyCompare(lo_f, 0) > 0)), () => pyAnd(((pyCompare(hi_f, 0) > 0)), () => ((pyCompare(lo_f, hi_f) <= 0))))))) {
            pyMethod(excluded_targets, "append", { ["brokerage"]: org, ["report_date"]: rd, ["reason"]: "invalid_target_bounds" });
            continue;
        }
        horizon = null;
        entry = { ["brokerage"]: org, ["report_date"]: rd, ["min_price"]: lo_f, ["max_price"]: hi_f, ["midpoint"]: pyRound((pyAdd(lo_f, hi_f) / 2), 4), ["currency"]: "CNY", ["verified_horizon"]: horizon, ["report_title"]: pyMethod(r, "get", "report_title") };
        pyMethod(individual, "append", entry);
        if (pyBool(((horizon === null)))) {
            pyMethod(excluded_targets, "append", { ["brokerage"]: org, ["report_date"]: rd, ["reason"]: "unverified_target_horizon" });
            continue;
        }
        g = pyMethod(groups, "setdefault", horizon, { ["horizon"]: horizon, ["members"]: [] });
        pyMethod(pyAt(g, "members"), "append", entry);
    }
    target_groups = [];
    for (g of pyIter(pyMethod(groups, "values"))) {
        members = pyAt(g, "members");
        out = { ["horizon"]: pyAt(g, "horizon"), ["eligible_brokerage_count"]: pyLen(members), ["source_dates"]: pySorted([(() => { const _comprehension28: any = []; for (const m of pyIter(members)) {
                    if (!pyBool(pyAt(m, "report_date")))
                        continue;
                    _comprehension28.push(pyAt(m, "report_date"));
                } return new Set(_comprehension28); })()], null, false), ["contributions"]: (() => { const _comprehension29: any = []; for (const m of pyIter(members)) {
                _comprehension29.push((() => { const _comprehension30: any = {}; for (const k of pyIter(["brokerage", "report_date", "min_price", "max_price", "midpoint"])) {
                    _comprehension30[k] = pyAt(m, k);
                } return _comprehension30; })());
            } return _comprehension29; })() };
        if (pyBool(((pyCompare(pyLen(members), MIN_BROKERAGES_PER_TARGET_GROUP) < 0)))) {
            pyMethod(out, "update", { ["average_target_midpoint"]: null, ["implied_percentage_difference"]: null, ["status"]: "insufficient_data", ["reason"]: ("insufficient_brokerage_coverage (needs " + pyStr(MIN_BROKERAGES_PER_TARGET_GROUP) + ")") });
        }
        else {
            if (pyBool(!pyBool(quote))) {
                pyMethod(out, "update", { ["average_target_midpoint"]: null, ["implied_percentage_difference"]: null, ["status"]: "unavailable", ["reason"]: "no_dated_close_for_comparison" });
            }
            else {
                avg = (pySum((() => { const _comprehension31: any = []; for (const m of pyIter(members)) {
                    _comprehension31.push(pyAt(m, "midpoint"));
                } return _comprehension31; })()) / pyLen(members));
                pyMethod(out, "update", { ["average_target_midpoint"]: pyRound(avg, 4), ["unit"]: "CNY per share", ["implied_percentage_difference"]: pyRound((((avg / pyAt(quote, "price")) - 1) * 100), 4), ["quote_date"]: pyAt(quote, "date"), ["quote_basis"]: "raw close", ["calculation"]: "arithmetic mean of brokerage midpoints, one contribution per brokerage", ["note"]: "Implied price difference vs the dated close -- not a guaranteed or measured return.", ["status"]: "available" });
            }
        }
        pyMethod(target_groups, "append", out);
    }
    res["rating_distribution"] = dist;
    res["rating_summary"] = summary;
    res["eligible_brokerages_for_ratings"] = mapped;
    res["eligible_brokerages_for_targets"] = pyLen(individual);
    res["total_distinct_brokerages_in_window"] = pyLen(by_org);
    res["individual_source_targets"] = individual;
    res["target_groups"] = target_groups;
    res["excluded_target_records"] = excluded_targets;
    res["unmapped_ratings"] = unmapped;
    res["excluded_ambiguous_institutions"] = pyLen(ambiguous_orgs);
    res["count_unit"] = "brokerages (not analysts, not reports)";
    res["horizon_policy_note"] = "Targets are averaged only within a verified common horizon. Where no target horizon is documented by the source, individual source targets are still displayed but excluded from any average with reason unverified_target_horizon.";
    res["status"] = (pyBool(pyOr(mapped, () => individual)) ? "available" : (pyBool(rows) ? "partial" : "no_results"));
    pyMethod(pyAt(res, "data_limitations"), "append", "Broker ratings and targets are third-party research opinions attributed to their brokerages; this panel is a sourced summary, not personalised investment advice.");
    return res;
}
export async function bundle_for(company: any, period: any = "1y"): Promise<any> {
    let fn: any, name: any, out: any, runners: any;
    out = { ["company"]: company.to_dict(), ["capabilities"]: {}, ["generated_at"]: retrieved_at(), ["timezone"]: "Asia/Shanghai" };
    runners = { ["historical_analysis"]: async () => (await historical_analysis(company, period)), ["card_metrics"]: async () => (await card_metrics(company)), ["industry_research"]: async () => (await industry_research(company)), ["company_industry_news"]: async () => (await company_industry_news(company)), ["price_target"]: async () => (await price_target(company)) };
    for ([name, fn] of pyIter(pyMethod(runners, "items"))) {
        try {
            pyAt(out, "capabilities")[name] = await fn();
        }
        catch (__error) {
            if (true) {
                const exc: any = __error;
                pyAt(out, "capabilities")[name] = { ["capability_id"]: name, ..._err(exc) };
            }
            else {
                throw __error;
            }
        }
    }
    out["feature_status"] = (() => { const _comprehension32: any = {}; for (const [k, v] of pyIter(pyMethod(pyAt(out, "capabilities"), "items"))) {
        _comprehension32[k] = pyMethod(v, "get", "status", "error");
    } return _comprehension32; })();
    return out;
}
