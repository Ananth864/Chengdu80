/** Local, schema-versioned records. No networking. Synthetic bundles are rejected. */
import { existsSync, readFileSync, mkdirSync, writeFileSync, renameSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { ROOT } from './paths.ts';
export const SCHEMA_VERSION = '1.1.0';
export const STORE_PATH = process.env.QWEN_STORE_PATH || join(ROOT, 'data/store/results.json');
const now = (): string => new Date(Date.now() + 8 * 3600000).toISOString().slice(0, 19) + '+08:00';
function read(): any {
    const empty = { schema_version: SCHEMA_VERSION, records: {} };
    if (!existsSync(STORE_PATH))
        return empty;
    try {
        const data = JSON.parse(readFileSync(STORE_PATH, 'utf8'));
        return data?.schema_version === SCHEMA_VERSION && data.records && typeof data.records === 'object' && !Array.isArray(data.records) ? data : empty;
    }
    catch (error) {
        if (error instanceof SyntaxError)
            return empty;
        throw error;
    }
}
export function contains_fixture(bundle: any): boolean {
    return Boolean(bundle.fixture_mode) || Object.values(bundle.capabilities || {}).some((v: any) => v?.status === 'fixture');
}
export function save(bundle: any): any {
    if (contains_fixture(bundle))
        return { status: 'rejected', reason: 'fixture data is never stored as an observation' };
    const company = bundle.company || {}, ticker = company.company_id;
    if (!ticker)
        return { status: 'rejected', reason: 'bundle has no validated company identity' };
    const record = { schema_version: SCHEMA_VERSION, stored_at: now(), exchange: company.exchange || 'SSE', company,
        capabilities: bundle.capabilities || {}, feature_status: bundle.feature_status || {},
        provenance: { provider: 'Tushare (via backend)', as_of: bundle.generated_at, timezone: bundle.timezone || 'Asia/Shanghai' } };
    // Synchronous read/replace is indivisible within one Node.js process.
    const data = read();
    data.records[ticker] = record;
    mkdirSync(dirname(STORE_PATH), { recursive: true });
    const temporary = STORE_PATH + '.tmp';
    writeFileSync(temporary, JSON.stringify(data, null, 1));
    renameSync(temporary, STORE_PATH);
    return { status: 'stored', ticker, stored_at: record.stored_at, capability_ids: Object.keys(record.capabilities) };
}
export const get = (ticker: string): any => read().records[(ticker || '').trim()] || null;
export const all_records = (): Record<string, any> => read().records;
export function summary(): any[] {
    return Object.entries(all_records()).map(([ticker, rec]) => ({ ticker,
        company_name: rec.company?.company_name, industry_label: rec.company?.industry_label, stored_at: rec.stored_at,
        populated: Object.entries(rec.capabilities || {}).filter(([, v]: any) => v?.status === 'available').map(([k]) => k),
        statuses: rec.feature_status || {} })).sort((a, b) => String(b.stored_at || '').localeCompare(String(a.stored_at || '')));
}
