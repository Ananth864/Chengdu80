import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
// Sources live in backend/; compiled JavaScript lives in dist/backend/.
const directory = dirname(fileURLToPath(import.meta.url));
export const ROOT = resolve(directory, directory.endsWith('/dist/backend') ? '../..' : '..');
