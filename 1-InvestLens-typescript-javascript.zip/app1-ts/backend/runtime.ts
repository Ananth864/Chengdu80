/** Native JS compatibility helpers preserve collection, date, and numeric semantics of the original algorithms. */
import { createHash } from 'node:crypto';
export function pyBool(v: any): boolean {
    if (v == null || v === false || v === '' || v === 0)
        return false;
    if (Array.isArray(v))
        return v.length > 0;
    if (v instanceof Set || v instanceof Map)
        return v.size > 0;
    if (typeof v === 'object' && v.constructor === Object)
        return Object.keys(v).length > 0;
    return true;
}
export const pyOr = (a: any, b: () => any): any => pyBool(a) ? a : b();
export const pyAnd = (a: any, b: () => any): any => pyBool(a) ? b() : a;
export function pyAt(v: any, k: any): any {
    if (typeof v === 'string' || Array.isArray(v)) {
        const i = k < 0 ? v.length + k : k;
        if (i < 0 || i >= v.length)
            throw new RangeError('Index out of range');
        return v[i];
    }
    if (v == null || !Object.hasOwn(v, k))
        throw new Error('Missing key: ' + k);
    return v[k];
}
export const pySlice = (v: any, start: any, end: any): any => v.slice(start ?? 0, end ?? undefined);
export function pyIn(item: any, container: any): boolean {
    if (typeof container === 'string')
        return container.includes(item);
    if (container instanceof Set || Array.isArray(container)) {
        return [...container].some(v => Array.isArray(v) && Array.isArray(item) ? pyCompare(v, item) === 0 : v === item);
    }
    return container != null && Object.hasOwn(container, item);
}
export function pyCompare(a: any, b: any): number {
    if (Array.isArray(a) && Array.isArray(b)) {
        for (let i = 0; i < Math.min(a.length, b.length); i++) {
            const c = pyCompare(a[i], b[i]);
            if (c)
                return c;
        }
        return Math.sign(a.length - b.length);
    }
    return a === b ? 0 : a < b ? -1 : 1;
}
export function pyIter(v: any): any[] {
    if (v == null)
        throw new TypeError('Cannot iterate null');
    if (typeof v === 'string' || Array.isArray(v) || v instanceof Set || v instanceof Map)
        return [...v];
    return Object.keys(v);
}
export const pyLen = (v: any): number => v instanceof Set || v instanceof Map ? v.size : v.length ?? Object.keys(v).length;
export function pySorted(args: any[], key: any = null, reverse = false): any[] {
    return pyIter(args[0]).sort((a, b) => (reverse ? -1 : 1) * pyCompare(key ? key(a) : a, key ? key(b) : b));
}
function extremum(args: any[], key: any, direction: number): any {
    const vals = args.length === 1 ? pyIter(args[0]) : args;
    if (!vals.length)
        throw new Error('Empty sequence');
    return vals.reduce((a, b) => direction * pyCompare(key ? key(a) : a, key ? key(b) : b) >= 0 ? a : b);
}
export const pyMax = (args: any[], key: any = null, _reverse = false): any => extremum(args, key, 1);
export const pyMin = (args: any[], key: any = null, _reverse = false): any => extremum(args, key, -1);
export const pySum = (v: any): number => pyIter(v).reduce((a, b) => a + b, 0);
export const pyAny = (v: any): boolean => pyIter(v).some(pyBool);
export const pyAll = (v: any): boolean => pyIter(v).every(pyBool);
export const pyList = (v: any = []): any[] => pyIter(v);
export const pySet = (v: any = []): Set<any> => new Set(pyIter(v));
export const pyDict = (v: any = {}): any => Array.isArray(v) ? Object.fromEntries(v) : { ...v };
export function pyZip(...values: any[]): any[][] {
    const arrays = values.map(pyIter);
    return Array.from({ length: Math.min(...arrays.map(a => a.length)) }, (_, i) => arrays.map(a => a[i]));
}
export function pyRange(start: number, stop?: number): number[] {
    if (stop === undefined) {
        stop = start;
        start = 0;
    }
    return Array.from({ length: Math.max(0, stop - start) }, (_, i) => start + i);
}
export function pyRound(v: number, places = 0): number {
    if (!Number.isFinite(v))
        return v;
    const scale = 10 ** places, scaled = v * scale, floor = Math.floor(scaled), fraction = scaled - floor;
    return (fraction === 0.5 ? floor + (floor % 2 === 0 ? 0 : 1) : Math.round(scaled)) / scale;
}
export const pyAbs = (v: number): number => Math.abs(v);
export function pyFloat(v: any): number {
    if (v == null || typeof v === 'string' && !v.trim())
        throw new TypeError('Not a number');
    if (v === 'inf')
        return Infinity;
    const num = Number(v);
    if (Number.isNaN(num))
        throw new TypeError('Not a number');
    return num;
}
export const pyInt = (v: any): number => Math.trunc(pyFloat(v));
export const pyType = (v: any): any => v?.constructor ?? { name: 'NoneType' };
export const pyIsinstance = (v: any, types: any): boolean => (Array.isArray(types) ? types : [types]).some(t => t === Number ? typeof v === 'number' : t === String ? typeof v === 'string' : v instanceof t);
export function pyStr(v: any): string {
    if (v === null || v === undefined)
        return 'None';
    if (v === true)
        return 'True';
    if (v === false)
        return 'False';
    if (typeof v === 'object')
        return JSON.stringify(v);
    return String(v);
}
export function pyFormat(v: any, format: string): string {
    if (format === ',.0f')
        return Number(v).toLocaleString('en-US', { maximumFractionDigits: 0, minimumFractionDigits: 0 });
    if (/^0?\d+d$/.test(format))
        return String(v).padStart(parseInt(format), '0');
    return pyStr(v);
}
export function pyMod(a: any, b: any): any {
    if (typeof a !== 'string')
        return ((a % b) + b) % b;
    const values = Array.isArray(b) ? [...b] : [b];
    return a.replace(/%[sd]/g, () => pyStr(values.shift()));
}
export function pyMethod(v: any, method: string, ...args: any[]): any {
    switch (method) {
        case 'get': return Object.hasOwn(v, args[0]) ? v[args[0]] : args.length > 1 ? args[1] : null;
        case 'items': return Object.entries(v);
        case 'keys': return Object.keys(v);
        case 'values': return Object.values(v);
        case 'append':
            v.push(args[0]);
            return null;
        case 'update':
            Object.assign(v, args[0]);
            return null;
        case 'setdefault':
            if (!Object.hasOwn(v, args[0]))
                v[args[0]] = args[1] ?? null;
            return v[args[0]];
        case 'pop': {
            const result = Object.hasOwn(v, args[0]) ? v[args[0]] : args[1] ?? null;
            delete v[args[0]];
            return result;
        }
        case 'strip': return v.trim();
        case 'lower': return v.toLowerCase();
        case 'upper': return v.toUpperCase();
        case 'startswith': return v.startsWith(args[0]);
        case 'endswith': return v.endsWith(args[0]);
        case 'isdigit': return /^\d+$/.test(v);
        case 'replace': return v.split(args[0]).join(args[1]);
        case 'join': return pyIter(args[0]).join(v);
        case 'encode': return v;
        case 'hexdigest': return v;
        case 'search': return regexSearch(v, args[0], false);
        case 'match': return regexSearch(v, args[0], true);
        case 'end': return v.index + v[0].length;
        default: throw new Error('Unsupported method: ' + method);
    }
}
export class PyDelta {
    milliseconds: number;
    constructor(days = 0, hours = 0) { this.milliseconds = days * 86400000 + hours * 3600000; }
}
export class PyDate {
    date: Date;
    constructor(value: string | number | Date) { this.date = new Date(typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) ? value + 'T00:00:00Z' : value); }
    isoformat(): string { return this.date.toISOString().slice(0, 10); }
}
export const pyDateSubtract = (date: PyDate, delta: PyDelta): PyDate => new PyDate(date.date.getTime() - delta.milliseconds);
export const pyDateFormat = (date: PyDate, format: string): string => format === '%Y%m%d' ? date.isoformat().replaceAll('-', '') : date.isoformat();
export const pyHash = (text: string): string => createHash('sha256').update(text, 'utf8').digest('hex');
function regexSearch(regex: RegExp, text: string, anchored: boolean): any {
    regex.lastIndex = 0;
    const match = regex.exec(text);
    return match && (!anchored || match.index === 0) ? match : null;
}
export const pyRegex = {
    compile(pattern: string, flags = 0): RegExp { return new RegExp(pattern, (flags & 2 ? 'i' : '') + (flags & 8 ? 'm' : '')); },
    search(pattern: string, text: string): any { return regexSearch(new RegExp(pattern), text, false); },
    findall(pattern: string, text: string): any[] { return [...text.matchAll(new RegExp(pattern, 'g'))].map(m => m.length > 1 ? m[1] : m[0]); },
};
export const pyAdd = (a: any, b: any): any => Array.isArray(a) && Array.isArray(b) ? a.concat(b) : a + b;
