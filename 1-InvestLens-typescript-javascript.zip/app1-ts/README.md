# InvestLens — TypeScript and JavaScript

Complete backend port of `/Users/larahachfeld/Desktop/qwen/app1`. The browser frontend was already JavaScript and is retained with its HTML and CSS. There is no Python runtime or Python source in this project.

## Run

Use Node.js **22.18 or newer**. The compiled JavaScript is included, so no dependency installation is needed to start:

```sh
cd "/Users/larahachfeld/Documents/ChatGPT/Chengdu 80/app1-ts"
npm start
```

Open **http://127.0.0.1:8765**. To choose another port:

```sh
npm start -- --port 9000
```

`node start.mjs` also works and builds automatically if compiled output is absent. `npm run dev` runs the TypeScript directly.

Without a Tushare token, the live panels show `provider_not_configured`. Use the existing fixture toggle to preview the layout with visibly labelled synthetic data. Fixtures never enter the factual record store.

## Credentials and records

Use **Connect Tushare** in the UI, set `TUSHARE_TOKEN` in the backend environment, or put the token in `config/tushare_token.txt`. Precedence is session memory, environment, then configuration file. The optional persistent token file is restricted to mode `0600`. Tokens are not included in API responses or stored financial records. The configuration example contains no credential.

Live bundles are saved to `data/store/results.json`; override the location with `QWEN_STORE_PATH`. This package starts with an empty store and does not copy the original app's session records or logs. Existing compatible records can be copied from the original app if desired. The bundled company CSV is preserved.

## Source and JavaScript output

| Original Python module | TypeScript source | Runnable JavaScript |
| --- | --- | --- |
| `server.py` | `backend/server.ts` | `dist/backend/server.js` |
| `tushare_client.py` | `backend/tushare_client.ts` | `dist/backend/tushare_client.js` |
| `universe.py` | `backend/universe.ts` | `dist/backend/universe.js` |
| `financial.py` | `backend/financial.ts` | `dist/backend/financial.js` |
| `capabilities.py` | `backend/capabilities.ts` | `dist/backend/capabilities.js` |
| `fixtures.py` | `backend/fixtures.ts` | `dist/backend/fixtures.js` |
| `metric_guide.py` | `backend/metric_guide.ts` | `dist/backend/metric_guide.js` |
| `result_store.py` | `backend/result_store.ts` | `dist/backend/result_store.js` |
| `chatbot.py` | `backend/chatbot.ts` | `dist/backend/chatbot.js` |

`backend/runtime.ts` provides native JavaScript collection, date, numeric, and regular-expression helpers to preserve the original algorithms' semantics. It is not an interpreter and never executes Python. `backend/paths.ts` locates assets for both source and compiled execution. JSON-shaped provider and capability records deliberately retain dynamic types and existing field names so the current UI remains compatible.

Rebuild after editing TypeScript:

```sh
npm run build
```

The build uses Node's built-in TypeScript stripping and has no package dependency. It converts all `.ts` module references into `.js` references. The generated `dist` directory is included for platforms that accept JavaScript only. Ship it together with `web`, `data/companies.csv`, and `config`; these assets are outside `dist`.

## Verification

```sh
npm test
npm install
npm run typecheck
```

Tests build and run without installing dependencies. Only static type checking needs the development dependencies. Tests use temporary stores and offline mocked provider responses; they do not contact Tushare.

17 tests cover:

- Python reference-output comparisons for all five live capabilities, every fixture panel, financial statement retrieval, all company CSV records, education content, and factual chatbot handlers.
- Missing-provider results, fixture rejection, persisted live records, stale timestamps, chatbot scope/context and injection handling, comparable-YTD TTM calculations, provider permission errors, empty success, and cache separation between credentials.
- Real localhost HTTP checks of the UI assets, API endpoints, token privacy, malformed input, unsupported methods, and static-file traversal protection.

`tests/parity-data.json` contains synthetic provider inputs and reference outputs captured from the original Python implementation, not real market observations. Comparisons ignore retrieval timestamps and harmless textual differences such as `12.0` versus `12`.

## Hosting

This package targets a **Node.js backend**. Choose the final platform before adding its deployment adapter. Conventional Node hosting can run `npm start`; set `HOST=0.0.0.0` when the host requires listening on all interfaces, and use its supplied `PORT`.

The current architecture is a single-user, single-process app with a process-wide session token and a writable JSON store. A serverless or edge deployment needs different persistence and session handling; a browser-only platform needs a separately hosted backend to keep the provider token private. No platform deployment has been attempted.

Live Tushare access and endpoint permissions have not been verified. The original provider-specific behavior and demo limitations remain: report targets without verified horizons are not averaged; no ROE/interest-coverage peer batch is fetched; news requests and matching follow the original implementation. The original industry annual-batch helper does not explicitly filter publication dates, and its growth-cohort selection uses the full returned batch. These existing analytical limitations need a separate correctness pass before relying on those outputs.

The Node adapter additionally validates JSON bodies and ports, constrains static files to the web directory, avoids echoing provider error text that could contain credentials, and prevents cache reuse across changed credentials. Fixture dates consistently use Asia/Shanghai.
