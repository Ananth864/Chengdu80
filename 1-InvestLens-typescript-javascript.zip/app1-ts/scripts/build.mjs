// Compile TypeScript into standalone JavaScript using Node's built-in transformer.
// No dependencies, Python interpreter, or network required to build or run.
import { stripTypeScriptTypes } from 'node:module';
import { readdirSync, readFileSync, writeFileSync, mkdirSync, rmSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = resolve(root, 'dist/backend');
rmSync(resolve(root, 'dist'), { recursive: true, force: true }); mkdirSync(output, { recursive: true });
for (const file of readdirSync(resolve(root, 'backend')).filter(f => f.endsWith('.ts'))) {
  const source = readFileSync(resolve(root, 'backend', file), 'utf8').replace(/(from\s+['"][^'"]+)\.ts(['"])/g, '$1.js$2');
  const js = stripTypeScriptTypes(source, { mode: 'strip', sourceUrl: `../../backend/${file}` });
  writeFileSync(resolve(output, file.replace(/\.ts$/, '.js')), js);
}
console.log('Built all backend modules in dist/backend/');
