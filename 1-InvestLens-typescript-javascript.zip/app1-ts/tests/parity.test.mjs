import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
const temporary = mkdtempSync(join(tmpdir(), 'app1-parity-'));
process.env.QWEN_STORE_PATH = join(temporary, 'results.json');
const { provider, expected } = JSON.parse(readFileSync(new URL('./parity-data.json', import.meta.url), 'utf8'));
const capabilities = await import('../dist/backend/capabilities.js');
const financial = await import('../dist/backend/financial.js');
const fixtures = await import('../dist/backend/fixtures.js');
const universe = await import('../dist/backend/universe.js');
const chatbot = await import('../dist/backend/chatbot.js');
const store = await import('../dist/backend/result_store.js');
const client = await import('../dist/backend/tushare_client.js');
const guide = await import('../dist/backend/metric_guide.js');
const company = universe.get_company('600000');
const RealDate = Date;
const realFetch = globalThis.fetch;
let calls = 0;
function normalize(value) {
  // The original fixture dates use host local time; this port consistently uses Shanghai.
  if (Array.isArray(value)) return value.map(normalize);
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).filter(([k]) => k !== 'retrieved_at' && k !== 'generated_at').map(([k, v]) => [k, normalize(v)]));
  if (typeof value === 'string') return value.replace(/(-?\d+)\.0(?!\d)/g, '$1');
  return value;
}
function compare(actual, reference) { assert.deepEqual(normalize(actual), normalize(reference)); }
function installMocks() {
  globalThis.Date = class extends RealDate {
    constructor(...args) { super(...(args.length ? args : ['2026-10-14T12:00:00Z'])); }
    static now() { return RealDate.parse('2026-10-14T12:00:00Z'); }
  };
  globalThis.fetch = async (_url, options) => {
    calls++; const payload = JSON.parse(options.body), params = payload.params;
    let rows = provider[payload.api_name] || [];
    if (['income', 'balancesheet', 'fina_indicator'].includes(payload.api_name)) {
      if (params.ts_code) rows = rows.filter(r => r.ts_code === params.ts_code);
      if (params.period) rows = rows.filter(r => r.end_date === params.period);
    }
    const fields = [...new Set(rows.flatMap(r => Object.keys(r)))];
    return { ok: true, json: async () => ({ code: 0, data: { fields, items: rows.map(r => fields.map(f => r[f] ?? null)) } }) };
  };
}
try {
  installMocks();
  await test('universe and education match all Python reference records', () => {
    compare(Object.values(universe.load_universe()).map(c => c.to_dict()), expected.universe);
    compare(guide.GUIDE, expected.guide);
  });
  await test('every synthetic panel matches the original fixture generator', () => compare(fixtures.bundle(company), expected.fixture));
  client.set_memory_token('offline-test-credential');
  for (const [name, fn] of [
    ['historical', () => capabilities.historical_analysis(company)], ['metrics', () => capabilities.card_metrics(company)],
    ['industry', () => capabilities.industry_research(company)], ['news', () => capabilities.company_industry_news(company)],
    ['targets', () => capabilities.price_target(company)], ['financial', () => financial.fetch_company_financials('600000.SH', '2026-10-14')],
  ]) await test(`${name} output matches Python under identical provider responses`, async () => compare(await fn(), expected[name]));
  await test('all factual chatbot handlers match Python and perform no networking', () => {
    const before = calls;
    for (const [q, reference] of Object.entries(expected.dispatch)) compare(chatbot._dispatch(q.toLowerCase(), expected.record, company.name), reference);
    assert.equal(calls, before);
  });
} finally {
  globalThis.Date = RealDate; globalThis.fetch = realFetch; client.clear_memory_token();
  rmSync(temporary, { recursive: true, force: true });
}
