/* Dashboard composition (capability: dashboard) + visualizations + metric education.
 * Each capability renders independently: a failed or unconfigured section never hides
 * results from the others. No chart is drawn without sourced observations. */
'use strict';

const S = { ticker: null, period: '1y', bundle: null, guide: {}, fixture: false };
const $ = s => document.querySelector(s);
const el = (t, c, h) => { const e = document.createElement(t); if (c) e.className = c; if (h != null) e.innerHTML = h; return e; };
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]));
const num = (v, d = 2) => (v == null || !isFinite(v)) ? null : Number(v).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
const pct = (v, d = 2) => (v == null || !isFinite(v)) ? null : num(v, d) + '%';
const money = v => { if (v == null || !isFinite(v)) return null;
  const a = Math.abs(v);
  if (a >= 1e12) return num(v / 1e12, 2) + ' trillion';
  if (a >= 1e8) return num(v / 1e8, 2) + ' hundred million';
  if (a >= 1e4) return num(v / 1e4, 2) + ' ten thousand';
  return num(v, 2); };

const STATUS_LABEL = {
  available: 'available', partial: 'partial', no_results: 'no results',
  insufficient_data: 'insufficient data', stale: 'stale',
  provider_not_configured: 'provider not configured',
  permission_denied: 'permission denied', unsupported_data: 'unsupported data',
  error: 'error', fixture: 'FIXTURE DATA — NOT REAL',
};

async function api(path, params = {}) {
  const q = new URLSearchParams(params).toString();
  const r = await fetch(q ? `${path}?${q}` : path, { cache: 'no-store' });
  const j = await r.json().catch(() => ({ status: 'error', reason: 'non-JSON response' }));
  j.__http = r.status;
  return j;
}

/* ------------------------------------------------------------------ header -- */
async function boot() {
  const cfg = await refreshConfig();
  if (!cfg.configured) {
    const n = $('#notice'); n.hidden = false;
    n.innerHTML = '<strong>No data token configured.</strong> The app is fully wired to Tushare, but every ' +
      'data panel will honestly report <code>provider_not_configured</code>. Click ' +
      '<em>Connect Tushare</em> (top right) to paste your token into the local backend — or ' +
      'tick <em>show labelled demo fixtures</em> to see the layout with numbers clearly stamped as fake.';
  } else { $('#notice').hidden = true; }
  const g = await api('/api/metric-guide');
  S.guide = g.guide || {};
}

/* ------------------------------------------------------------------ search -- */
let searchTimer;
$('#search').addEventListener('input', e => {
  clearTimeout(searchTimer);
  const v = e.target.value.trim();
  searchTimer = setTimeout(async () => {
    const box = $('#results');
    if (!v) { box.hidden = true; return; }
    const r = await api('/api/companies', { q: v, limit: 30 });
    box.innerHTML = '';
    (r.results || []).forEach(c => {
      const row = el('div', '', `<strong>${esc(c.company_name)}</strong> <span class="tk">${esc(c.company_id)}</span>` +
        `<small>${esc(c.industry_label)} · ${esc(c.size_category || '')}</small>`);
      row.onclick = () => { box.hidden = true; $('#search').value = `${c.company_name} (${c.company_id})`; load(c.company_id); };
      box.appendChild(row);
    });
    box.hidden = !(r.results || []).length;
  }, 220);
});
$('#search').addEventListener('keydown', async e => {
  if (e.key !== 'Enter') return;
  const m = e.target.value.match(/\d{6}/);
  if (m) { $('#results').hidden = true; return load(m[0]); }
  const r = await api('/api/companies', { q: e.target.value.trim(), limit: 1 });
  if (r.results && r.results[0]) load(r.results[0].company_id);
});
document.addEventListener('click', e => { if (!e.target.closest('.search-wrap')) $('#results').hidden = true; });

document.querySelectorAll('.periods button').forEach(b => b.onclick = () => {
  document.querySelectorAll('.periods button').forEach(x => x.classList.remove('on'));
  b.classList.add('on'); S.period = b.dataset.p; if (S.ticker) load(S.ticker);
});
$('#fixtureMode').onchange = e => { S.fixture = e.target.checked; if (S.ticker) load(S.ticker); };

/* -------------------------------------------------------------------- load -- */
async function load(ticker) {
  const chk = await api('/api/company', { ticker });
  if (chk.status !== 'available') {
    $('#main').innerHTML = `<div class="hero-empty"><h2>Not a valid universe member</h2><p>${esc(chk.message || 'Only SSE A-share companies from the supplied CSV can be validated.')}</p></div>`;
    return;
  }
  S.ticker = ticker;
  $('#main').innerHTML = '<div class="hero-empty"><h2>Loading…</h2><p class="meta">querying Tushare through the local backend</p></div>';
  const params = { ticker, period: S.period };
  if (S.fixture) params.mode = 'fixture';
  S.bundle = await api('/api/bundle', params);
  render(S.bundle);
}

const isFx = cap => cap && cap.status === 'fixture';
const isOk = st => st === 'available' || st === 'fixture';
function fxBanner() {
  return el('div', 'warnbar', 'DEMO FIXTURE — every value in this panel is synthetic. It is NOT a real market, financial or news observation and cannot support any investment judgement.');
}

function panel(title, cap, id) {
  const p = el('section', 'panel'); p.id = id;
  const st = cap && cap.status ? cap.status : 'error';
  p.appendChild(el('h3', '', `${esc(title)} <span class="chip st-${esc(st)}">${esc(STATUS_LABEL[st] || st)}</span>`));
  const meta = (cap && (cap.retrieved_at || cap.as_of)) ?
    `source: ${esc(cap.provider || 'Tushare')} · as of ${esc(cap.as_of || '')} · retrieved ${esc(cap.retrieved_at || '')}` : '';
  if (meta) p.appendChild(el('div', 'meta', meta));
  return p;
}
function reason(cap) {
  const bits = [];
  if (cap.reason) bits.push(cap.reason);
  if (cap.error_code) bits.push('code ' + cap.error_code);
  if (!bits.length && cap.data_limitations && cap.data_limitations.length) bits.push(cap.data_limitations[0]);
  return bits.length ? el('p', 'reason', 'Why: ' + esc(bits.join(' — '))) : null;
}

/* ------------------------------------------------------------------ render -- */
function render(b) {
  const main = $('#main'); main.innerHTML = '';
  const c = b.company || {};
  const head = el('section', 'panel');
  head.appendChild(el('div', 'company-h',
    `<h2>${esc(c.company_name)}</h2><span class="tk">${esc(c.exchange || 'SSE')} · ${esc(c.company_id)}</span>` +
    `<span class="badge">${esc(c.industry_label)}</span><span class="badge">${esc(c.size_category || '')}</span>`));
  head.appendChild(el('div', 'meta',
    'Peer comparisons use every CSV company sharing this exact industry label — a supplied-universe ' +
    'SSE statistic, not a whole-China benchmark.'));
  main.appendChild(head);

  main.appendChild(pricePanel(b.capabilities.historical_analysis));
  main.appendChild(metricsPanel(b.capabilities.card_metrics));
  main.appendChild(industryPanel(b.capabilities.industry_research));
  main.appendChild(targetPanel(b.capabilities.price_target));
  main.appendChild(newsPanel(b.capabilities.company_industry_news));
  main.appendChild(el('p', 'meta',
    'feature status: ' + Object.entries(b.feature_status || {}).map(([k, v]) => `${k}=${v}`).join(' · ') +
    ' · timezone Asia/Shanghai'));
}

/* ------------------------------------------------------------------ charts -- */
function lineChart(series, h = 260) {
  if (!series || series.length < 2) return el('p', 'reason', 'Not enough dated observations to draw a price line. Nothing is interpolated.');
  const W = 900, P = 42;
  const vals = series.map(s => s.close), hi = series.map(s => s.high), lo = series.map(s => s.low);
  const min = Math.min(...lo), max = Math.max(...hi), span = (max - min) || 1;
  const x = i => P + i * (W - P * 2) / (series.length - 1);
  const y = v => h - 26 - ((v - min) / span) * (h - 52);
  const pts = series.map((s, i) => `${x(i).toFixed(1)},${y(s.close).toFixed(1)}`).join(' ');
  const area = `M${x(0)},${h - 26} L` + pts.split(' ').join(' L') + ` L${x(series.length - 1)},${h - 26} Z`;
  let ticks = '';
  for (let k = 0; k <= 4; k++) {
    const v = min + span * k / 4, yy = y(v);
    ticks += `<line class="grid-l" x1="${P}" y1="${yy}" x2="${W - P}" y2="${yy}"/>` +
      `<text class="axis" x="${P - 7}" y="${yy + 4}" text-anchor="end">${money(v)}</text>`;
  }
  const nlab = Math.min(5, series.length);
  for (let k = 0; k < nlab; k++) {
    const i = Math.round(k * (series.length - 1) / (nlab - 1 || 1));
    ticks += `<text class="axis" x="${x(i)}" y="${h - 6}" text-anchor="middle">${(series[i].date || '').slice(0, 7)}</text>`;
  }
  let dots = '';
  series.forEach((s, i) => {
    dots += `<circle cx="${x(i)}" cy="${y(s.close)}" r="7" fill="transparent"><title>${esc(s.date)} · close ${esc(num(s.close))} CNY · high ${esc(num(s.high))} · low ${esc(num(s.low))}</title></circle>`;
  });
  const svg = `<svg viewBox="0 0 ${W} ${h}" role="img" aria-label="Closing price history, raw unadjusted daily quotes">
    ${ticks}<path class="area" d="${area}"/><polyline class="line" points="${pts}"/>${dots}
    <text class="axis" x="${P}" y="14">close (raw daily quotes, CNY) — hover points for values</text></svg>`;
  return el('div', '', svg);
}

function barChart(rows, key, label, color) {
  const data = rows.filter(r => r[key] != null);
  if (!data.length) return el('p', 'reason', `No sourced observations for ${esc(label.text)}.`);
  const W = 900, h = 230, P = 52;
  const vals = data.map(r => r[key]);
  const min = Math.min(0, ...vals), max = Math.max(...vals), span = (max - min) || 1;
  const bw = (W - P * 2) / data.length * 0.6;
  let g = '';
  data.forEach((r, i) => {
    const cx = P + (i + 0.5) * (W - P * 2) / data.length;
    const y0 = h - 30 - ((0 - min) / span) * (h - 60);
    const y1 = h - 30 - ((r[key] - min) / span) * (h - 60);
    g += `<rect x="${cx - bw / 2}" y="${Math.min(y0, y1)}" width="${bw}" height="${Math.abs(y1 - y0)}" fill="${color}" rx="3">
      <title>${esc(r[label._k] || r.years || r.financial_year)}: ${esc(num(r[key], 2))} ${label.unit}</title></rect>`;
    g += `<text class="axis" x="${cx}" y="${h - 10}" text-anchor="middle">${esc(r[label._k] || r.years || r.financial_year)}</text>`;
  });
  return el('div', '', `<svg viewBox="0 0 ${W} ${h}" role="img" aria-label="${esc(label.text)}">${g}</svg>`);
}

/* ----------------------------------------------------------------- pricing -- */
function pricePanel(cap) {
  const p = panel('Price history', cap, 'p-price');
  if (!cap || cap.status === 'provider_not_configured' || cap.status === 'permission_denied' ||
      cap.status === 'error' || cap.status === 'no_results') { const r = reason(cap); if (r) p.appendChild(r); return p; }

  const src = cap;
  if (isFx(src)) p.appendChild(fxBanner());
  const m = (src.metrics || {});
  const cov = src.actual_coverage_period || {};
  p.appendChild(el('div', 'meta', `coverage ${esc(cov.start || '?')} → ${esc(cov.end || '?')} · ${esc(cov.trading_days || 0)} trading days · basis: ${esc(src.price_basis || src.adjustment_basis || '')}`));

  const q = el('div', 'quote');
  const cell = (k, v, info, cls) => {
    const d = el('div', 'q');
    d.appendChild(el('div', 'k', '')).append(k);
    const lab = d.querySelector('.k'); lab.textContent = k;
    const vv = el('div', 'v ' + (cls || ''), v == null ? 'N/A' : v);
    if (info) vv.appendChild(infoBtn(info));
    d.appendChild(vv); return d;
  };
  const dc = m.daily_change_percentage;
  q.appendChild(cell('Latest close', m.current_price != null ? `CNY ${num(m.current_price)}` : null, 'current_price'));
  q.appendChild(cell('Daily change', dc == null ? null : `${dc > 0 ? '+' : ''}${pct(dc)}` +
    (m.daily_change_amount != null ? ` (${m.daily_change_amount > 0 ? '+' : ''}${num(m.daily_change_amount)})` : ''), 'daily_change', dc > 0 ? 'up' : dc < 0 ? 'down' : ''));
  q.appendChild(cell('52-week high', m['52_week_high'] != null ? num(m['52_week_high']) : null, '52_week_high'));
  q.appendChild(cell('52-week low', m['52_week_low'] != null ? num(m['52_week_low']) : null, '52_week_low'));
  q.appendChild(cell('Period high', m.available_period_high != null ? num(m.available_period_high) : null, 'available_period_high'));
  q.appendChild(cell('Period low', m.available_period_low != null ? num(m.available_period_low) : null, 'available_period_low'));
  const dfh = m.distance_from_52_week_high || {}, dfl = m.distance_from_52_week_low || {};
  q.appendChild(cell('vs 52w high', dfh.percentage != null ? pct(dfh.percentage) : null, 'distance_from_52_week_high'));
  q.appendChild(cell('vs 52w low', dfl.percentage != null ? pct(dfl.percentage) : null, 'distance_from_52_week_low'));
  const md = m.max_drawdown || {};
  q.appendChild(cell('Max drawdown', md.percentage == null ? null : pct(md.percentage), 'max_drawdown'));
  p.appendChild(q);

  if (md.status === 'unavailable')
    p.appendChild(el('p', 'reason', 'Max drawdown unavailable: ' + esc(md.reason || '') +
      '. Raw-price metrics above are still shown; drawdown is never calculated from raw prices.'));
  else if (md.reference_date)
    p.appendChild(el('div', 'meta', `drawdown basis: adjusted closes, reference date ${esc(md.reference_date)}, ${esc(md.period || '')}`));
  if (src.coverage_note) p.appendChild(el('div', 'meta', esc(src.coverage_note)));

  p.appendChild(lineChart(src.series));
  return p;
}

/* ----------------------------------------------------------------- metrics -- */
const METRIC_META = {
  pe: ['P/E (TTM)', 'x'], ps: ['P/S (TTM)', 'x'], dividend_yield: ['TTM cash dividend yield', '%'],
  revenue_growth: ['Revenue growth', '%'], roe: ['ROE', '%'], interest_coverage: ['Interest coverage', 'x'],
};
function metricsPanel(cap) {
  const p = panel('Company metrics', cap, 'p-metrics');
  if (!cap || !cap.metrics) { const r = reason(cap); if (r) p.appendChild(r); return p; }
  if (isFx(cap)) p.appendChild(fxBanner());
  p.appendChild(el('div', 'meta', `quote date ${esc(cap.quote_as_of || 'N/A')} · latest completed financial year ${esc(cap.latest_completed_financial_year || 'N/A')} · all values CNY basis`));

  const grid = el('div', 'grid metrics');
  Object.entries(cap.metrics).forEach(([id, m]) => {
    const [name, unit] = METRIC_META[id] || [id, ''];
    const card = el('div', 'mcard');
    const lab = el('div', 'lab', esc(name)); lab.appendChild(infoBtn(id));
    card.appendChild(lab);
    const shown = isOk(m.status) && m.value != null
      ? num(m.value, 2) + (unit === '%' ? '%' : ' ' + unit) : 'N/A';
    card.appendChild(el('div', 'val' + (isOk(m.status) ? '' : ' na'), shown));
    const bits = [];
    if (!isOk(m.status)) bits.push('status ' + m.status + (m.reason ? ` (${m.reason})` : ''));
    else {
      bits.push(m.provenance === 'calculated' ? 'calculated' : (m.status === 'fixture' ? 'FIXTURE' : 'provider ratio'));
      if (m.reporting_period) bits.push('FY' + m.reporting_period);
      if (m.calculation_basis) bits.push(m.calculation_basis);
    }
    card.appendChild(el('div', 'fine', esc(bits.join(' · '))));
    const bm = m.benchmark || {};
    if (isOk(bm.status) && bm.industry_median != null && m.value != null) {
      const scale = Math.max(Math.abs(m.value), Math.abs(bm.industry_median)) * 1.25 || 1;
      const wrap = el('div', 'bm');
      const bar = el('div', 'bar');
      const fill = el('div', 'fill'); fill.style.width = (Math.min(Math.abs(m.value), scale) / scale * 100) + '%';
      const med = el('div', 'med'); med.style.left = (Math.min(Math.abs(bm.industry_median), scale) / scale * 100) + '%';
      med.title = 'industry median';
      bar.append(fill, med); wrap.appendChild(bar);
      wrap.appendChild(el('div', 'txt',
        `<span>this company ${esc(num(m.value, 2))}</span><span>median ${esc(num(bm.industry_median, 2))} (n=${esc(bm.peer_count)})</span>`));
      wrap.appendChild(el('div', 'txt', `<span>${esc(bm.benchmark_period || '')}</span><span>excluded ${esc(bm.excluded_count)} of ${esc(bm.industry_universe_count)}</span>`));
      card.appendChild(wrap);
    } else if (bm.status) {
      card.appendChild(el('div', 'fine', `benchmark: ${esc(bm.status)}${bm.reason ? ' — ' + esc(bm.reason) : ''}${bm.peer_count != null ? ` (eligible n=${esc(bm.peer_count)})` : ''}`));
    }
    grid.appendChild(card);
  });
  p.appendChild(grid);
  p.appendChild(el('p', 'fine', 'Median markers are only drawn when both the company value and the peer median share one definition, period and quote date. A median of this SSE supplied universe is not an industry standard level.'));
  (cap.data_limitations || []).forEach(t => p.appendChild(el('p', 'reason', esc(t))));
  return p;
}

/* ---------------------------------------------------------------- industry -- */
function industryPanel(cap) {
  const p = panel('Industry — listed-company revenue history', cap, 'p-industry');
  if (!cap) return p;
  if (isFx(cap)) p.appendChild(fxBanner());
  if (!cap.annual_revenue_totals || !cap.annual_revenue_totals.some(r => r.aggregate_revenue_cny != null)) {
    const r = reason(cap); if (r) p.appendChild(r);
    p.appendChild(el('p', 'fine', 'No chart is drawn without sourced annual statements.'));
    return p;
  }
  p.appendChild(el('div', 'meta', `universe: ${esc(cap.industry_label)} · ${esc((cap.universe_scope || {}).total_universe_count)} CSV companies · exact industry-label match, no size filter`));
  p.appendChild(el('p', 'fine', esc(cap.status_note || '')));

  const rows = cap.annual_revenue_totals.map(r => ({ ...r, financial_year: r.financial_year + (r.status === 'partial' ? '*' : '') }));
  p.appendChild(barChart(rows, 'aggregate_revenue_cny', { _k: 'financial_year', text: 'aggregate reported annual revenue', unit: 'CNY' }, 'var(--accent)'));
  const tbl = el('table');
  tbl.innerHTML = '<tr><th>Financial year</th><th>Aggregate revenue (CNY)</th><th>Included</th><th>Coverage</th><th>Status</th></tr>' +
    cap.annual_revenue_totals.map(r => `<tr><td>${esc(r.financial_year)}</td><td>${r.aggregate_revenue_cny == null ? 'unavailable' : esc(money(r.aggregate_revenue_cny))}</td>` +
      `<td>${esc(r.included_company_count)}/${esc(r.total_universe_count)}</td>` +
      `<td>${r.coverage_percentage == null ? '—' : esc(r.coverage_percentage) + '%'}</td>` +
      `<td><span class="chip st-${esc(r.status)}">${esc(STATUS_LABEL[r.status] || r.status)}</span></td></tr>`).join('');
  p.appendChild(tbl);
  p.appendChild(el('div', 'fine', '* partial coverage: companies without a published consolidated annual statement are excluded, never counted as zero.'));

  p.appendChild(el('h3', '', 'Matched-cohort year-on-year growth'));
  const gro = (cap.matched_cohort_growth || []).filter(g => g.status === 'available');
  if (gro.length) {
    p.appendChild(barChart(gro, 'yoy_growth_percentage_points', { _k: 'years', text: 'matched-cohort YoY growth', unit: '%' }, 'var(--ok)'));
    p.appendChild(el('table', '', '<tr><th>Year pair</th><th>Growth</th><th>Matched companies</th><th>Cohort coverage</th></tr>' +
      gro.map(g => `<tr><td>${esc(g.years)}</td><td>${esc(pct(g.yoy_growth_percentage_points))}</td>` +
        `<td>${esc(g.matched_company_count)}</td><td>${esc(g.matched_cohort_coverage_percentage)}%</td></tr>`).join('')));
    p.appendChild(el('div', 'fine', 'Growth uses only companies reporting comparable revenue in both years of each pair. Cohort membership can differ between pairs, so this is not a fixed-cohort trend and is kept separate from the yearly totals above.'));
  } else {
    p.appendChild(el('p', 'reason', 'No matched-cohort growth computed: ' + esc((cap.matched_cohort_growth || [])[0]?.reason || 'no comparable year pairs retrieved') + '.'));
  }
  p.appendChild(el('p', 'fine', 'Out of demo scope: ' + esc((cap.excluded_scope || []).join(', ')) + '.'));
  return p;
}

/* ------------------------------------------------------------- price target -- */
function targetPanel(cap) {
  const p = panel('Brokerage research summary', cap, 'p-target');
  if (!cap) return p;
  if (isFx(cap)) p.appendChild(fxBanner());
  if (!cap.rating_distribution) { const r = reason(cap); if (r) p.appendChild(r); return p; }
  const qw = cap.query_window || {};
  p.appendChild(el('div', 'meta', `reports dated ${esc(qw.start_date)} → ${esc(qw.end_date)} · ${esc(cap.total_distinct_brokerages_in_batch || cap.total_distinct_brokerages_in_window || 0)} brokerages in window · counts are brokerages, not analysts or reports`));

  const total = Object.values(cap.rating_distribution).reduce((a, b) => a + (b || 0), 0) || 1;
  const box = el('div');
  cap.demo_configuration?.rating_categories?.forEach(cat => {
    const n = cap.rating_distribution[cat] || 0;
    box.appendChild(el('div', 'ratebar',
      `<span>${esc(cat)}</span><span class="t"><span class="f" style="width:${(n / total * 100).toFixed(1)}%"></span></span><span class="n">${esc(n)}</span>`));
  });
  p.appendChild(box);

  const s = cap.rating_summary || {};
  if (s.value) p.appendChild(el('p', 'meta', `${esc(s.label)}: <strong>${esc(s.value)}</strong> (${esc(s.category_count)} of ${esc(s.total_mapped_brokerages)} mapped)` +
    (s.tied_categories ? ` — tie between ${esc(s.tied_categories.join(', '))}` : '') + (s.majority ? '' : ' · no majority claimed')));
  else p.appendChild(el('p', 'fine', 'Rating summary: ' + esc(s.reason || 'unavailable')));

  const lc = cap.latest_close;
  if (lc) p.appendChild(el('div', 'fine', `comparison close: CNY ${esc(num(lc.price))} on ${esc(lc.date)} (${esc(lc.basis)})`));

  (cap.target_groups || []).forEach(g => {
    const d = el('div', 'mcard');
    d.appendChild(el('div', 'lab', `Target horizon: ${esc(g.horizon)}`));
    if (g.average_target_midpoint != null) {
      d.appendChild(el('div', 'val', `CNY ${esc(num(g.average_target_midpoint))}`));
      const ip = g.implied_percentage_difference;
      d.appendChild(el('div', 'fine', `implied difference vs close: ${esc(pct(ip))} — a price comparison, not a forecast return`));
      d.appendChild(el('div', 'fine', `${esc(g.eligible_brokerage_count)} brokerages · ${esc(g.calculation)}`));
    } else {
      d.appendChild(el('div', 'val na', 'N/A'));
      d.appendChild(el('div', 'fine', esc(g.status) + (g.reason ? ' — ' + esc(g.reason) : '')));
    }
    p.appendChild(d);
  });
  const ind = cap.individual_source_targets || [];
  if (ind.length) {
    p.appendChild(el('table', '', '<tr><th>Brokerage</th><th>Report date</th><th>Low</th><th>High</th><th>Midpoint</th></tr>' +
      ind.slice(0, 12).map(t => `<tr><td>${esc(t.brokerage)}</td><td>${esc(t.report_date)}</td><td>${esc(num(t.min_price))}</td>` +
        `<td>${esc(num(t.max_price))}</td><td>${esc(num(t.midpoint))}</td></tr>`).join('')));
  }
  const ex = (cap.excluded_target_records || []);
  const reasons = [...new Set(ex.map(e => e.reason))];
  p.appendChild(el('p', 'fine', (cap.target_groups || []).length
    ? '' : `No target average shown: ${esc(reasons.join(', ') || 'no valid target bounds')} — ${esc(cap.horizon_policy_note || '')}`));
  if ((cap.unmapped_ratings || []).length)
    p.appendChild(el('p', 'fine', `${cap.unmapped_ratings.length} rating(s) excluded as unmappable; originals retained, not defaulted to Hold.`));
  (cap.data_limitations || []).forEach(t => p.appendChild(el('p', 'reason', esc(t))));
  return p;
}

/* -------------------------------------------------------------------- news -- */
function newsPanel(cap) {
  const p = panel('Company & industry news', cap, 'p-news');
  if (!cap) return p;
  if (isFx(cap)) p.appendChild(fxBanner());
  const w = cap.query_window || {};
  if (cap.status === 'available' || cap.status === 'partial' || cap.status === 'no_results')
    p.appendChild(el('div', 'meta', `window ${esc(w.start_date)} → ${esc(w.end_date)} (7-day default) · newest first · max 5 company + 5 industry items`));
  if (!cap.feed || !cap.feed.length) {
    if (cap.status === 'no_results') p.appendChild(el('p', 'fine', 'A successful query returned no matching stories in this window — an empty feed, not a failure.'));
    else { const r = reason(cap); if (r) p.appendChild(r); else p.appendChild(el('p', 'reason', 'News section could not be queried; this is not presented as an empty feed.')); }
    return p;
  }
  const ul = el('ul');
  cap.feed.forEach(it => {
    const li = el('li');
    const src = it.source_reference || {};
    const href = src.url && /^https?:\/\//i.test(src.url) ? src.url : null;
    li.appendChild(el('div', 'mt', (it.match_type || '') + (it.also_matches_industry ? ' · also matches industry' : '')));
    const t = el('div', '', href ? `<a href="${esc(href)}" target="_blank" rel="noopener noreferrer">${esc(it.title)}</a>` : esc(it.title));
    li.appendChild(t);
    li.appendChild(el('div', 'when', `${esc(it.publisher || 'publisher not supplied')} · ${esc(it.published_at || 'time not supplied')} · ${esc(it.provider_id || 'Tushare')}`));
    if (it.summary) li.appendChild(el('div', 'fine', esc(it.summary)));
    ul.appendChild(li);
  });
  const box = el('div', 'news'); box.appendChild(ul); p.appendChild(box);
  p.appendChild(el('p', 'fine', esc(cap.coverage_note || '') + ' Timing of a story is not evidence that it moved the price.'));
  return p;
}

/* -------------------------------------------------------- education dialog -- */
function infoBtn(id) {
  const b = el('button', 'info', 'i');
  b.setAttribute('aria-label', 'Explain ' + id);
  b.onclick = () => explain(id);
  return b;
}
function explain(id) {
  const g = S.guide[id];
  const dlg = $('#explain'), body = $('#explainBody');
  body.innerHTML = '';
  const name = (METRIC_META[id] || [id])[0];
  body.appendChild(el('h4', '', esc(g ? name : id)));
  if (!g) body.appendChild(el('p', '', 'No curated explanation is available for this item.'));
  else {
    [['What it means', g.meaning], ['Why it is useful', g.usefulness],
     ['How to compare it with an industry', g.comparison_context]].forEach(([h, t]) => {
      if (!t) return;
      body.appendChild(el('div', 'h', esc(h)));
      body.appendChild(el('p', '', esc(t)));
    });
  }
  body.appendChild(el('p', 'fine', 'There is no universal good or bad level for this metric. A numeric benchmark is only valid when definitions, periods and units match.'));
  dlg.showModal();
}
document.addEventListener('keydown', e => { if (e.key === 'Escape' && $('#explain').open) $('#explain').close(); });

/* ----------------------------------------------------------- fixture guard -- */
/* Fixture data is produced by the backend and stamped status="fixture". The UI
   only labels it — nothing here invents financial values. */

/* ------------------------------------------------------------------ token UI -- */
const tokenState = $('#tokenState'), connectBtn = $('#connectBtn'),
      tokenDialog = $('#tokenDialog'), tokenInput = $('#tokenInput'),
      tokenPersist = $('#tokenPersist'), verifyBox = $('#verifyResults');

async function post(path, body) {
  const r = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify(body) });
  return r.json();
}
async function refreshConfig() {
  const cfg = await api('/api/config');
  tokenState.textContent = cfg.configured
    ? `Tushare connected (${cfg.token_source})` : 'no Tushare token — data panels report unavailable';
  tokenState.className = 'token-state ' + (cfg.configured ? 'ok' : 'off');
  connectBtn.textContent = cfg.configured ? 'Manage Tushare token' : 'Connect Tushare';
  return cfg;
}
connectBtn.onclick = () => { tokenInput.value = ''; tokenDialog.showModal(); };
tokenState.onclick = () => { tokenInput.value = ''; tokenDialog.showModal(); };
$('#tokenClose').onclick = e => { e.preventDefault(); tokenDialog.close(); };

$('#tokenSave').onclick = async e => {
  e.preventDefault();
  const tok = tokenInput.value.trim();
  if (!tok) return;
  const res = await post('/api/token', { token: tok, persist: tokenPersist.checked });
  tokenInput.value = '';
  verifyBox.hidden = false;
  verifyBox.innerHTML = `<p>${esc(res.status === 'saved'
    ? 'Token saved to the backend (memory' + (res.written_to_config_file ? ' + config file' : ', session only') + '). It is not stored in the browser.'
    : res.status === 'cleared' ? 'Session token cleared from backend memory.'
    : 'Save failed: ' + esc(res.reason || res.status))}</p>`;
  await refreshConfig();
  if (S.ticker) load(S.ticker);
};
$('#tokenClear').onclick = async e => {
  e.preventDefault();
  const res = await post('/api/token', { token: '', persist: false });
  verifyBox.hidden = false;
  verifyBox.innerHTML = `<p>${esc(res.note || 'Session token cleared.')}</p>`;
  await refreshConfig();
  if (S.ticker) load(S.ticker);
};
$('#tokenVerify').onclick = async e => {
  e.preventDefault();
  verifyBox.hidden = false;
  verifyBox.innerHTML = '<p class="fine">Running one minimal authenticated query per data family — this contacts Tushare. Results describe each endpoint separately…</p>';
  const res = await post('/api/verify', {});
  if (res.status === 'provider_not_configured') {
    verifyBox.innerHTML = '<p>No token in the backend — nothing was sent anywhere.</p>'; return;
  }
  const rows = (res.endpoints || []).map(ep => {
    const st = ep.status === 'available' ? 'st-available'
             : ep.status === 'empty_success' ? 'st-partial' : 'st-permission_denied';
    return `<div class="vrow"><span class="chip ${st}">${esc(ep.status)}</span> `
      + `<strong>${esc(ep.endpoint)}</strong> <span class="fine">— ${esc(ep.description)}</span>`
      + (ep.rows_returned ? ` <span class="fine">(${esc(ep.rows_returned)} rows)</span>` : '')
      + (ep.reason ? `<div class="fine reason">why: ${esc(ep.reason)}</div>` : '')
      + (ep.note ? `<div class="fine">${esc(ep.note)}</div>` : '') + '</div>';
  }).join('');
  verifyBox.innerHTML = `<p><strong>${esc(res.endpoints_ok)}/${esc(res.endpoints_total)}</strong> `
    + `endpoints returned data for this account <span class="fine">(token source: ${esc(res.token_source)})</span></p>`
    + rows + `<p class="fine">${esc(res.note)}</p>`;
};

boot();

/* ------------------------------------------------------------ chatbot UI -- */
const ANSWER_COLORS = {
  answered: 'var(--ok)', insufficient_data: 'var(--warn)', stale_data: 'var(--warn)',
  unsupported_question: 'var(--bad)', error: 'var(--bad)',
  conversational: 'var(--dim)', clarification_needed: 'var(--accent)',
};
const ANSWER_LABELS = {
  answered: 'answered from stored records',
  insufficient_data: 'insufficient data',
  stale_data: 'stale data',
  unsupported_question: 'unsupported question',
  error: 'retrieval error',
  conversational: 'conversation',
  clarification_needed: 'needs clarification',
};

function chatBubble(role, html) {
  const log = $('#chatLog');
  const b = el('div', 'bubble ' + role, html);
  log.appendChild(b);
  log.scrollTop = log.scrollHeight;
  return b;
}

async function refreshChatScope() {
  const st = await api('/api/store');
  const n = (st.stored_companies || []).length;
  const chip = $('#chatScopeChip');
  chip.textContent = n ? `${n} company record${n > 1 ? 's' : ''} in local store` : 'store empty';
  chip.className = 'chip ' + (n ? 'st-available' : 'st-unavailable');
}

$('#chatForm').addEventListener('submit', async e => {
  e.preventDefault();
  const input = $('#chatInput');
  const q = input.value.trim();
  if (!q) return;
  input.value = '';
  chatBubble('user', esc(q));
  const thinking = chatBubble('bot', '<span class="fine">querying local store…</span>');
  let r;
  const params = { q };
  if (S.ticker) params.ctx = S.ticker;  // resolves "its" -> the dashboard selection
  try { r = await api('/api/chat', params); }
  catch { r = { answer: 'Chatbot request failed.', answer_status: 'error' }; }
  const color = ANSWER_COLORS[r.answer_status] || 'var(--dim)';
  let html = `<div class="st" style="color:${color}">${esc(ANSWER_LABELS[r.answer_status] || r.answer_status)}</div>`;
  html += `<div>${esc(r.answer || '(no answer text)')}</div>`;
  if (r.citations && (r.citations.as_of || r.citations.stored_at)) {
    html += `<div class="fine">source: ${esc(r.citations.source || 'stored record')} · as of ${esc(r.citations.as_of || '?')} · stored ${esc(r.citations.stored_at || '?')}</div>`;
  }
  if (r.note) html += `<div class="fine">note: ${esc(r.note)}</div>`;
  thinking.innerHTML = html;
  refreshChatScope();
});

refreshChatScope();
