import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';

const MAX_BODY = 2 * 1024 * 1024;
const MAX_RESP = 12 * 1024 * 1024;
type Options = { upstream?: string; timeoutMs?: number };

export function createFinMatchServer(options: Options = {}) {
  const upstream = options.upstream ?? 'https://api.tushare.pro';
  const publicDir = fileURLToPath(new URL('../public/', import.meta.url));
  return createServer(async (req: IncomingMessage, res: ServerResponse) => {
    const origin = req.headers.origin;
    // Browser access is limited to file pages and local development origins.
    if (origin && origin !== 'null' && !/^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i.test(origin)) {
      res.writeHead(403, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ code: 403, msg: 'origin not allowed' }));
      return;
    }
    res.setHeader('Access-Control-Allow-Origin', origin ?? '*');
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Headers', 'content-type');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Max-Age', '600');
    const reply = (status: number, obj: unknown) => {
      res.writeHead(status, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(obj));
    };
    if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
    if (req.method === 'GET' && ['/', '/index.html', '/finmatch-app.html', '/app.js'].includes(req.url ?? '')) {
      const filename = req.url === '/app.js' ? 'app.js' : 'index.html';
      try {
        const data = await readFile(resolve(publicDir, filename));
        res.writeHead(200, { 'Content-Type': filename.endsWith('.js') ? 'text/javascript; charset=utf-8' : 'text/html; charset=utf-8' });
        res.end(data);
      } catch { reply(500, { code: 500, msg: 'build the app first: npm run build' }); }
      return;
    }
    if (!['/', '/tushare'].includes(req.url ?? '')) { reply(404, { code: 404, msg: 'unknown path' }); return; }
    if (req.method !== 'POST') { reply(405, { code: 405, msg: 'method not allowed' }); return; }
    const length = Number(req.headers['content-length'] ?? 0);
    if (!Number.isInteger(length) || length <= 0 || length > MAX_BODY) { reply(400, { code: 400, msg: 'bad body size' }); req.resume(); return; }
    let raw: Buffer;
    try {
      const chunks: Buffer[] = [];
      let size = 0;
      for await (const chunk of req) {
        size += chunk.length;
        if (size > MAX_BODY) { reply(400, { code: 400, msg: 'bad body size' }); return; }
        chunks.push(Buffer.from(chunk));
      }
      raw = Buffer.concat(chunks);
    } catch { reply(400, { code: 400, msg: 'incomplete request' }); return; }
    let payload: Record<string, unknown>;
    try {
      const parsed: unknown = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(raw));
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error();
      payload = parsed as Record<string, unknown>;
    } catch { reply(400, { code: 400, msg: 'invalid JSON' }); return; }
    if (typeof payload.token !== 'string' || !payload.token.trim() || typeof payload.api_name !== 'string' || !payload.api_name.trim()) {
      reply(400, { code: 400, msg: 'token and api_name required' }); return;
    }
    try {
      const response = await fetch(upstream, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload), signal: AbortSignal.timeout(options.timeoutMs ?? 30_000), redirect: 'error',
      });
      const cap = response.ok ? MAX_RESP : 64 * 1024;
      const chunks: Uint8Array[] = [];
      let size = 0;
      if (response.body) {
        const reader = response.body.getReader();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (size + value.length > cap) {
            if (response.ok) { await reader.cancel(); reply(502, { code: 502, msg: 'upstream response too large' }); return; }
            chunks.push(value.subarray(0, cap - size)); await reader.cancel(); break;
          }
          size += value.length; chunks.push(value);
        }
      }
      res.writeHead(response.ok ? 200 : 502, { 'Content-Type': 'application/json' });
      res.end(Buffer.concat(chunks));
      // No token, request body, upstream rows, or exception details are logged.
    } catch { reply(502, { code: 502, msg: 'upstream request failed' }); }
  });
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.argv[2] ?? 8787);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    console.error('usage: node dist/proxy.js [port]'); process.exit(1);
  }
  const server = createFinMatchServer();
  server.on('error', () => { console.error('Could not start server; check the port.'); process.exitCode = 1; });
  server.listen(port, '127.0.0.1', () => console.log(`FinMatch: http://127.0.0.1:${port}\nToken is forwarded only, never stored or logged.`));
  process.on('SIGINT', () => server.close());
  process.on('SIGTERM', () => server.close());
}
