import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { createFinMatchServer } from '../dist/proxy.js';

async function serve(t, server) {
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  t.after(() => { server.closeAllConnections(); server.close(); });
  return `http://127.0.0.1:${server.address().port}`;
}
const post = (base, body, headers = {}) => fetch(base + '/tushare', { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body });
test('forwards JSON and serves app, with local CORS', async t => {
  let received;
  const upstream = await serve(t, createServer(async (req, res) => {
    let body = ''; for await (const chunk of req) body += chunk;
    received = JSON.parse(body); res.end(JSON.stringify({ code: 0, data: { items: [[1]] } }));
  }));
  const base = await serve(t, createFinMatchServer({ upstream }));
  const payload = { token: 'test-secret', api_name: 'daily_basic', params: { ts_code: '600000.SH' } };
  const res = await post(base, JSON.stringify(payload), { Origin: 'http://localhost:3000' });
  assert.equal(res.status, 200); assert.deepEqual(received, payload);
  assert.equal(res.headers.get('access-control-allow-origin'), 'http://localhost:3000');
  assert.equal((await res.json()).code, 0);
  assert.equal((await fetch(base, { method: 'OPTIONS' })).status, 204);
  assert.match(await (await fetch(base)).text(), /script src="\.\/app.js"/);
  assert.match(await (await fetch(base + '/app.js')).text(), /FinMatch ready/);
});
test('rejects malformed requests and remote origins', async t => {
  const base = await serve(t, createFinMatchServer());
  for (const body of ['{', 'null', '[]', '{}', '{"token":"x"}']) assert.equal((await post(base, body)).status, 400);
  assert.equal((await post(base, '{}', { Origin: 'https://example.com' })).status, 403);
  assert.equal((await fetch(base + '/missing')).status, 404);
  assert.equal((await post(base, 'x'.repeat(2 * 1024 * 1024 + 1))).status, 400);
});
test('maps upstream HTTP failures, oversized responses, and timeout to 502', async t => {
  for (const mode of ['http', 'oversize', 'timeout']) {
    const upstream = await serve(t, createServer((req, res) => {
      req.resume();
      if (mode === 'http') { res.writeHead(401); res.end('{"code":401}'); }
      if (mode === 'oversize') res.end('x'.repeat(12 * 1024 * 1024 + 1));
    }));
    const base = await serve(t, createFinMatchServer({ upstream, timeoutMs: mode === 'timeout' ? 50 : 5000 }));
    const res = await post(base, '{"token":"test","api_name":"daily"}');
    assert.equal(res.status, 502);
    if (mode === 'http') assert.equal((await res.json()).code, 401);
    if (mode === 'oversize') assert.equal((await res.json()).msg, 'upstream response too large');
    if (mode === 'timeout') assert.equal((await res.json()).msg, 'upstream request failed');
  }
});
