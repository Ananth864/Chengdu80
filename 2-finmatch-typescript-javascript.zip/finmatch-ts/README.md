# FinMatch — TypeScript / JavaScript package

Requires Node.js 22.18 or newer. No Python or npm dependencies required.

```sh
npm run build
npm start
```

Open http://127.0.0.1:8787. The generated JavaScript is included, so `npm start` also works without rebuilding. To use another port: `npm start -- 9000`, then update the proxy URL in the app's Data tab to match.

## Files

- `src/app.ts`: original browser application, extracted from the HTML; company CSV and all existing application logic retained.
- `src/proxy.ts`: typed Node.js replacement for the Python Tushare proxy, also serving the browser files.
- `public/index.html`: original interface and styles, loading `app.js`.
- `public/app.js`: generated browser JavaScript, suitable for static hosting.
- `dist/proxy.js`: generated Node.js JavaScript backend.
- `scripts/build.mjs`: dependency-free TypeScript stripping using Node's built-in API.
- `tests/proxy.test.mjs`: mock-upstream integration tests; run `npm test`.

## Migration scope

The original frontend was already JavaScript. Its behavior has been preserved in a TypeScript source file with `@ts-nocheck`; it has **not** been fully annotated or statically type-checked. The proxy has explicit TypeScript types. The build strips types and checks syntax; it does not perform TypeScript semantic checking.

The Python proxy has been replaced entirely. Its endpoint, request and response limits, timeout, and error mapping are retained. The replacement rejects remote browser origins (the original Python implementation reflected every origin despite its local-only comment), and safely rejects non-object JSON. It never logs tokens or response rows.

The browser files can be hosted independently, but live Tushare access still requires a backend because the API does not support browser CORS. This package targets a browser with a local Node.js server. Serverless, edge, and browser-only platforms may require a platform-specific backend adapter and a change to the app's existing localhost-only proxy URL validation. Tokens remain in request/process memory, and the original browser storage behavior is preserved.

Tests use mock Tushare responses; no live account or token was used. Full browser interaction and actual Tushare access have not been verified.
