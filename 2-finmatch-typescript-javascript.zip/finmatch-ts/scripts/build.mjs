import { stripTypeScriptTypes } from 'node:module';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
const root = new URL('../', import.meta.url);
mkdirSync(new URL('dist/', root), { recursive: true });
for (const [source, target] of [['src/proxy.ts', 'dist/proxy.js'], ['src/app.ts', 'public/app.js']]) {
  writeFileSync(new URL(target, root), stripTypeScriptTypes(readFileSync(new URL(source, root), 'utf8'), { mode: 'strip' }));
}
console.log('Built TypeScript sources into runnable JavaScript.');
