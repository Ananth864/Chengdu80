# BoardSight — TypeScript and JavaScript

Port of `BoardSight-Source`, with its Python server and Swift/macOS PDFKit reader replaced by TypeScript modules and compiled JavaScript. The original JavaScript dashboard, financial extraction rules, comparisons, evidence dialogs, browser storage and HTML/CSS are retained. No Python, Swift compiler or macOS executable is needed.

## Run

Use Node.js 22.18 or newer:

```sh
cd "/Users/larahachfeld/Documents/ChatGPT/Chengdu 80/boardsight-ts"
npm ci
npm start
```

Open http://127.0.0.1:8847. Stop with Ctrl+C. Compiled JavaScript is included; installation supplies the PDF.js dependency. The initial npm installation downloads packages; report processing makes no external API calls and uploads are never written to disk by the backend.

Choose a different port with `npm start -- --port 8848`. Hosting platforms can set `PORT` and `HOST=0.0.0.0`. This targets a conventional Node.js web backend; a serverless or edge platform may require an adapter and different worker/upload limits. The interface describes the default local setup. On remote hosting, reports are sent to that server and those privacy labels must be revised before publication.

## Source mapping

| Original | Replacement |
| --- | --- |
| `server.py` | `backend/server.ts` → `dist/server.js` |
| `pdf.swift` and `pdf-reader` | `backend/pdf.ts`, `pdf-worker.ts`, `extract.ts` → corresponding `dist/*.js` |
| `Launch.command` | `npm start` |
| `app.js` | `web/app.js` (existing JavaScript, retained from the current single-report source) |
| `index.html` | `web/index.html` (unchanged) |

The dashboard uses one annual report to compare current-year and prior-year columns, including comparative restatements. Missing or ambiguous prior-year values remain unavailable.

The `/extract` endpoint keeps the existing `{pages: string[]}` response format. PDF.js extracts text coordinates; the reader reconstructs rows from top to bottom and columns from left to right. Each PDF runs in a worker with a 40-second timeout. Uploads are limited to 30 MiB, including requests without a Content-Length header. UTF-8 TXT files support BOMs and form-feed page breaks. The server exposes only public UI assets, without the original directory listing behavior.

## Build and verify

```sh
npm run build
npm run typecheck
npm test
```

Eleven tests pass: the four original parser/table/OCBC/single-report suites, positioned-row reconstruction, UTF-8 handling, actual PDF extraction, malformed/empty PDFs and timeout handling, ten OCBC figures with original page references through generated PDF fixtures, port validation, and HTTP upload/static/error behavior. Tests run offline. The full original OCBC PDFs were not supplied: generated PDFs containing the supplied extracted statement text verify the new reader and existing parsers together. They do not establish identical extraction for every original report layout.

The compiled files, declarations and source maps are included in `dist`. Deploy that directory together with `web`, `package.json`, and `package-lock.json`; run `npm ci --omit=dev`, then `npm start`.

## Retained limitations

Scanned reports need OCR, which is not included. PDF.js and PDFKit may extract some layouts differently, so check source rows and figures against original reports. Generic layouts may need adapters; ambiguous rows remain selectable for manual review. Banking metrics retain Group scope and shareholder net profit; net profit divided by total income is not net interest margin. Browser workspace data remains in localStorage, and Clear workspace removes the saved report workspace.

PDF.js dependency documentation: https://github.com/mozilla/pdf.js
