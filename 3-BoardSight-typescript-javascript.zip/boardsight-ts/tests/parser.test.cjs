const fs=require('fs'),vm=require('vm'),assert=require('assert');let els={};const ctx={document:{getElementById:id=>els[id]??=( {addEventListener(){},value:'',innerHTML:'',textContent:'',showModal(){this.open=true},close(){this.open=false}})},console};vm.createContext(ctx);vm.runInContext(fs.readFileSync(require('path').join(__dirname,'../web/app.js'),'utf8'),ctx);vm.runInContext(`
state.unit=1000000;
let r=parse(['Revenue 100.5\\nNet profit (12.3)\\nTotal assets 120 110']);
if(r.revenue.value!==100500000||r.profit.value!==-12300000||r.assets.value!==null)throw Error('Extraction failed');
if(parse(['Revenue 10\\nRevenue 20']).revenue.value!==null)throw Error('Duplicate rows must abstain');
state.records=[{revenue:{value:110},profit:{value:22}},{revenue:{value:100},profit:{value:10}}];
if(Math.abs(change('revenue')-10)>1e-9||change('margin')!==10)throw Error('Formula failed');
state.records[1].revenue.value=0;if(change('revenue')!==null)throw Error('Zero denominator');
`,ctx);console.log('PASS: extraction, ambiguity, duplicate rows, signed values, changes, margins, zero denominator');
