const vm=require('vm'),fs=require('fs');let els={};let ctx={console,document:{getElementById:id=>els[id]??={value:'',textContent:'',innerHTML:'',addEventListener(){},showModal(){this.open=true},close(){this.open=false}}}};vm.createContext(ctx);vm.runInContext(fs.readFileSync(require('path').join(__dirname,'../web/app.js'),'utf8'),ctx);vm.runInContext(`
state.unit=1000000;
let p=parse(['Consolidated income statement\\n2025 2024\\nRevenue\\n128.4\\n112.8\\nNet profit\\n18.6\\n14.2'],2025);
if(p.revenue.value!==128400000||p.profit.value!==18600000)throw Error('Split rows / year columns');
let cn=parse(['2025 2024\\n营业收入：128.4 112.8\\n净利润 18.6 14.2'],2025);
if(cn.revenue.value!==128400000)throw Error('Chinese row');
let dup=parse(['Revenue 10\\nRevenue 20'],2025);if(dup.revenue.value!==null||dup.revenue.matches.length!==2)throw Error('Keep ambiguous sources');
let repeated=parse(['Revenue 10\\nRevenue 10'],2025);if(repeated.revenue.value!==10000000)throw Error('Matching repeats');
let narrative=parse(['Revenue increased 50% to 100'],2025);if(narrative.revenue)throw Error('Narrative excluded');
console.log('PASS: split PDF rows, explicit year columns, Chinese labels, conflicting and consistent repeats, narrative rejection');
`,ctx);
