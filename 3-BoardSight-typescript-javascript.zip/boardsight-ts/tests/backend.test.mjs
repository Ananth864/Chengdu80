import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { createApp, resolvePort } from '../dist/server.js';
import { reconstructRows } from '../dist/pdf.js';
import { extractReport, MAX_UPLOAD_BYTES } from '../dist/extract.js';
import { makePdf } from './make-pdf.mjs';

test('row reconstruction preserves positioned columns and reading order', () => {
  const item = (str, x, y) => ({ str, transform: [1, 0, 0, 1, x, y] });
  assert.equal(reconstructRows([item('110', 250, 700), item('100', 150, 701), item('Revenue', 30, 700), item('2025 2024', 150, 730)]), '2025 2024\nRevenue  100  110');
});
test('UTF-8 text, BOM and form-feed pages are preserved; invalid/empty input is rejected', async () => {
  assert.deepEqual(await extractReport(Buffer.from('\ufeffRevenue 100\f营业收入 90')), ['Revenue 100', '营业收入 90']);
  await assert.rejects(extractReport(Buffer.from(' \f\n')), /No selectable text/);
  await assert.rejects(extractReport(Uint8Array.of(0xff)), /UTF-8/);
  await assert.rejects(extractReport(new Uint8Array(MAX_UPLOAD_BYTES + 1)), /30 MB/);
});
test('actual PDF bytes yield ordered rows and page boundaries through the worker', async () => {
  const bytes = makePdf([[{ text: 'Revenue', x: 30, y: 700 }, { text: '100 90', x: 180, y: 700 }, { text: '2025 2024', x: 180, y: 730 }], [{ text: 'Total assets 120 110' }]]);
  const pages = await extractReport(bytes);
  assert.equal(pages.length, 2);
  assert.match(pages[0], /^2025 2024\nRevenue\s+100 90$/);
  assert.equal(pages[1], 'Total assets 120 110');
});
test('corrupt, image-only/empty PDFs and extraction timeout return errors', async () => {
  await assert.rejects(extractReport(Buffer.from('%PDF broken')), /could not be read/);
  await assert.rejects(extractReport(makePdf([[]])), /No selectable text/);
  await assert.rejects(extractReport(makePdf([[{ text: 'Revenue 100' }]]), 1), /timed out/);
});
test('PDF extraction feeds the unchanged OCBC rules for all ten figures', async () => {
  const elements = {};
  const context = vm.createContext({ document: { getElementById: id => elements[id] ??= { value: '', textContent: '', innerHTML: '', addEventListener() {}, showModal() {}, close() {} } } });
  vm.runInContext(readFileSync(new URL('../web/app.js', import.meta.url), 'utf8'), context);
  for (const year of [2025, 2024]) {
    const layout = JSON.parse(readFileSync(new URL(`./fixtures/layout${year}.json`, import.meta.url), 'utf8'));
    // Preserve all original page slots, including blank pages, so citations are checked.
    const pdf = makePdf(layout.map(page => page.split('\n').map((text, index) => ({ text, y: 770 - index * 12 }))));
    context.pages = await extractReport(pdf); context.year = year;
    const records = vm.runInContext('statementMetrics(pages, year)', context);
    const expected = year === 2025 ? [14614, 7422, 9125, 675688, 612118] : [14473, 7587, 3964, 625050, 564670];
    for (const [index, key] of ['revenue', 'profit', 'cash', 'assets', 'debt'].entries()) {
      assert.equal(records[key]?.value, expected[index] * 1e6, `${year} ${key}`);
      assert.equal(records[key].page, layout.findIndex(page => page.includes(key === 'cash' ? 'Consolidated Cash Flow Statement' : ['assets', 'debt'].includes(key) ? 'Balance Sheets' : 'Income Statements')) + 1);
    }
  }
});
test('ports accept platform PORT and explicit flags; invalid values fail clearly', () => {
  assert.equal(resolvePort([]), 8847); assert.equal(resolvePort([], '9000'), 9000);
  assert.equal(resolvePort(['--port', '8848'], '9000'), 8848);
  for (const raw of ['', '0', '65536', 'abc', '1.5']) assert.throws(() => resolvePort(['--port', raw]), /Port must/);
});
test('HTTP serves UI, uploads TXT/PDF, rejects errors and keeps source files private', async () => {
  const app = createApp();
  await new Promise((resolve, reject) => { app.once('error', reject); app.listen(0, '127.0.0.1', resolve); });
  const base = `http://127.0.0.1:${app.address().port}`;
  try {
    const home = await fetch(base); assert.equal(home.status, 200); assert.match(await home.text(), /BoardSight/);
    const script = await fetch(base + '/app.js'); assert.equal(script.status, 200); assert.match(await script.text(), /function statementMetrics/);
    const head = await fetch(base, { method: 'HEAD' }); assert.equal(head.status, 200); assert.equal(await head.text(), '');
    for (const path of ['/server.py', '/package.json', '/backend/server.ts', '/%2e%2e%2fpackage.json']) assert.equal((await fetch(base + path)).status, 404);
    const text = await fetch(base + '/extract', { method: 'POST', body: 'Revenue 100\fRevenue 90' });
    assert.deepEqual(await text.json(), { pages: ['Revenue 100', 'Revenue 90'] });
    const pdf = await fetch(base + '/extract', { method: 'POST', body: makePdf([[{ text: 'Revenue 100' }]]) });
    assert.equal(pdf.status, 200); assert.deepEqual(await pdf.json(), { pages: ['Revenue 100'] });
    const empty = await fetch(base + '/extract', { method: 'POST', body: '' }); assert.equal(empty.status, 422); assert.match((await empty.json()).error, /No selectable text/);
    const invalid = await fetch(base + '/extract', { method: 'POST', body: '%PDF invalid' }); assert.equal(invalid.status, 422);
    const large = await fetch(base + '/extract', { method: 'POST', body: new Uint8Array(MAX_UPLOAD_BYTES + 1) }); assert.equal(large.status, 413);
    assert.equal((await fetch(base + '/unknown', { method: 'POST', body: 'x' })).status, 404);
    assert.equal((await fetch(base, { method: 'PUT' })).status, 405);
  } finally { await new Promise(resolve => app.close(resolve)); }
});
