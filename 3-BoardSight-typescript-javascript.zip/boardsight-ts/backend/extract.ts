import { Worker } from 'node:worker_threads';
export const MAX_UPLOAD_BYTES = 30 * 1024 * 1024;
export const PDF_TIMEOUT_MS = 40_000;
const NO_TEXT = 'No selectable text found. Scanned reports need OCR, which is not included.';

export async function extractReport(data: Uint8Array, timeoutMs = PDF_TIMEOUT_MS): Promise<string[]> {
  if (data.byteLength > MAX_UPLOAD_BYTES) throw new Error('Each report must be 30 MB or smaller.');
  let pages: string[];
  if (Buffer.from(data.subarray(0, 4)).toString('ascii') === '%PDF') {
    pages = await new Promise<string[]>((resolve, reject) => {
      const worker = new Worker(new URL('./pdf-worker.js', import.meta.url), { workerData: data });
      let settled = false;
      const finish = (error?: Error, value?: string[]) => {
        if (settled) return;
        settled = true; clearTimeout(timer); void worker.terminate();
        if (error) reject(error); else resolve(value!);
      };
      const timer = setTimeout(() => finish(new Error('PDF extraction timed out after 40 seconds.')), timeoutMs);
      worker.once('message', (message: { pages?: string[]; error?: string }) => {
        if (message.error || !Array.isArray(message.pages)) finish(new Error(message.error || 'This PDF could not be read.'));
        else finish(undefined, message.pages);
      });
      worker.once('error', () => finish(new Error('This PDF could not be read.')));
      worker.once('exit', () => finish(new Error('PDF reader stopped before completing extraction.')));
    });
  } else {
    try { pages = new TextDecoder('utf-8', { fatal: true }).decode(data).split('\f'); }
    catch { throw new Error('Text reports must use UTF-8 encoding.'); }
  }
  if (!pages.some(page => page.trim())) throw new Error(NO_TEXT);
  return pages;
}
