import { parentPort, workerData } from 'node:worker_threads';
import { extractPdf } from './pdf.js';
try {
  parentPort?.postMessage({ pages: await extractPdf(workerData as Uint8Array) });
} catch {
  parentPort?.postMessage({ error: 'This PDF could not be read. Check that it is a valid, unencrypted report.' });
}
