/** Replacement for the Swift PDFKit reader. No OCR or external services. */
import { createRequire } from 'node:module';
import { dirname, join, sep } from 'node:path';
export interface PositionedText { str: string; transform: number[]; }

/** PDF coordinates grow upward: sort top to bottom, then left to right. */
export function reconstructRows(items: PositionedText[]): string {
  const parts = items.filter(item => item.str.trim()).map(item => ({
    text: item.str.replace(/\r?\n/g, ' '), x: item.transform[4], y: item.transform[5],
  })).sort((a, b) => b.y - a.y || a.x - b.x);
  const rows: typeof parts[] = [];
  for (const part of parts) {
    const last = rows.at(-1);
    if (last && Math.abs(last[0].y - part.y) < 3) last.push(part);
    else rows.push([part]);
  }
  return rows.map(row => row.sort((a, b) => a.x - b.x).map(part => part.text).join('  ')).join('\n');
}

export async function extractPdf(bytes: Uint8Array): Promise<string[]> {
  const { getDocument } = await import('pdfjs-dist/legacy/build/pdf.mjs');
  const assets = dirname(createRequire(import.meta.url).resolve('pdfjs-dist/package.json'));
  const task = getDocument({ data: Uint8Array.from(bytes), useSystemFonts: true,
    cMapUrl: join(assets, 'cmaps') + sep, cMapPacked: true,
    standardFontDataUrl: join(assets, 'standard_fonts') + sep,
  });
  try {
    const document = await task.promise;
    const pages: string[] = [];
    for (let index = 1; index <= document.numPages; index++) {
      const page = await document.getPage(index);
      const content = await page.getTextContent();
      pages.push(reconstructRows(content.items.filter((item): item is PositionedText & typeof item => 'str' in item)));
      page.cleanup();
    }
    return pages;
  } finally { await task.destroy(); }
}
