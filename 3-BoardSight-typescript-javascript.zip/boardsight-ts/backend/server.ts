import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { extractReport, MAX_UPLOAD_BYTES } from './extract.js';

const WEB = fileURLToPath(new URL('../web/', import.meta.url));
const ASSETS: Record<string, [string, string]> = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/index.html': ['index.html', 'text/html; charset=utf-8'],
  '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
};
function send(res: ServerResponse, status: number, body: string | Buffer, type = 'application/json; charset=utf-8', head = false): void {
  res.writeHead(status, { 'Content-Type': type, 'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(head ? undefined : body);
}
function error(res: ServerResponse, status: number, message: string): void { send(res, status, JSON.stringify({ error: message })); }
export async function handler(req: IncomingMessage, res: ServerResponse): Promise<void> {
  try {
    const path = new URL(req.url || '/', 'http://localhost').pathname;
    if (req.method === 'POST') {
      if (path !== '/extract') { error(res, 404, 'Not found.'); req.resume(); return; }
      const declared = Number(req.headers['content-length'] || 0);
      if (declared > MAX_UPLOAD_BYTES) { error(res, 413, 'Each report must be 30 MB or smaller.'); req.resume(); return; }
      let size = 0;
      const chunks: Buffer[] = [];
      for await (const chunk of req) {
        size += chunk.length;
        if (size > MAX_UPLOAD_BYTES) { error(res, 413, 'Each report must be 30 MB or smaller.'); req.resume(); return; }
        chunks.push(Buffer.from(chunk));
      }
      try { send(res, 200, JSON.stringify({ pages: await extractReport(Buffer.concat(chunks)) })); }
      catch (failure) { error(res, 422, (failure as Error).message); }
      return;
    }
    if (!['GET', 'HEAD'].includes(req.method || '')) {
      res.setHeader('Allow', 'GET, HEAD, POST'); error(res, 405, 'Method not allowed.'); return;
    }
    const asset = ASSETS[path];
    if (!asset) { error(res, 404, 'Not found.'); return; }
    send(res, 200, await readFile(resolve(WEB, asset[0])), asset[1], req.method === 'HEAD');
  } catch { if (!res.headersSent) error(res, 500, 'The request could not be completed.'); else res.end(); }
}
export function createApp() { return createServer((req, res) => { void handler(req, res); }); }
export function resolvePort(args: string[], environment?: string): number {
  const index = args.indexOf('--port');
  const raw = index >= 0 ? args[index + 1] : environment || '8847';
  if (!raw || !/^\d+$/.test(raw) || Number(raw) < 1 || Number(raw) > 65535)
    throw new Error('Port must be a number between 1 and 65535. Example: npm start -- --port 8848');
  return Number(raw);
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  try {
    const server = createApp(), port = resolvePort(process.argv.slice(2), process.env.PORT), host = process.env.HOST || '127.0.0.1';
    server.on('error', failure => { console.error(`Cannot start BoardSight: ${failure.message}`); process.exitCode = 1; });
    server.listen(port, host, () => console.log(`BoardSight: http://${host}:${port}`));
  } catch (failure) { console.error((failure as Error).message); process.exitCode = 1; }
}
